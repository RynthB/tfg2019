-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_hrm_function`
--

CREATE TABLE `llx_c_hrm_function` (
  `rowid` int(11) NOT NULL,
  `pos` tinyint(4) NOT NULL default '0',
  `code` varchar(16) collate utf8_unicode_ci NOT NULL,
  `label` varchar(50) collate utf8_unicode_ci default NULL,
  `c_level` tinyint(4) NOT NULL default '0',
  `active` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `llx_c_hrm_function`
--

INSERT INTO `llx_c_hrm_function` (`rowid`, `pos`, `code`, `label`, `c_level`, `active`) VALUES
(1, 5, 'EXECBOARD', 'Executive board', 0, 1),
(2, 10, 'MANAGDIR', 'Managing director', 1, 1),
(3, 15, 'ACCOUNTMANAG', 'Account manager', 0, 1),
(4, 20, 'ENGAGDIR', 'Engagement director', 1, 1),
(5, 25, 'DIRECTOR', 'Director', 1, 1),
(6, 30, 'PROJMANAG', 'Project manager', 0, 1),
(7, 35, 'DEPHEAD', 'Department head', 0, 1),
(8, 40, 'SECRETAR', 'Secretary', 0, 1),
(9, 45, 'EMPLOYEE', 'Department employee', 0, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_incoterms`
--

CREATE TABLE `llx_c_incoterms` (
  `rowid` int(11) NOT NULL auto_increment,
  `code` varchar(3) collate utf8_unicode_ci NOT NULL,
  `libelle` varchar(255) collate utf8_unicode_ci NOT NULL,
  `active` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_c_incoterms` (`code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Volcado de datos para la tabla `llx_c_incoterms`
--

INSERT INTO `llx_c_incoterms` (`rowid`, `code`, `libelle`, `active`) VALUES
(1, 'EXW', 'Ex Works, au départ non chargé, non dédouané sortie d''usine (uniquement adapté aux flux domestiques, nationaux)', 1),
(2, 'FCA', 'Free Carrier, marchandises dédouanées et chargées dans le pays de départ, chez le vendeur ou chez le commissionnaire de transport de l''acheteur', 1),
(3, 'FAS', 'Free Alongside Ship, sur le quai du port de départ', 1),
(4, 'FOB', 'Free On Board, chargé sur le bateau, les frais de chargement dans celui-ci étant fonction du liner term indiqué par la compagnie maritime (à la charge du vendeur)', 1),
(5, 'CFR', 'Cost and Freight, chargé dans le bateau, livraison au port de départ, frais payés jusqu''au port d''arrivée, sans assurance pour le transport, non déchargé du navire à destination (les frais de déchargement sont inclus ou non au port d''arrivée)', 1),
(6, 'CIF', 'Cost, Insurance and Freight, chargé sur le bateau, frais jusqu''au port d''arrivée, avec l''assurance marchandise transportée souscrite par le vendeur pour le compte de l''acheteur', 1),
(7, 'CPT', 'Carriage Paid To, livraison au premier transporteur, frais jusqu''au déchargement du mode de transport, sans assurance pour le transport', 1),
(8, 'CIP', 'Carriage and Insurance Paid to, idem CPT, avec assurance marchandise transportée souscrite par le vendeur pour le compte de l''acheteur', 1),
(9, 'DAT', 'Delivered At Terminal, marchandises (déchargées) livrées sur quai, dans un terminal maritime, fluvial, aérien, routier ou ferroviaire désigné (dédouanement import, et post-acheminement payés par l''acheteur)', 1),
(10, 'DAP', 'Delivered At Place, marchandises (non déchargées) mises à disposition de l''acheteur dans le pays d''importation au lieu précisé dans le contrat (déchargement, dédouanement import payé par l''acheteur)', 1),
(11, 'DDP', 'Delivered Duty Paid, marchandises (non déchargées) livrées à destination finale, dédouanement import et taxes à la charge du vendeur ; l''acheteur prend en charge uniquement le déchargement (si exclusion des taxes type TVA, le préciser clairement)', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_input_method`
--

CREATE TABLE `llx_c_input_method` (
  `rowid` int(11) NOT NULL auto_increment,
  `code` varchar(30) collate utf8_unicode_ci default NULL,
  `libelle` varchar(60) collate utf8_unicode_ci default NULL,
  `active` tinyint(4) NOT NULL default '1',
  `module` varchar(32) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_c_input_method` (`code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `llx_c_input_method`
--

INSERT INTO `llx_c_input_method` (`rowid`, `code`, `libelle`, `active`, `module`) VALUES
(1, 'OrderByMail', 'Courrier', 1, NULL),
(2, 'OrderByFax', 'Fax', 1, NULL),
(3, 'OrderByEMail', 'EMail', 1, NULL),
(4, 'OrderByPhone', 'Téléphone', 1, NULL),
(5, 'OrderByWWW', 'En ligne', 1, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_input_reason`
--

CREATE TABLE `llx_c_input_reason` (
  `rowid` int(11) NOT NULL auto_increment,
  `code` varchar(30) collate utf8_unicode_ci default NULL,
  `label` varchar(60) collate utf8_unicode_ci default NULL,
  `active` tinyint(4) NOT NULL default '1',
  `module` varchar(32) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_c_input_reason` (`code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Volcado de datos para la tabla `llx_c_input_reason`
--

INSERT INTO `llx_c_input_reason` (`rowid`, `code`, `label`, `active`, `module`) VALUES
(1, 'SRC_INTE', 'Web site', 1, NULL),
(2, 'SRC_CAMP_MAIL', 'Mailing campaign', 1, NULL),
(3, 'SRC_CAMP_PHO', 'Phone campaign', 1, NULL),
(4, 'SRC_CAMP_FAX', 'Fax campaign', 1, NULL),
(5, 'SRC_COMM', 'Commercial contact', 1, NULL),
(6, 'SRC_SHOP', 'Shop contact', 1, NULL),
(7, 'SRC_CAMP_EMAIL', 'EMailing campaign', 1, NULL),
(8, 'SRC_WOM', 'Word of mouth', 1, NULL),
(9, 'SRC_PARTNER', 'Partner', 1, NULL),
(10, 'SRC_EMPLOYEE', 'Employee', 1, NULL),
(11, 'SRC_SPONSORING', 'Sponsorship', 1, NULL),
(12, 'SRC_CUSTOMER', 'Incoming contact of a customer', 1, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_lead_status`
--

CREATE TABLE `llx_c_lead_status` (
  `rowid` int(11) NOT NULL auto_increment,
  `code` varchar(10) collate utf8_unicode_ci default NULL,
  `label` varchar(50) collate utf8_unicode_ci default NULL,
  `position` int(11) default NULL,
  `percent` double(5,2) default NULL,
  `active` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_c_lead_status_code` (`code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `llx_c_lead_status`
--

INSERT INTO `llx_c_lead_status` (`rowid`, `code`, `label`, `position`, `percent`, `active`) VALUES
(1, 'PROSP', 'Prospection', 10, 0.00, 1),
(2, 'QUAL', 'Qualification', 20, 20.00, 1),
(3, 'PROPO', 'Proposal', 30, 40.00, 1),
(4, 'NEGO', 'Negotiation', 40, 60.00, 1),
(5, 'PENDING', 'Pending', 50, 50.00, 0),
(6, 'WON', 'Won', 60, 100.00, 1),
(7, 'LOST', 'Lost', 70, 0.00, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_paiement`
--

CREATE TABLE `llx_c_paiement` (
  `id` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `code` varchar(6) collate utf8_unicode_ci NOT NULL,
  `libelle` varchar(62) collate utf8_unicode_ci default NULL,
  `type` smallint(6) default NULL,
  `active` tinyint(4) NOT NULL default '1',
  `accountancy_code` varchar(32) collate utf8_unicode_ci default NULL,
  `module` varchar(32) collate utf8_unicode_ci default NULL,
  `position` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `uk_c_paiement_code` (`entity`,`code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=54 ;

--
-- Volcado de datos para la tabla `llx_c_paiement`
--

INSERT INTO `llx_c_paiement` (`id`, `entity`, `code`, `libelle`, `type`, `active`, `accountancy_code`, `module`, `position`) VALUES
(1, 1, 'TIP', 'TIP', 2, 0, NULL, NULL, 0),
(2, 1, 'VIR', 'Transfer', 2, 1, NULL, NULL, 0),
(3, 1, 'PRE', 'Debit order', 2, 1, NULL, NULL, 0),
(4, 1, 'LIQ', 'Cash', 2, 1, NULL, NULL, 0),
(6, 1, 'CB', 'Credit card', 2, 1, NULL, NULL, 0),
(7, 1, 'CHQ', 'Cheque', 2, 1, NULL, NULL, 0),
(50, 1, 'VAD', 'Online payment', 2, 0, NULL, NULL, 0),
(51, 1, 'TRA', 'Traite', 2, 0, NULL, NULL, 0),
(52, 1, 'LCR', 'LCR', 2, 0, NULL, NULL, 0),
(53, 1, 'FAC', 'Factor', 2, 0, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_paper_format`
--

CREATE TABLE `llx_c_paper_format` (
  `rowid` int(11) NOT NULL auto_increment,
  `code` varchar(16) collate utf8_unicode_ci NOT NULL,
  `label` varchar(50) collate utf8_unicode_ci NOT NULL,
  `width` float(6,2) default '0.00',
  `height` float(6,2) default '0.00',
  `unit` varchar(5) collate utf8_unicode_ci NOT NULL,
  `active` tinyint(4) NOT NULL default '1',
  `module` varchar(32) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=226 ;

--
-- Volcado de datos para la tabla `llx_c_paper_format`
--

INSERT INTO `llx_c_paper_format` (`rowid`, `code`, `label`, `width`, `height`, `unit`, `active`, `module`) VALUES
(1, 'EU4A0', 'Format 4A0', 1682.00, 2378.00, 'mm', 1, NULL),
(2, 'EU2A0', 'Format 2A0', 1189.00, 1682.00, 'mm', 1, NULL),
(3, 'EUA0', 'Format A0', 840.00, 1189.00, 'mm', 1, NULL),
(4, 'EUA1', 'Format A1', 594.00, 840.00, 'mm', 1, NULL),
(5, 'EUA2', 'Format A2', 420.00, 594.00, 'mm', 1, NULL),
(6, 'EUA3', 'Format A3', 297.00, 420.00, 'mm', 1, NULL),
(7, 'EUA4', 'Format A4', 210.00, 297.00, 'mm', 1, NULL),
(8, 'EUA5', 'Format A5', 148.00, 210.00, 'mm', 1, NULL),
(9, 'EUA6', 'Format A6', 105.00, 148.00, 'mm', 1, NULL),
(100, 'USLetter', 'Format Letter (A)', 216.00, 279.00, 'mm', 1, NULL),
(105, 'USLegal', 'Format Legal', 216.00, 356.00, 'mm', 1, NULL),
(110, 'USExecutive', 'Format Executive', 190.00, 254.00, 'mm', 1, NULL),
(115, 'USLedger', 'Format Ledger/Tabloid (B)', 279.00, 432.00, 'mm', 1, NULL),
(200, 'CAP1', 'Format Canadian P1', 560.00, 860.00, 'mm', 1, NULL),
(205, 'CAP2', 'Format Canadian P2', 430.00, 560.00, 'mm', 1, NULL),
(210, 'CAP3', 'Format Canadian P3', 280.00, 430.00, 'mm', 1, NULL),
(215, 'CAP4', 'Format Canadian P4', 215.00, 280.00, 'mm', 1, NULL),
(220, 'CAP5', 'Format Canadian P5', 140.00, 215.00, 'mm', 1, NULL),
(225, 'CAP6', 'Format Canadian P6', 107.00, 140.00, 'mm', 1, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_payment_term`
--

CREATE TABLE `llx_c_payment_term` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `code` varchar(16) collate utf8_unicode_ci default NULL,
  `sortorder` smallint(6) default NULL,
  `active` tinyint(4) default '1',
  `libelle` varchar(255) collate utf8_unicode_ci default NULL,
  `libelle_facture` text collate utf8_unicode_ci,
  `type_cdr` tinyint(4) default NULL,
  `nbjour` smallint(6) default NULL,
  `decalage` smallint(6) default NULL,
  `module` varchar(32) collate utf8_unicode_ci default NULL,
  `position` int(11) NOT NULL default '0',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_c_payment_term_code` (`entity`,`code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Volcado de datos para la tabla `llx_c_payment_term`
--

INSERT INTO `llx_c_payment_term` (`rowid`, `entity`, `code`, `sortorder`, `active`, `libelle`, `libelle_facture`, `type_cdr`, `nbjour`, `decalage`, `module`, `position`) VALUES
(1, 1, 'RECEP', 1, 1, 'Due upon receipt', 'Due upon receipt', 0, 1, NULL, NULL, 0),
(2, 1, '30D', 2, 1, '30 days', 'Due in 30 days', 0, 30, NULL, NULL, 0),
(3, 1, '30DENDMONTH', 3, 1, '30 days end of month', 'Due in 30 days, end of month', 1, 30, NULL, NULL, 0),
(4, 1, '60D', 4, 1, '60 days', 'Due in 60 days, end of month', 0, 60, NULL, NULL, 0),
(5, 1, '60DENDMONTH', 5, 1, '60 days end of month', 'Due in 60 days, end of month', 1, 60, NULL, NULL, 0),
(6, 1, 'PT_ORDER', 6, 1, 'Due on order', 'Due on order', 0, 1, NULL, NULL, 0),
(7, 1, 'PT_DELIVERY', 7, 1, 'Due on delivery', 'Due on delivery', 0, 1, NULL, NULL, 0),
(8, 1, 'PT_5050', 8, 1, '50 and 50', '50% on order, 50% on delivery', 0, 1, NULL, NULL, 0),
(9, 1, '10D', 9, 1, '10 days', 'Due in 10 days', 0, 10, NULL, NULL, 0),
(10, 1, '10DENDMONTH', 10, 1, '10 days end of month', 'Due in 10 days, end of month', 1, 10, NULL, NULL, 0),
(11, 1, '14D', 11, 1, '14 days', 'Due in 14 days', 0, 14, NULL, NULL, 0),
(12, 1, '14DENDMONTH', 12, 1, '14 days end of month', 'Due in 14 days, end of month', 1, 14, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_price_expression`
--

CREATE TABLE `llx_c_price_expression` (
  `rowid` int(11) NOT NULL auto_increment,
  `title` varchar(20) collate utf8_unicode_ci NOT NULL,
  `expression` varchar(80) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_price_global_variable`
--

CREATE TABLE `llx_c_price_global_variable` (
  `rowid` int(11) NOT NULL auto_increment,
  `code` varchar(20) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci,
  `value` double(24,8) default '0.00000000',
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_price_global_variable_updater`
--

CREATE TABLE `llx_c_price_global_variable_updater` (
  `rowid` int(11) NOT NULL auto_increment,
  `type` int(11) NOT NULL,
  `description` text collate utf8_unicode_ci,
  `parameters` text collate utf8_unicode_ci,
  `fk_variable` int(11) NOT NULL,
  `update_interval` int(11) default '0',
  `next_update` int(11) default '0',
  `last_status` text collate utf8_unicode_ci,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_propalst`
--

CREATE TABLE `llx_c_propalst` (
  `id` smallint(6) NOT NULL,
  `code` varchar(12) collate utf8_unicode_ci NOT NULL,
  `label` varchar(30) collate utf8_unicode_ci default NULL,
  `active` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `uk_c_propalst` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `llx_c_propalst`
--

INSERT INTO `llx_c_propalst` (`id`, `code`, `label`, `active`) VALUES
(0, 'PR_DRAFT', 'Brouillon', 1),
(1, 'PR_OPEN', 'Ouverte', 1),
(2, 'PR_SIGNED', 'Signée', 1),
(3, 'PR_NOTSIGNED', 'Non Signée', 1),
(4, 'PR_FAC', 'Facturée', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_prospectlevel`
--

CREATE TABLE `llx_c_prospectlevel` (
  `code` varchar(12) collate utf8_unicode_ci NOT NULL,
  `label` varchar(30) collate utf8_unicode_ci default NULL,
  `sortorder` smallint(6) default NULL,
  `active` smallint(6) NOT NULL default '1',
  `module` varchar(32) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `llx_c_prospectlevel`
--

INSERT INTO `llx_c_prospectlevel` (`code`, `label`, `sortorder`, `active`, `module`) VALUES
('PL_HIGH', 'High', 4, 1, NULL),
('PL_LOW', 'Low', 2, 1, NULL),
('PL_MEDIUM', 'Medium', 3, 1, NULL),
('PL_NONE', 'None', 1, 1, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_regions`
--

CREATE TABLE `llx_c_regions` (
  `rowid` int(11) NOT NULL auto_increment,
  `code_region` int(11) NOT NULL,
  `fk_pays` int(11) NOT NULL,
  `cheflieu` varchar(50) collate utf8_unicode_ci default NULL,
  `tncc` int(11) default NULL,
  `nom` varchar(100) collate utf8_unicode_ci default NULL,
  `active` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_code_region` (`code_region`),
  KEY `idx_c_regions_fk_pays` (`fk_pays`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=275 ;

--
-- Volcado de datos para la tabla `llx_c_regions`
--

INSERT INTO `llx_c_regions` (`rowid`, `code_region`, `fk_pays`, `cheflieu`, `tncc`, `nom`, `active`) VALUES
(1, 0, 0, '0', 0, '-', 1),
(2, 1, 1, '97105', 3, 'Guadeloupe', 1),
(3, 2, 1, '97209', 3, 'Martinique', 1),
(4, 3, 1, '97302', 3, 'Guyane', 1),
(5, 4, 1, '97411', 3, 'Réunion', 1),
(6, 6, 1, '97601', 3, 'Mayotte', 1),
(7, 11, 1, '75056', 1, 'Île-de-France', 1),
(8, 21, 1, '51108', 0, 'Champagne-Ardenne', 1),
(9, 22, 1, '80021', 0, 'Picardie', 1),
(10, 23, 1, '76540', 0, 'Haute-Normandie', 1),
(11, 24, 1, '45234', 2, 'Centre', 1),
(12, 25, 1, '14118', 0, 'Basse-Normandie', 1),
(13, 26, 1, '21231', 0, 'Bourgogne', 1),
(14, 31, 1, '59350', 2, 'Nord-Pas-de-Calais', 1),
(15, 41, 1, '57463', 0, 'Lorraine', 1),
(16, 42, 1, '67482', 1, 'Alsace', 1),
(17, 43, 1, '25056', 0, 'Franche-Comté', 1),
(18, 52, 1, '44109', 4, 'Pays de la Loire', 1),
(19, 53, 1, '35238', 0, 'Bretagne', 1),
(20, 54, 1, '86194', 2, 'Poitou-Charentes', 1),
(21, 72, 1, '33063', 1, 'Aquitaine', 1),
(22, 73, 1, '31555', 0, 'Midi-Pyrénées', 1),
(23, 74, 1, '87085', 2, 'Limousin', 1),
(24, 82, 1, '69123', 2, 'Rhône-Alpes', 1),
(25, 83, 1, '63113', 1, 'Auvergne', 1),
(26, 91, 1, '34172', 2, 'Languedoc-Roussillon', 1),
(27, 93, 1, '13055', 0, 'Provence-Alpes-Côte d''Azur', 1),
(28, 94, 1, '2A004', 0, 'Corse', 1),
(29, 4101, 41, '', 0, 'Österreich', 1),
(30, 201, 2, '', 1, 'Flandre', 1),
(31, 202, 2, '', 2, 'Wallonie', 1),
(32, 203, 2, '', 3, 'Bruxelles-Capitale', 1),
(33, 301, 3, NULL, 1, 'Abruzzo', 1),
(34, 302, 3, NULL, 1, 'Basilicata', 1),
(35, 303, 3, NULL, 1, 'Calabria', 1),
(36, 304, 3, NULL, 1, 'Campania', 1),
(37, 305, 3, NULL, 1, 'Emilia-Romagna', 1),
(38, 306, 3, NULL, 1, 'Friuli-Venezia Giulia', 1),
(39, 307, 3, NULL, 1, 'Lazio', 1),
(40, 308, 3, NULL, 1, 'Liguria', 1),
(41, 309, 3, NULL, 1, 'Lombardia', 1),
(42, 310, 3, NULL, 1, 'Marche', 1),
(43, 311, 3, NULL, 1, 'Molise', 1),
(44, 312, 3, NULL, 1, 'Piemonte', 1),
(45, 313, 3, NULL, 1, 'Puglia', 1),
(46, 314, 3, NULL, 1, 'Sardegna', 1),
(47, 315, 3, NULL, 1, 'Sicilia', 1),
(48, 316, 3, NULL, 1, 'Toscana', 1),
(49, 317, 3, NULL, 1, 'Trentino-Alto Adige', 1),
(50, 318, 3, NULL, 1, 'Umbria', 1),
(51, 319, 3, NULL, 1, 'Valle d Aosta', 1),
(52, 320, 3, NULL, 1, 'Veneto', 1),
(53, 401, 4, '', 0, 'Andalucia', 1),
(54, 402, 4, '', 0, 'Aragón', 1),
(55, 403, 4, '', 0, 'Castilla y León', 1),
(56, 404, 4, '', 0, 'Castilla la Mancha', 1),
(57, 405, 4, '', 0, 'Canarias', 1),
(58, 406, 4, '', 0, 'Cataluña', 1),
(59, 407, 4, '', 0, 'Comunidad de Ceuta', 1),
(60, 408, 4, '', 0, 'Comunidad Foral de Navarra', 1),
(61, 409, 4, '', 0, 'Comunidad de Melilla', 1),
(62, 410, 4, '', 0, 'Cantabria', 1),
(63, 411, 4, '', 0, 'Comunidad Valenciana', 1),
(64, 412, 4, '', 0, 'Extemadura', 1),
(65, 413, 4, '', 0, 'Galicia', 1),
(66, 414, 4, '', 0, 'Islas Baleares', 1),
(67, 415, 4, '', 0, 'La Rioja', 1),
(68, 416, 4, '', 0, 'Comunidad de Madrid', 1),
(69, 417, 4, '', 0, 'Región de Murcia', 1),
(70, 418, 4, '', 0, 'Principado de Asturias', 1),
(71, 419, 4, '', 0, 'Pais Vasco', 1),
(72, 420, 4, '', 0, 'Otros', 1),
(73, 501, 5, '', 0, 'Deutschland', 1),
(74, 10201, 102, NULL, NULL, 'Αττική', 1),
(75, 10202, 102, NULL, NULL, 'Στερεά Ελλάδα', 1),
(76, 10203, 102, NULL, NULL, 'Κεντρική Μακεδονία', 1),
(77, 10204, 102, NULL, NULL, 'Κρήτη', 1),
(78, 10205, 102, NULL, NULL, 'Ανατολική Μακεδονία και Θράκη', 1),
(79, 10206, 102, NULL, NULL, 'Ήπειρος', 1),
(80, 10207, 102, NULL, NULL, 'Ιόνια νησιά', 1),
(81, 10208, 102, NULL, NULL, 'Βόρειο Αιγαίο', 1),
(82, 10209, 102, NULL, NULL, 'Πελοπόννησος', 1),
(83, 10210, 102, NULL, NULL, 'Νότιο Αιγαίο', 1),
(84, 10211, 102, NULL, NULL, 'Δυτική Ελλάδα', 1),
(85, 10212, 102, NULL, NULL, 'Θεσσαλία', 1),
(86, 10213, 102, NULL, NULL, 'Δυτική Μακεδονία', 1),
(87, 601, 6, '', 1, 'Cantons', 1),
(88, 701, 7, '', 0, 'England', 1),
(89, 702, 7, '', 0, 'Wales', 1),
(90, 703, 7, '', 0, 'Scotland', 1),
(91, 704, 7, '', 0, 'Northern Ireland', 1),
(92, 1001, 10, '', 0, 'Ariana', 1),
(93, 1002, 10, '', 0, 'Béja', 1),
(94, 1003, 10, '', 0, 'Ben Arous', 1),
(95, 1004, 10, '', 0, 'Bizerte', 1),
(96, 1005, 10, '', 0, 'Gabès', 1),
(97, 1006, 10, '', 0, 'Gafsa', 1),
(98, 1007, 10, '', 0, 'Jendouba', 1),
(99, 1008, 10, '', 0, 'Kairouan', 1),
(100, 1009, 10, '', 0, 'Kasserine', 1),
(101, 1010, 10, '', 0, 'Kébili', 1),
(102, 1011, 10, '', 0, 'La Manouba', 1),
(103, 1012, 10, '', 0, 'Le Kef', 1),
(104, 1013, 10, '', 0, 'Mahdia', 1),
(105, 1014, 10, '', 0, 'Médenine', 1),
(106, 1015, 10, '', 0, 'Monastir', 1),
(107, 1016, 10, '', 0, 'Nabeul', 1),
(108, 1017, 10, '', 0, 'Sfax', 1),
(109, 1018, 10, '', 0, 'Sidi Bouzid', 1),
(110, 1019, 10, '', 0, 'Siliana', 1),
(111, 1020, 10, '', 0, 'Sousse', 1),
(112, 1021, 10, '', 0, 'Tataouine', 1),
(113, 1022, 10, '', 0, 'Tozeur', 1),
(114, 1023, 10, '', 0, 'Tunis', 1),
(115, 1024, 10, '', 0, 'Zaghouan', 1),
(116, 1101, 11, '', 0, 'United-States', 1),
(117, 1301, 13, '', 0, 'Algerie', 1),
(118, 1401, 14, '', 0, 'Canada', 1),
(119, 1701, 17, '', 0, 'Provincies van Nederland ', 1),
(120, 2301, 23, '', 0, 'Norte', 1),
(121, 2302, 23, '', 0, 'Litoral', 1),
(122, 2303, 23, '', 0, 'Cuyana', 1),
(123, 2304, 23, '', 0, 'Central', 1),
(124, 2305, 23, '', 0, 'Patagonia', 1),
(125, 2801, 28, '', 0, 'Australia', 1),
(126, 4601, 46, '', 0, 'Barbados', 1),
(127, 5201, 52, '', 0, 'Chuquisaca', 1),
(128, 5202, 52, '', 0, 'La Paz', 1),
(129, 5203, 52, '', 0, 'Cochabamba', 1),
(130, 5204, 52, '', 0, 'Oruro', 1),
(131, 5205, 52, '', 0, 'Potosí', 1),
(132, 5206, 52, '', 0, 'Tarija', 1),
(133, 5207, 52, '', 0, 'Santa Cruz', 1),
(134, 5208, 52, '', 0, 'El Beni', 1),
(135, 5209, 52, '', 0, 'Pando', 1),
(136, 5601, 56, '', 0, 'Brasil', 1),
(137, 7001, 70, '', 0, 'Colombie', 1),
(138, 6701, 67, NULL, NULL, 'Tarapacá', 1),
(139, 6702, 67, NULL, NULL, 'Antofagasta', 1),
(140, 6703, 67, NULL, NULL, 'Atacama', 1),
(141, 6704, 67, NULL, NULL, 'Coquimbo', 1),
(142, 6705, 67, NULL, NULL, 'Valparaíso', 1),
(143, 6706, 67, NULL, NULL, 'General Bernardo O Higgins', 1),
(144, 6707, 67, NULL, NULL, 'Maule', 1),
(145, 6708, 67, NULL, NULL, 'Biobío', 1),
(146, 6709, 67, NULL, NULL, 'Raucanía', 1),
(147, 6710, 67, NULL, NULL, 'Los Lagos', 1),
(148, 6711, 67, NULL, NULL, 'Aysén General Carlos Ibáñez del Campo', 1),
(149, 6712, 67, NULL, NULL, 'Magallanes y Antártica Chilena', 1),
(150, 6713, 67, NULL, NULL, 'Metropolitana de Santiago', 1),
(151, 6714, 67, NULL, NULL, 'Los Ríos', 1),
(152, 6715, 67, NULL, NULL, 'Arica y Parinacota', 1),
(153, 8601, 86, NULL, NULL, 'Central', 1),
(154, 8602, 86, NULL, NULL, 'Oriental', 1),
(155, 8603, 86, NULL, NULL, 'Occidental', 1),
(156, 11401, 114, '', 0, 'Honduras', 1),
(157, 11701, 117, '', 0, 'India', 1),
(158, 11801, 118, '', 0, 'Indonesia', 1),
(159, 1201, 12, '', 0, 'Tanger-Tétouan', 1),
(160, 1202, 12, '', 0, 'Gharb-Chrarda-Beni Hssen', 1),
(161, 1203, 12, '', 0, 'Taza-Al Hoceima-Taounate', 1),
(162, 1204, 12, '', 0, 'L''Oriental', 1),
(163, 1205, 12, '', 0, 'Fès-Boulemane', 1),
(164, 1206, 12, '', 0, 'Meknès-Tafialet', 1),
(165, 1207, 12, '', 0, 'Rabat-Salé-Zemour-Zaër', 1),
(166, 1208, 12, '', 0, 'Grand Cassablanca', 1),
(167, 1209, 12, '', 0, 'Chaouia-Ouardigha', 1),
(168, 1210, 12, '', 0, 'Doukahla-Adba', 1),
(169, 1211, 12, '', 0, 'Marrakech-Tensift-Al Haouz', 1),
(170, 1212, 12, '', 0, 'Tadla-Azilal', 1),
(171, 1213, 12, '', 0, 'Sous-Massa-Drâa', 1),
(172, 1214, 12, '', 0, 'Guelmim-Es Smara', 1),
(173, 1215, 12, '', 0, 'Laâyoune-Boujdour-Sakia el Hamra', 1),
(174, 1216, 12, '', 0, 'Oued Ed-Dahab Lagouira', 1),
(175, 14001, 140, '', 0, 'Diekirch', 1),
(176, 14002, 140, '', 0, 'Grevenmacher', 1),
(177, 14003, 140, '', 0, 'Luxembourg', 1),
(178, 15201, 152, '', 0, 'Rivière Noire', 1),
(179, 15202, 152, '', 0, 'Flacq', 1),
(180, 15203, 152, '', 0, 'Grand Port', 1),
(181, 15204, 152, '', 0, 'Moka', 1),
(182, 15205, 152, '', 0, 'Pamplemousses', 1),
(183, 15206, 152, '', 0, 'Plaines Wilhems', 1),
(184, 15207, 152, '', 0, 'Port-Louis', 1),
(185, 15208, 152, '', 0, 'Rivière du Rempart', 1),
(186, 15209, 152, '', 0, 'Savanne', 1),
(187, 15210, 152, '', 0, 'Rodrigues', 1),
(188, 15211, 152, '', 0, 'Les îles Agaléga', 1),
(189, 15212, 152, '', 0, 'Les écueils des Cargados Carajos', 1),
(190, 15401, 154, '', 0, 'Mexique', 1),
(191, 18801, 188, '', 0, 'Romania', 1),
(192, 23201, 232, '', 0, 'Los Andes', 1),
(193, 23202, 232, '', 0, 'Capital', 1),
(194, 23203, 232, '', 0, 'Central', 1),
(195, 23204, 232, '', 0, 'Cento Occidental', 1),
(196, 23205, 232, '', 0, 'Guayana', 1),
(197, 23206, 232, '', 0, 'Insular', 1),
(198, 23207, 232, '', 0, 'Los Llanos', 1),
(199, 23208, 232, '', 0, 'Nor-Oriental', 1),
(200, 23209, 232, '', 0, 'Zuliana', 1),
(201, 18101, 181, '', 0, 'Amazonas', 1),
(202, 18102, 181, '', 0, 'Ancash', 1),
(203, 18103, 181, '', 0, 'Apurimac', 1),
(204, 18104, 181, '', 0, 'Arequipa', 1),
(205, 18105, 181, '', 0, 'Ayacucho', 1),
(206, 18106, 181, '', 0, 'Cajamarca', 1),
(207, 18107, 181, '', 0, 'Callao', 1),
(208, 18108, 181, '', 0, 'Cuzco', 1),
(209, 18109, 181, '', 0, 'Huancavelica', 1),
(210, 18110, 181, '', 0, 'Huanuco', 1),
(211, 18111, 181, '', 0, 'Ica', 1),
(212, 18112, 181, '', 0, 'Junin', 1),
(213, 18113, 181, '', 0, 'La Libertad', 1),
(214, 18114, 181, '', 0, 'Lambayeque', 1),
(215, 18115, 181, '', 0, 'Lima Metropolitana', 1),
(216, 18116, 181, '', 0, 'Lima', 1),
(217, 18117, 181, '', 0, 'Loreto', 1),
(218, 18118, 181, '', 0, 'Madre de Dios', 1),
(219, 18119, 181, '', 0, 'Moquegua', 1),
(220, 18120, 181, '', 0, 'Pasco', 1),
(221, 18121, 181, '', 0, 'Piura', 1),
(222, 18122, 181, '', 0, 'Puno', 1),
(223, 18123, 181, '', 0, 'San Martín', 1),
(224, 18124, 181, '', 0, 'Tacna', 1),
(225, 18125, 181, '', 0, 'Tumbes', 1),
(226, 18126, 181, '', 0, 'Ucayali', 1),
(227, 17801, 178, '', 0, 'Panama', 1),
(228, 22701, 227, '', 0, 'United Arab Emirates', 1),
(229, 34000, 34, 'AD', NULL, 'Andorra', 1),
(230, 183100, 18, 'HU31', NULL, 'Northern Hungary', 1),
(231, 183200, 18, 'HU32', NULL, 'Northern Great Plain', 1),
(232, 183300, 18, 'HU33', NULL, 'Southern Great Plain', 1),
(233, 180100, 18, 'HU1', NULL, 'Central Hungary', 1),
(234, 182100, 18, 'HU21', NULL, 'Central Transdanubia', 1),
(235, 182200, 18, 'HU22', NULL, 'Western Transdanubia', 1),
(236, 182300, 18, 'HU23', NULL, 'Southern Transdanubia', 1),
(237, 15001, 25, 'PT', NULL, 'Portugal', 1),
(238, 15002, 25, 'PT9', NULL, 'Azores-Madeira', 1),
(239, 20203, 202, 'SI03', NULL, 'East Slovenia', 1),
(240, 20204, 202, 'SI04', NULL, 'West Slovenia', 1),
(241, 901, 9, '京', 0, '北京市', 1),
(242, 902, 9, '津', 0, '天津市', 1),
(243, 903, 9, '沪', 0, '上海市', 1),
(244, 904, 9, '渝', 0, '重庆市', 1),
(245, 905, 9, '冀', 0, '河北省', 1),
(246, 906, 9, '晋', 0, '山西省', 1),
(247, 907, 9, '辽', 0, '辽宁省', 1),
(248, 908, 9, '吉', 0, '吉林省', 1),
(249, 909, 9, '黑', 0, '黑龙江省', 1),
(250, 910, 9, '苏', 0, '江苏省', 1),
(251, 911, 9, '浙', 0, '浙江省', 1),
(252, 912, 9, '皖', 0, '安徽省', 1),
(253, 913, 9, '闽', 0, '福建省', 1),
(254, 914, 9, '赣', 0, '江西省', 1),
(255, 915, 9, '鲁', 0, '山东省', 1),
(256, 916, 9, '豫', 0, '河南省', 1),
(257, 917, 9, '鄂', 0, '湖北省', 1),
(258, 918, 9, '湘', 0, '湖南省', 1),
(259, 919, 9, '粤', 0, '广东省', 1),
(260, 920, 9, '琼', 0, '海南省', 1),
(261, 921, 9, '川', 0, '四川省', 1),
(262, 922, 9, '贵', 0, '贵州省', 1),
(263, 923, 9, '云', 0, '云南省', 1),
(264, 924, 9, '陕', 0, '陕西省', 1),
(265, 925, 9, '甘', 0, '甘肃省', 1),
(266, 926, 9, '青', 0, '青海省', 1),
(267, 927, 9, '台', 0, '台湾省', 1),
(268, 928, 9, '蒙', 0, '内蒙古自治区', 1),
(269, 929, 9, '桂', 0, '广西壮族自治区', 1),
(270, 930, 9, '藏', 0, '西藏自治区', 1),
(271, 931, 9, '宁', 0, '宁夏回族自治区', 1),
(272, 932, 9, '新', 0, '新疆维吾尔自治区', 1),
(273, 933, 9, '港', 0, '香港特别行政区', 1),
(274, 934, 9, '澳', 0, '澳门特别行政区', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_revenuestamp`
--

CREATE TABLE `llx_c_revenuestamp` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_pays` int(11) NOT NULL,
  `taux` double NOT NULL,
  `revenuestamp_type` varchar(16) collate utf8_unicode_ci NOT NULL default 'fixed',
  `note` varchar(128) collate utf8_unicode_ci default NULL,
  `active` tinyint(4) NOT NULL default '1',
  `accountancy_code_sell` varchar(32) collate utf8_unicode_ci default NULL,
  `accountancy_code_buy` varchar(32) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1543 ;

--
-- Volcado de datos para la tabla `llx_c_revenuestamp`
--

INSERT INTO `llx_c_revenuestamp` (`rowid`, `fk_pays`, `taux`, `revenuestamp_type`, `note`, `active`, `accountancy_code_sell`, `accountancy_code_buy`) VALUES
(101, 10, 0.4, 'fixed', 'Revenue stamp tunisia', 1, NULL, NULL),
(1541, 154, 1.5, 'percent', 'Revenue stamp mexico', 1, NULL, NULL),
(1542, 154, 3, 'percent', 'Revenue stamp mexico', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_shipment_mode`
--

CREATE TABLE `llx_c_shipment_mode` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `code` varchar(30) collate utf8_unicode_ci NOT NULL,
  `libelle` varchar(50) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci,
  `tracking` varchar(255) collate utf8_unicode_ci default NULL,
  `active` tinyint(4) default '0',
  `module` varchar(32) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_c_shipment_mode` (`code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Volcado de datos para la tabla `llx_c_shipment_mode`
--

INSERT INTO `llx_c_shipment_mode` (`rowid`, `tms`, `code`, `libelle`, `description`, `tracking`, `active`, `module`) VALUES
(1, '2019-07-29 16:24:46', 'CATCH', 'In-Store Collection', 'In-store collection by the customer', '', 1, NULL),
(2, '2019-07-29 16:24:46', 'TRANS', 'Courier Service', 'Courier Service', '', 1, NULL),
(3, '2019-07-29 16:24:46', 'COLSUI', 'Colissimo Suivi', 'Colissimo Suivi', 'https://www.laposte.fr/outils/suivre-vos-envois?code={TRACKID}', 0, NULL),
(4, '2019-07-29 16:24:46', 'LETTREMAX', 'Lettre Max', 'Courrier Suivi et Lettre Max', 'https://www.laposte.fr/outils/suivre-vos-envois?code={TRACKID}', 0, NULL),
(5, '2019-07-29 16:24:46', 'UPS', 'UPS', 'United Parcel Service', 'http://wwwapps.ups.com/etracking/tracking.cgi?InquiryNumber2=&InquiryNumber3=&tracknums_displayed=3&loc=fr_FR&TypeOfInquiryNumber=T&HTMLVersion=4.0&InquiryNumber22=&InquiryNumber32=&track=Track&Suivi.x=64&Suivi.y=7&Suivi=Valider&InquiryNumber1={TRACKID}', 0, NULL),
(6, '2019-07-29 16:24:46', 'KIALA', 'KIALA', 'Relais Kiala', 'http://www.kiala.fr/tnt/delivery/{TRACKID}', 0, NULL),
(7, '2019-07-29 16:24:46', 'GLS', 'GLS', 'General Logistics Systems', 'https://gls-group.eu/FR/fr/suivi-colis?match={TRACKID}', 0, NULL),
(8, '2019-07-29 16:24:46', 'CHRONO', 'Chronopost', 'Chronopost', 'http://www.chronopost.fr/expedier/inputLTNumbersNoJahia.do?listeNumeros={TRACKID}', 0, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_stcomm`
--

CREATE TABLE `llx_c_stcomm` (
  `id` int(11) NOT NULL,
  `code` varchar(12) collate utf8_unicode_ci NOT NULL,
  `libelle` varchar(30) collate utf8_unicode_ci default NULL,
  `picto` varchar(128) collate utf8_unicode_ci default NULL,
  `active` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `uk_c_stcomm` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `llx_c_stcomm`
--

INSERT INTO `llx_c_stcomm` (`id`, `code`, `libelle`, `picto`, `active`) VALUES
(-1, 'ST_NO', 'Do not contact', NULL, 1),
(0, 'ST_NEVER', 'Never contacted', NULL, 1),
(1, 'ST_TODO', 'To contact', NULL, 1),
(2, 'ST_PEND', 'Contact in progress', NULL, 1),
(3, 'ST_DONE', 'Contacted', NULL, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_ticket_category`
--

CREATE TABLE `llx_c_ticket_category` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) default '1',
  `code` varchar(32) collate utf8_unicode_ci NOT NULL,
  `pos` varchar(32) collate utf8_unicode_ci NOT NULL,
  `label` varchar(128) collate utf8_unicode_ci NOT NULL,
  `active` int(11) default '1',
  `use_default` int(11) default '1',
  `description` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_code` (`code`,`entity`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `llx_c_ticket_category`
--

INSERT INTO `llx_c_ticket_category` (`rowid`, `entity`, `code`, `pos`, `label`, `active`, `use_default`, `description`) VALUES
(1, 1, 'OTHER', '10', 'Other', 1, 1, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_ticket_severity`
--

CREATE TABLE `llx_c_ticket_severity` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) default '1',
  `code` varchar(32) collate utf8_unicode_ci NOT NULL,
  `pos` varchar(32) collate utf8_unicode_ci NOT NULL,
  `label` varchar(128) collate utf8_unicode_ci NOT NULL,
  `color` varchar(10) collate utf8_unicode_ci NOT NULL,
  `active` int(11) default '1',
  `use_default` int(11) default '1',
  `description` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_code` (`code`,`entity`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `llx_c_ticket_severity`
--

INSERT INTO `llx_c_ticket_severity` (`rowid`, `entity`, `code`, `pos`, `label`, `color`, `active`, `use_default`, `description`) VALUES
(1, 1, 'LOW', '10', 'Low', '', 1, 0, NULL),
(2, 1, 'NORMAL', '20', 'Normal', '', 1, 1, NULL),
(3, 1, 'HIGH', '30', 'High', '', 1, 0, NULL),
(4, 1, 'BLOCKING', '40', 'Critical / blocking', '', 1, 0, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_ticket_type`
--

CREATE TABLE `llx_c_ticket_type` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) default '1',
  `code` varchar(32) collate utf8_unicode_ci NOT NULL,
  `pos` varchar(32) collate utf8_unicode_ci NOT NULL,
  `label` varchar(128) collate utf8_unicode_ci NOT NULL,
  `active` int(11) default '1',
  `use_default` int(11) default '1',
  `description` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_code` (`code`,`entity`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `llx_c_ticket_type`
--

INSERT INTO `llx_c_ticket_type` (`rowid`, `entity`, `code`, `pos`, `label`, `active`, `use_default`, `description`) VALUES
(1, 1, 'COM', '10', 'Commercial question', 1, 1, NULL),
(2, 1, 'ISSUE', '20', 'Issue or problem', 1, 0, NULL),
(3, 1, 'REQUEST', '25', 'Change or enhancement request', 1, 0, NULL),
(4, 1, 'PROJECT', '30', 'Project', 0, 0, NULL),
(5, 1, 'OTHER', '40', 'Other', 1, 0, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_tva`
--

CREATE TABLE `llx_c_tva` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_pays` int(11) NOT NULL,
  `code` varchar(10) collate utf8_unicode_ci default '',
  `taux` double NOT NULL,
  `localtax1` varchar(20) collate utf8_unicode_ci NOT NULL default '0',
  `localtax1_type` varchar(10) collate utf8_unicode_ci NOT NULL default '0',
  `localtax2` varchar(20) collate utf8_unicode_ci NOT NULL default '0',
  `localtax2_type` varchar(10) collate utf8_unicode_ci NOT NULL default '0',
  `recuperableonly` int(11) NOT NULL default '0',
  `note` varchar(128) collate utf8_unicode_ci default NULL,
  `active` tinyint(4) NOT NULL default '1',
  `accountancy_code_sell` varchar(32) collate utf8_unicode_ci default NULL,
  `accountancy_code_buy` varchar(32) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_c_tva_id` (`fk_pays`,`code`,`taux`,`recuperableonly`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2469 ;

--
-- Volcado de datos para la tabla `llx_c_tva`
--

INSERT INTO `llx_c_tva` (`rowid`, `fk_pays`, `code`, `taux`, `localtax1`, `localtax1_type`, `localtax2`, `localtax2_type`, `recuperableonly`, `note`, `active`, `accountancy_code_sell`, `accountancy_code_buy`) VALUES
(11, 1, '', 20, '0', '0', '0', '0', 0, 'VAT standard rate (France hors DOM-TOM)', 1, NULL, NULL),
(14, 1, '', 5.5, '0', '0', '0', '0', 0, 'VAT reduced rate (France hors DOM-TOM)', 1, NULL, NULL),
(15, 1, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0 ou non applicable', 1, NULL, NULL),
(16, 1, '', 2.1, '0', '0', '0', '0', 0, 'VAT super-reduced rate', 1, NULL, NULL),
(17, 1, '', 10, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(21, 2, '', 21, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(22, 2, '', 6, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(23, 2, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0 ou non applicable', 1, NULL, NULL),
(24, 2, '', 12, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(31, 3, '', 22, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(32, 3, '', 10, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(33, 3, '', 4, '0', '0', '0', '0', 0, 'VAT super-reduced rate', 1, NULL, NULL),
(34, 3, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(41, 4, '', 21, '5.2', '3', '-19:-15:-9', '5', 0, 'VAT standard rate', 1, NULL, NULL),
(42, 4, '', 10, '1.4', '3', '-19:-15:-9', '5', 0, 'VAT reduced rate', 1, NULL, NULL),
(43, 4, '', 4, '0.5', '3', '-19:-15:-9', '5', 0, 'VAT super-reduced rate', 1, NULL, NULL),
(44, 4, '', 0, '0', '3', '-19:-15:-9', '5', 0, 'VAT Rate 0', 1, NULL, NULL),
(51, 5, '', 19, '0', '0', '0', '0', 0, 'allgemeine Ust.', 1, NULL, NULL),
(52, 5, '', 7, '0', '0', '0', '0', 0, 'ermäßigte USt.', 1, NULL, NULL),
(53, 5, '', 0, '0', '0', '0', '0', 0, 'keine USt.', 1, NULL, NULL),
(54, 5, '', 5.5, '0', '0', '0', '0', 0, 'USt. Forst', 0, NULL, NULL),
(55, 5, '', 10.7, '0', '0', '0', '0', 0, 'USt. Landwirtschaft', 0, NULL, NULL),
(61, 6, '', 7.7, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(62, 6, '', 3.7, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(63, 6, '', 2.5, '0', '0', '0', '0', 0, 'VAT super-reduced rate', 1, NULL, NULL),
(64, 6, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(71, 7, '', 20, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(72, 7, '', 17.5, '0', '0', '0', '0', 0, 'VAT standard rate before 2011', 1, NULL, NULL),
(73, 7, '', 5, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(74, 7, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(81, 8, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(82, 8, '', 23, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(83, 8, '', 13.5, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(84, 8, '', 9, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(85, 8, '', 4.8, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(91, 9, '', 17, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(92, 9, '', 13, '0', '0', '0', '0', 0, 'VAT reduced rate 0', 1, NULL, NULL),
(93, 9, '', 3, '0', '0', '0', '0', 0, 'VAT super reduced rate 0', 1, NULL, NULL),
(94, 9, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(101, 10, '', 6, '1', '4', '0', '0', 0, 'VAT 6%', 1, NULL, NULL),
(102, 10, '', 12, '1', '4', '0', '0', 0, 'VAT 12%', 1, NULL, NULL),
(103, 10, '', 18, '1', '4', '0', '0', 0, 'VAT 18%', 1, NULL, NULL),
(104, 10, '', 7.5, '1', '4', '0', '0', 0, 'VAT 6% Majoré à 25% (7.5%)', 1, NULL, NULL),
(105, 10, '', 15, '1', '4', '0', '0', 0, 'VAT 12% Majoré à 25% (15%)', 1, NULL, NULL),
(106, 10, '', 22.5, '1', '4', '0', '0', 0, 'VAT 18% Majoré à 25% (22.5%)', 1, NULL, NULL),
(107, 10, '', 0, '1', '4', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(111, 11, '', 0, '0', '0', '0', '0', 0, 'No Sales Tax', 1, NULL, NULL),
(112, 11, '', 4, '0', '0', '0', '0', 0, 'Sales Tax 4%', 1, NULL, NULL),
(113, 11, '', 6, '0', '0', '0', '0', 0, 'Sales Tax 6%', 1, NULL, NULL),
(121, 12, '', 20, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(122, 12, '', 14, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(123, 12, '', 10, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(124, 12, '', 7, '0', '0', '0', '0', 0, 'VAT super-reduced rate', 1, NULL, NULL),
(125, 12, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(141, 14, '', 7, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(142, 14, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(143, 14, '', 5, '9.975', '1', '0', '0', 0, 'GST/TPS and PST/TVQ rate for Province', 1, NULL, NULL),
(171, 17, '', 19, '0', '0', '0', '0', 0, 'Algemeen BTW tarief', 1, NULL, NULL),
(172, 17, '', 6, '0', '0', '0', '0', 0, 'Verlaagd BTW tarief', 1, NULL, NULL),
(173, 17, '', 0, '0', '0', '0', '0', 0, '0 BTW tarief', 1, NULL, NULL),
(174, 17, '', 21, '0', '0', '0', '0', 0, 'Algemeen BTW tarief (vanaf 1 oktober 2012)', 0, NULL, NULL),
(201, 20, '', 25, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(202, 20, '', 12, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(203, 20, '', 6, '0', '0', '0', '0', 0, 'VAT super-reduced rate', 1, NULL, NULL),
(204, 20, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(211, 21, '', 0, '0', '0', '0', '0', 0, 'IVA Rate 0', 1, NULL, NULL),
(212, 21, '', 18, '7.5', '2', '0', '0', 0, 'IVA standard rate', 1, NULL, NULL),
(221, 22, '', 18, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(222, 22, '', 10, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(223, 22, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(231, 23, '', 21, '0', '0', '0', '0', 0, 'IVA standard rate', 1, NULL, NULL),
(232, 23, '', 10.5, '0', '0', '0', '0', 0, 'IVA reduced rate', 1, NULL, NULL),
(233, 23, '', 0, '0', '0', '0', '0', 0, 'IVA Rate 0', 1, NULL, NULL),
(241, 24, '', 19.25, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(242, 24, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(251, 25, '', 23, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(252, 25, '', 13, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(253, 25, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(254, 25, '', 6, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(261, 26, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(262, 26, '', 5, '0', '0', '0', '0', 0, 'VAT Rate 5', 1, NULL, NULL),
(271, 27, '', 19.6, '0', '0', '0', '0', 0, 'VAT standard rate (France hors DOM-TOM)', 1, NULL, NULL),
(272, 27, '', 8.5, '0', '0', '0', '0', 0, 'VAT standard rate (DOM sauf Guyane et Saint-Martin)', 0, NULL, NULL),
(273, 27, '', 8.5, '0', '0', '0', '0', 1, 'VAT standard rate (DOM sauf Guyane et Saint-Martin), non perçu par le vendeur mais récupérable par acheteur', 0, NULL, NULL),
(274, 27, '', 5.5, '0', '0', '0', '0', 0, 'VAT reduced rate (France hors DOM-TOM)', 0, NULL, NULL),
(275, 27, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0 ou non applicable', 1, NULL, NULL),
(276, 27, '', 2.1, '0', '0', '0', '0', 0, 'VAT super-reduced rate', 1, NULL, NULL),
(277, 27, '', 7, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(281, 28, '', 10, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(282, 28, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(411, 41, '', 20, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(412, 41, '', 10, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(413, 41, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(461, 46, '', 0, '0', '0', '0', '0', 0, 'No VAT', 1, NULL, NULL),
(462, 46, '', 15, '0', '0', '0', '0', 0, 'VAT 15%', 1, NULL, NULL),
(463, 46, '', 7.5, '0', '0', '0', '0', 0, 'VAT 7.5%', 1, NULL, NULL),
(561, 56, '', 0, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(591, 59, '', 20, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(592, 59, '', 7, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(593, 59, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(671, 67, '', 19, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(672, 67, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(781, 78, '', 19, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(782, 78, '', 9, '0', '0', '0', '0', 0, 'VAT Rate 9', 1, NULL, NULL),
(783, 78, '', 5, '0', '0', '0', '0', 0, 'VAT Rate 5', 1, NULL, NULL),
(784, 78, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(801, 80, '', 25, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(802, 80, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(803, 1, '85', 8.5, '0', '0', '0', '0', 0, 'VAT standard rate (DOM sauf Guyane et Saint-Martin)', 0, NULL, NULL),
(804, 1, '85NPR', 8.5, '0', '0', '0', '0', 1, 'VAT standard rate (DOM sauf Guyane et Saint-Martin), non perçu par le vendeur mais récupérable par acheteur', 0, NULL, NULL),
(805, 1, '85NPROM', 8.5, '2', '3', '0', '0', 1, 'VAT standard rate (DOM sauf Guyane et Saint-Martin), NPR, Octroi de Mer', 0, NULL, NULL),
(806, 1, '85NPROMOMR', 8.5, '2', '3', '2.5', '3', 1, 'VAT standard rate (DOM sauf Guyane et Saint-Martin), NPR, Octroi de Mer et Octroi de Mer Regional', 0, NULL, NULL),
(861, 86, '', 13, '0', '0', '0', '0', 0, 'IVA 13', 1, NULL, NULL),
(862, 86, '', 0, '0', '0', '0', '0', 0, 'SIN IVA', 1, NULL, NULL),
(1141, 114, '', 0, '0', '0', '0', '0', 0, 'No ISV', 1, NULL, NULL),
(1142, 114, '', 12, '0', '0', '0', '0', 0, 'ISV 12%', 1, NULL, NULL),
(1161, 116, '', 25.5, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(1162, 116, '', 7, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(1163, 116, '', 0, '0', '0', '0', '0', 0, 'VAT rate 0', 1, NULL, NULL),
(1171, 117, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 0, NULL, NULL),
(1176, 117, 'C+S-18', 0, '9', '1', '9', '1', 0, 'CGST+SGST - Same state sales', 1, NULL, NULL),
(1177, 117, 'I-18', 18, '0', '0', '0', '0', 0, 'IGST', 1, NULL, NULL),
(1178, 117, 'C+S-5', 0, '2.5', '1', '2.5', '1', 0, 'CGST+SGST - Same state sales', 1, NULL, NULL),
(1179, 117, 'I-5', 5, '0', '0', '0', '0', 0, 'IGST', 1, NULL, NULL),
(1180, 117, 'C+S-12', 0, '6', '1', '6', '1', 0, 'CGST+SGST - Same state sales', 1, NULL, NULL),
(1181, 117, 'I-12', 12, '0', '0', '0', '0', 0, 'IGST', 1, NULL, NULL),
(1182, 117, 'C+S-28', 0, '14', '1', '14', '1', 0, 'CGST+SGST - Same state sales', 1, NULL, NULL),
(1183, 117, 'I-28', 28, '0', '0', '0', '0', 0, 'IGST', 1, NULL, NULL),
(1231, 123, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(1232, 123, '', 5, '0', '0', '0', '0', 0, 'VAT Rate 5', 1, NULL, NULL),
(1401, 140, '', 17, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(1402, 140, '', 14, '0', '0', '0', '0', 0, 'VAT intermediary rate', 1, NULL, NULL),
(1403, 140, '', 8, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(1404, 140, '', 3, '0', '0', '0', '0', 0, 'VAT super-reduced rate', 1, NULL, NULL),
(1405, 140, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(1481, 148, '', 18, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(1482, 148, '', 7, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(1483, 148, '', 5, '0', '0', '0', '0', 0, 'VAT super-reduced rate', 1, NULL, NULL),
(1484, 148, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(1511, 151, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(1512, 151, '', 14, '0', '0', '0', '0', 0, 'VAT Rate 14', 1, NULL, NULL),
(1521, 152, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(1522, 152, '', 15, '0', '0', '0', '0', 0, 'VAT Rate 15', 1, NULL, NULL),
(1541, 154, '', 0, '0', '0', '0', '0', 0, 'No VAT', 1, NULL, NULL),
(1542, 154, '', 16, '0', '0', '0', '0', 0, 'VAT 16%', 1, NULL, NULL),
(1543, 154, '', 10, '0', '0', '0', '0', 0, 'VAT Frontero', 1, NULL, NULL),
(1662, 166, '', 15, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(1663, 166, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(1692, 169, '', 5, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(1693, 169, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(1731, 173, '', 25, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(1732, 173, '', 14, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(1733, 173, '', 8, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(1734, 173, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(1781, 178, '', 7, '0', '0', '0', '0', 0, 'ITBMS standard rate', 1, NULL, NULL),
(1782, 178, '', 0, '0', '0', '0', '0', 0, 'ITBMS Rate 0', 1, NULL, NULL),
(1811, 181, '', 18, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(1812, 181, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(1841, 184, '', 23, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(1842, 184, '', 8, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(1843, 184, '', 3, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(1844, 184, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(1881, 188, '', 19, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(1882, 188, '', 9, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(1883, 188, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(1884, 188, '', 5, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(1931, 193, '', 0, '0', '0', '0', '0', 0, 'No VAT in SPM', 1, NULL, NULL),
(2011, 201, '', 19, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(2012, 201, '', 10, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(2013, 201, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(2021, 202, '', 22, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(2022, 202, '', 9.5, '0', '0', '0', '0', 0, 'VAT reduced rate', 1, NULL, NULL),
(2023, 202, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(2051, 205, '', 15, '0', '0', '0', '0', 0, 'VAT standard rate', 1, NULL, NULL),
(2052, 205, '', 14, '0', '0', '0', '0', 0, 'VAT 14%', 1, NULL, NULL),
(2053, 205, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(2071, 207, '', 0, '0', '0', '0', '0', 0, 'VAT 0', 1, NULL, NULL),
(2072, 207, '', 15, '0', '0', '0', '0', 0, 'VAT 15%', 1, NULL, NULL),
(2131, 213, '', 5, '0', '0', '0', '0', 0, 'VAT 5%', 1, NULL, NULL),
(2132, 213, '', 0, '0', '0', '0', '0', 0, 'VAT 0', 1, NULL, NULL),
(2261, 226, '', 20, '0', '0', '0', '0', 0, 'VAT standart rate', 1, NULL, NULL),
(2262, 226, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(2321, 232, '', 0, '0', '0', '0', '0', 0, 'No VAT', 1, NULL, NULL),
(2322, 232, '', 12, '0', '0', '0', '0', 0, 'VAT 12%', 1, NULL, NULL),
(2323, 232, '', 8, '0', '0', '0', '0', 0, 'VAT 8%', 1, NULL, NULL),
(2461, 246, '', 0, '0', '0', '0', '0', 0, 'VAT Rate 0', 1, NULL, NULL),
(2462, 102, '', 24, '0', '0', '0', '0', 0, 'Κανονικός Φ.Π.Α.', 1, NULL, NULL),
(2463, 102, '', 0, '0', '0', '0', '0', 0, 'Μηδενικό Φ.Π.Α.', 1, NULL, NULL),
(2464, 102, '', 13, '0', '0', '0', '0', 0, 'Μειωμένος Φ.Π.Α.', 1, NULL, NULL),
(2465, 102, '', 6.5, '0', '0', '0', '0', 0, 'Υπερμειωμένος Φ.Π.Α.', 1, NULL, NULL),
(2466, 102, '', 16, '0', '0', '0', '0', 0, 'Νήσων κανονικός Φ.Π.Α.', 1, NULL, NULL),
(2467, 102, '', 9, '0', '0', '0', '0', 0, 'Νήσων μειωμένος Φ.Π.Α.', 1, NULL, NULL),
(2468, 102, '', 5, '0', '0', '0', '0', 0, 'Νήσων υπερμειωμένος Φ.Π.Α.', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_typent`
--

CREATE TABLE `llx_c_typent` (
  `id` int(11) NOT NULL,
  `code` varchar(12) collate utf8_unicode_ci NOT NULL,
  `libelle` varchar(64) collate utf8_unicode_ci default NULL,
  `fk_country` int(11) default NULL,
  `active` tinyint(4) NOT NULL default '1',
  `module` varchar(32) collate utf8_unicode_ci default NULL,
  `position` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `uk_c_typent` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `llx_c_typent`
--

INSERT INTO `llx_c_typent` (`id`, `code`, `libelle`, `fk_country`, `active`, `module`, `position`) VALUES
(0, 'TE_UNKNOWN', '-', NULL, 1, NULL, 0),
(1, 'TE_STARTUP', 'Start-up', NULL, 0, NULL, 0),
(2, 'TE_GROUP', 'Grand groupe', NULL, 1, NULL, 0),
(3, 'TE_MEDIUM', 'PME/PMI', NULL, 1, NULL, 0),
(4, 'TE_SMALL', 'TPE', NULL, 1, NULL, 0),
(5, 'TE_ADMIN', 'Administration', NULL, 1, NULL, 0),
(6, 'TE_WHOLE', 'Grossiste', NULL, 0, NULL, 0),
(7, 'TE_RETAIL', 'Revendeur', NULL, 0, NULL, 0),
(8, 'TE_PRIVATE', 'Particulier', NULL, 1, NULL, 0),
(100, 'TE_OTHER', 'Autres', NULL, 1, NULL, 0),
(231, 'TE_A_RI', 'Responsable Inscripto (typo A)', 23, 0, NULL, 0),
(232, 'TE_B_RNI', 'Responsable No Inscripto (typo B)', 23, 0, NULL, 0),
(233, 'TE_C_FE', 'Consumidor Final/Exento (typo C)', 23, 0, NULL, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_type_contact`
--

CREATE TABLE `llx_c_type_contact` (
  `rowid` int(11) NOT NULL,
  `element` varchar(30) collate utf8_unicode_ci NOT NULL,
  `source` varchar(8) collate utf8_unicode_ci NOT NULL default 'external',
  `code` varchar(32) collate utf8_unicode_ci NOT NULL,
  `libelle` varchar(64) collate utf8_unicode_ci NOT NULL,
  `active` tinyint(4) NOT NULL default '1',
  `module` varchar(32) collate utf8_unicode_ci default NULL,
  `position` int(11) NOT NULL default '0',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_c_type_contact_id` (`element`,`source`,`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `llx_c_type_contact`
--

INSERT INTO `llx_c_type_contact` (`rowid`, `element`, `source`, `code`, `libelle`, `active`, `module`, `position`) VALUES
(10, 'contrat', 'internal', 'SALESREPSIGN', 'Commercial signataire du contrat', 1, NULL, 0),
(11, 'contrat', 'internal', 'SALESREPFOLL', 'Commercial suivi du contrat', 1, NULL, 0),
(20, 'contrat', 'external', 'BILLING', 'Contact client facturation contrat', 1, NULL, 0),
(21, 'contrat', 'external', 'CUSTOMER', 'Contact client suivi contrat', 1, NULL, 0),
(22, 'contrat', 'external', 'SALESREPSIGN', 'Contact client signataire contrat', 1, NULL, 0),
(31, 'propal', 'internal', 'SALESREPFOLL', 'Commercial à l''origine de la propale', 1, NULL, 0),
(40, 'propal', 'external', 'BILLING', 'Contact client facturation propale', 1, NULL, 0),
(41, 'propal', 'external', 'CUSTOMER', 'Contact client suivi propale', 1, NULL, 0),
(42, 'propal', 'external', 'SHIPPING', 'Contact client livraison propale', 1, NULL, 0),
(50, 'facture', 'internal', 'SALESREPFOLL', 'Responsable suivi du paiement', 1, NULL, 0),
(60, 'facture', 'external', 'BILLING', 'Contact client facturation', 1, NULL, 0),
(61, 'facture', 'external', 'SHIPPING', 'Contact client livraison', 1, NULL, 0),
(62, 'facture', 'external', 'SERVICE', 'Contact client prestation', 1, NULL, 0),
(70, 'invoice_supplier', 'internal', 'SALESREPFOLL', 'Responsable suivi du paiement', 1, NULL, 0),
(71, 'invoice_supplier', 'external', 'BILLING', 'Contact fournisseur facturation', 1, NULL, 0),
(72, 'invoice_supplier', 'external', 'SHIPPING', 'Contact fournisseur livraison', 1, NULL, 0),
(73, 'invoice_supplier', 'external', 'SERVICE', 'Contact fournisseur prestation', 1, NULL, 0),
(80, 'agenda', 'internal', 'ACTOR', 'Responsable', 1, NULL, 0),
(81, 'agenda', 'internal', 'GUEST', 'Guest', 1, NULL, 0),
(85, 'agenda', 'external', 'ACTOR', 'Responsable', 1, NULL, 0),
(86, 'agenda', 'external', 'GUEST', 'Guest', 1, NULL, 0),
(91, 'commande', 'internal', 'SALESREPFOLL', 'Responsable suivi de la commande', 1, NULL, 0),
(100, 'commande', 'external', 'BILLING', 'Contact client facturation commande', 1, NULL, 0),
(101, 'commande', 'external', 'CUSTOMER', 'Contact client suivi commande', 1, NULL, 0),
(102, 'commande', 'external', 'SHIPPING', 'Contact client livraison commande', 1, NULL, 0),
(110, 'supplier_proposal', 'internal', 'SALESREPFOLL', 'Responsable suivi de la demande', 1, NULL, 0),
(111, 'supplier_proposal', 'external', 'BILLING', 'Contact fournisseur facturation', 1, NULL, 0),
(112, 'supplier_proposal', 'external', 'SHIPPING', 'Contact fournisseur livraison', 1, NULL, 0),
(113, 'supplier_proposal', 'external', 'SERVICE', 'Contact fournisseur prestation', 1, NULL, 0),
(120, 'fichinter', 'internal', 'INTERREPFOLL', 'Responsable suivi de l''intervention', 1, NULL, 0),
(121, 'fichinter', 'internal', 'INTERVENING', 'Intervenant', 1, NULL, 0),
(130, 'fichinter', 'external', 'BILLING', 'Contact client facturation intervention', 1, NULL, 0),
(131, 'fichinter', 'external', 'CUSTOMER', 'Contact client suivi de l''intervention', 1, NULL, 0),
(140, 'order_supplier', 'internal', 'SALESREPFOLL', 'Responsable suivi de la commande', 1, NULL, 0),
(141, 'order_supplier', 'internal', 'SHIPPING', 'Responsable réception de la commande', 1, NULL, 0),
(142, 'order_supplier', 'external', 'BILLING', 'Contact fournisseur facturation commande', 1, NULL, 0),
(143, 'order_supplier', 'external', 'CUSTOMER', 'Contact fournisseur suivi commande', 1, NULL, 0),
(145, 'order_supplier', 'external', 'SHIPPING', 'Contact fournisseur livraison commande', 1, NULL, 0),
(150, 'dolresource', 'internal', 'USERINCHARGE', 'In charge of resource', 1, NULL, 0),
(151, 'dolresource', 'external', 'THIRDINCHARGE', 'In charge of resource', 1, NULL, 0),
(155, 'ticket', 'internal', 'SUPPORTTEC', 'Utilisateur contact support', 1, NULL, 0),
(156, 'ticket', 'internal', 'CONTRIBUTOR', 'Intervenant', 1, NULL, 0),
(157, 'ticket', 'external', 'SUPPORTCLI', 'Contact client suivi incident', 1, NULL, 0),
(158, 'ticket', 'external', 'CONTRIBUTOR', 'Intervenant', 1, NULL, 0),
(160, 'project', 'internal', 'PROJECTLEADER', 'Chef de Projet', 1, NULL, 0),
(161, 'project', 'internal', 'PROJECTCONTRIBUTOR', 'Intervenant', 1, NULL, 0),
(170, 'project', 'external', 'PROJECTLEADER', 'Chef de Projet', 1, NULL, 0),
(171, 'project', 'external', 'PROJECTCONTRIBUTOR', 'Intervenant', 1, NULL, 0),
(180, 'project_task', 'internal', 'TASKEXECUTIVE', 'Responsable', 1, NULL, 0),
(181, 'project_task', 'internal', 'TASKCONTRIBUTOR', 'Intervenant', 1, NULL, 0),
(190, 'project_task', 'external', 'TASKEXECUTIVE', 'Responsable', 1, NULL, 0),
(191, 'project_task', 'external', 'TASKCONTRIBUTOR', 'Intervenant', 1, NULL, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_type_container`
--

CREATE TABLE `llx_c_type_container` (
  `rowid` int(11) NOT NULL auto_increment,
  `code` varchar(32) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `label` varchar(64) collate utf8_unicode_ci NOT NULL,
  `module` varchar(32) collate utf8_unicode_ci default NULL,
  `active` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_c_type_container_id` (`code`,`entity`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `llx_c_type_container`
--

INSERT INTO `llx_c_type_container` (`rowid`, `code`, `entity`, `label`, `module`, `active`) VALUES
(1, 'page', 1, 'Page', 'system', 1),
(2, 'banner', 1, 'Banner', 'system', 1),
(3, 'blogpost', 1, 'BlogPost', 'system', 1),
(4, 'other', 1, 'Other', 'system', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_type_fees`
--

CREATE TABLE `llx_c_type_fees` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(12) collate utf8_unicode_ci NOT NULL,
  `label` varchar(30) collate utf8_unicode_ci default NULL,
  `type` int(11) default '0',
  `accountancy_code` varchar(32) collate utf8_unicode_ci default NULL,
  `active` tinyint(4) NOT NULL default '1',
  `module` varchar(32) collate utf8_unicode_ci default NULL,
  `position` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `uk_c_type_fees` (`code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=26 ;

--
-- Volcado de datos para la tabla `llx_c_type_fees`
--

INSERT INTO `llx_c_type_fees` (`id`, `code`, `label`, `type`, `accountancy_code`, `active`, `module`, `position`) VALUES
(1, 'TF_OTHER', 'Other', 0, NULL, 1, NULL, 0),
(2, 'TF_TRIP', 'Transportation', 0, NULL, 1, NULL, 0),
(3, 'TF_LUNCH', 'Lunch', 0, NULL, 1, NULL, 0),
(4, 'EX_KME', 'ExpLabelKm', 0, NULL, 1, NULL, 0),
(5, 'EX_FUE', 'ExpLabelFuelCV', 0, NULL, 0, NULL, 0),
(6, 'EX_HOT', 'ExpLabelHotel', 0, NULL, 0, NULL, 0),
(7, 'EX_PAR', 'ExpLabelParkingCV', 0, NULL, 0, NULL, 0),
(8, 'EX_TOL', 'ExpLabelTollCV', 0, NULL, 0, NULL, 0),
(9, 'EX_TAX', 'ExpLabelVariousTaxes', 0, NULL, 0, NULL, 0),
(10, 'EX_IND', 'ExpLabelIndemnityTransSubscrip', 0, NULL, 0, NULL, 0),
(11, 'EX_SUM', 'ExpLabelMaintenanceSupply', 0, NULL, 0, NULL, 0),
(12, 'EX_SUO', 'ExpLabelOfficeSupplies', 0, NULL, 0, NULL, 0),
(13, 'EX_CAR', 'ExpLabelCarRental', 0, NULL, 0, NULL, 0),
(14, 'EX_DOC', 'ExpLabelDocumentation', 0, NULL, 0, NULL, 0),
(15, 'EX_CUR', 'ExpLabelCustomersReceiving', 0, NULL, 0, NULL, 0),
(16, 'EX_OTR', 'ExpLabelOtherReceiving', 0, NULL, 0, NULL, 0),
(17, 'EX_POS', 'ExpLabelPostage', 0, NULL, 0, NULL, 0),
(18, 'EX_CAM', 'ExpLabelMaintenanceRepairCV', 0, NULL, 0, NULL, 0),
(19, 'EX_EMM', 'ExpLabelEmployeesMeal', 0, NULL, 0, NULL, 0),
(20, 'EX_GUM', 'ExpLabelGuestsMeal', 0, NULL, 0, NULL, 0),
(21, 'EX_BRE', 'ExpLabelBreakfast', 0, NULL, 0, NULL, 0),
(22, 'EX_FUE_VP', 'ExpLabelFuelPV', 0, NULL, 0, NULL, 0),
(23, 'EX_TOL_VP', 'ExpLabelTollPV', 0, NULL, 0, NULL, 0),
(24, 'EX_PAR_VP', 'ExpLabelParkingPV', 0, NULL, 0, NULL, 0),
(25, 'EX_CAM_VP', 'ExpLabelMaintenanceRepairPV', 0, NULL, 0, NULL, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_type_resource`
--

CREATE TABLE `llx_c_type_resource` (
  `rowid` int(11) NOT NULL auto_increment,
  `code` varchar(32) collate utf8_unicode_ci NOT NULL,
  `label` varchar(64) collate utf8_unicode_ci NOT NULL,
  `active` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_c_type_resource_id` (`label`,`code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `llx_c_type_resource`
--

INSERT INTO `llx_c_type_resource` (`rowid`, `code`, `label`, `active`) VALUES
(1, 'RES_VES', 'Vestuario', 1),
(2, 'RES_MUS', 'Sonido', 1),
(3, 'RES_SUM', 'Suministros', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_units`
--

CREATE TABLE `llx_c_units` (
  `rowid` int(11) NOT NULL auto_increment,
  `code` varchar(3) collate utf8_unicode_ci default NULL,
  `scale` int(11) default NULL,
  `label` varchar(50) collate utf8_unicode_ci default NULL,
  `short_label` varchar(5) collate utf8_unicode_ci default NULL,
  `unit_type` varchar(10) collate utf8_unicode_ci default NULL,
  `active` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_c_units_code` (`code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=37 ;

--
-- Volcado de datos para la tabla `llx_c_units`
--

INSERT INTO `llx_c_units` (`rowid`, `code`, `scale`, `label`, `short_label`, `unit_type`, `active`) VALUES
(1, 'T', 3, 'WeightUnitton', 'T', 'weight', 1),
(2, 'KG', 0, 'WeightUnitkg', 'kg', 'weight', 1),
(3, 'G', -3, 'WeightUnitg', 'g', 'weight', 1),
(4, 'MG', -6, 'WeightUnitmg', 'mg', 'weight', 1),
(5, 'OZ', 98, 'WeightUnitounce', 'Oz', 'weight', 1),
(6, 'LB', 99, 'WeightUnitpound', 'lb', 'weight', 1),
(7, 'M', 0, 'SizeUnitm', 'm', 'size', 1),
(8, 'DM', -1, 'SizeUnitdm', 'dm', 'size', 1),
(9, 'CM', -2, 'SizeUnitcm', 'cm', 'size', 1),
(10, 'MM', -3, 'SizeUnitmm', 'mm', 'size', 1),
(11, 'FT', 98, 'SizeUnitfoot', 'ft', 'size', 1),
(12, 'IN', 99, 'SizeUnitinch', 'in', 'size', 1),
(13, 'M2', 0, 'SurfaceUnitm2', 'm2', 'surface', 1),
(14, 'DM2', -2, 'SurfaceUnitdm2', 'dm2', 'surface', 1),
(15, 'CM2', -4, 'SurfaceUnitcm2', 'cm2', 'surface', 1),
(16, 'MM2', -6, 'SurfaceUnitmm2', 'mm2', 'surface', 1),
(17, 'FT2', 98, 'SurfaceUnitfoot2', 'ft2', 'surface', 1),
(18, 'IN2', 99, 'SurfaceUnitinch2', 'in2', 'surface', 1),
(19, 'M3', 0, 'VolumeUnitm3', 'm3', 'volume', 1),
(20, 'DM3', -3, 'VolumeUnitdm3', 'dm3', 'volume', 1),
(21, 'CM3', -6, 'VolumeUnitcm3', 'cm3', 'volume', 1),
(22, 'MM3', -9, 'VolumeUnitmm3', 'mm3', 'volume', 1),
(23, 'FT3', 88, 'VolumeUnitfoot3', 'ft3', 'volume', 1),
(24, 'IN3', 89, 'VolumeUnitinch3', 'in3', 'volume', 1),
(25, 'OZ3', 97, 'VolumeUnitounce', 'Oz', 'volume', 1),
(26, 'L', 98, 'VolumeUnitlitre', 'L', 'volume', 1),
(27, 'GAL', 99, 'VolumeUnitgallon', 'gal', 'volume', 1),
(28, 'P', 0, 'Piece', 'p', 'qty', 1),
(29, 'SET', 0, 'Set', 'set', 'qty', 1),
(30, 'S', 0, 'second', 's', 'time', 1),
(31, 'MI', 60, 'minute', 'i', 'time', 1),
(32, 'H', 3600, 'hour', 'h', 'time', 1),
(33, 'D', 12960000, 'day', 'd', 'time', 1),
(34, 'W', 604800, 'week', 'w', 'time', 1),
(35, 'MO', 2629800, 'month', 'm', 'time', 1),
(36, 'Y', 31557600, 'year', 'y', 'time', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_c_ziptown`
--

CREATE TABLE `llx_c_ziptown` (
  `rowid` int(11) NOT NULL auto_increment,
  `code` varchar(5) collate utf8_unicode_ci default NULL,
  `fk_county` int(11) default NULL,
  `fk_pays` int(11) NOT NULL default '0',
  `zip` varchar(10) collate utf8_unicode_ci NOT NULL,
  `town` varchar(180) collate utf8_unicode_ci NOT NULL,
  `active` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_ziptown_fk_pays` (`zip`,`town`,`fk_pays`),
  KEY `idx_c_ziptown_fk_county` (`fk_county`),
  KEY `idx_c_ziptown_fk_pays` (`fk_pays`),
  KEY `idx_c_ziptown_zip` (`zip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_default_values`
--

CREATE TABLE `llx_default_values` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `type` varchar(10) collate utf8_unicode_ci default NULL,
  `user_id` int(11) NOT NULL default '0',
  `page` varchar(255) collate utf8_unicode_ci default NULL,
  `param` varchar(255) collate utf8_unicode_ci default NULL,
  `value` varchar(128) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_default_values` (`type`,`entity`,`user_id`,`page`,`param`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_deplacement`
--

CREATE TABLE `llx_deplacement` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(30) collate utf8_unicode_ci default NULL,
  `entity` int(11) NOT NULL default '1',
  `datec` datetime NOT NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `dated` datetime default NULL,
  `fk_user` int(11) NOT NULL,
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `type` varchar(12) collate utf8_unicode_ci NOT NULL,
  `fk_statut` int(11) NOT NULL default '1',
  `km` double default NULL,
  `fk_soc` int(11) default NULL,
  `fk_projet` int(11) default '0',
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `extraparams` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_document_model`
--

CREATE TABLE `llx_document_model` (
  `rowid` int(11) NOT NULL auto_increment,
  `nom` varchar(50) collate utf8_unicode_ci default NULL,
  `entity` int(11) NOT NULL default '1',
  `type` varchar(20) collate utf8_unicode_ci NOT NULL,
  `libelle` varchar(255) collate utf8_unicode_ci default NULL,
  `description` text collate utf8_unicode_ci,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_document_model` (`nom`,`type`,`entity`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `llx_document_model`
--

INSERT INTO `llx_document_model` (`rowid`, `nom`, `entity`, `type`, `libelle`, `description`) VALUES
(1, 'standard', 1, 'member', NULL, NULL),
(2, 'standard', 1, 'expensereport', NULL, NULL),
(3, 'azur', 1, 'propal', NULL, NULL),
(4, 'Standard', 1, 'stock', NULL, NULL),
(5, 'StdMouvement', 1, 'mouvement', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_don`
--

CREATE TABLE `llx_don` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(30) collate utf8_unicode_ci default NULL,
  `entity` int(11) NOT NULL default '1',
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_statut` smallint(6) NOT NULL default '0',
  `datedon` datetime default NULL,
  `amount` double(24,8) default '0.00000000',
  `fk_payment` int(11) default NULL,
  `paid` smallint(6) NOT NULL default '0',
  `fk_soc` int(11) default NULL,
  `firstname` varchar(50) collate utf8_unicode_ci default NULL,
  `lastname` varchar(50) collate utf8_unicode_ci default NULL,
  `societe` varchar(50) collate utf8_unicode_ci default NULL,
  `address` text collate utf8_unicode_ci,
  `zip` varchar(30) collate utf8_unicode_ci default NULL,
  `town` varchar(50) collate utf8_unicode_ci default NULL,
  `country` varchar(50) collate utf8_unicode_ci default NULL,
  `fk_country` int(11) NOT NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `phone` varchar(24) collate utf8_unicode_ci default NULL,
  `phone_mobile` varchar(24) collate utf8_unicode_ci default NULL,
  `public` smallint(6) NOT NULL default '1',
  `fk_projet` int(11) default NULL,
  `datec` datetime default NULL,
  `fk_user_author` int(11) NOT NULL,
  `date_valid` datetime default NULL,
  `fk_user_valid` int(11) default NULL,
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `extraparams` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_don_extrafields`
--

CREATE TABLE `llx_don_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_don_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_ecm_directories`
--

CREATE TABLE `llx_ecm_directories` (
  `rowid` int(11) NOT NULL auto_increment,
  `label` varchar(64) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `fk_parent` int(11) default NULL,
  `description` varchar(255) collate utf8_unicode_ci NOT NULL,
  `cachenbofdoc` int(11) NOT NULL default '0',
  `fullpath` varchar(750) collate utf8_unicode_ci default NULL,
  `extraparams` varchar(255) collate utf8_unicode_ci default NULL,
  `date_c` datetime default NULL,
  `date_m` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_user_c` int(11) default NULL,
  `fk_user_m` int(11) default NULL,
  `acl` text collate utf8_unicode_ci,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_ecm_directories` (`label`,`fk_parent`,`entity`),
  KEY `idx_ecm_directories_fk_user_c` (`fk_user_c`),
  KEY `idx_ecm_directories_fk_user_m` (`fk_user_m`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_ecm_files`
--

CREATE TABLE `llx_ecm_files` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(128) collate utf8_unicode_ci default NULL,
  `label` varchar(128) collate utf8_unicode_ci NOT NULL,
  `share` varchar(128) collate utf8_unicode_ci default NULL,
  `entity` int(11) NOT NULL default '1',
  `filepath` varchar(255) collate utf8_unicode_ci NOT NULL,
  `filename` varchar(255) collate utf8_unicode_ci NOT NULL,
  `src_object_type` varchar(32) collate utf8_unicode_ci default NULL,
  `src_object_id` int(11) default NULL,
  `fullpath_orig` varchar(750) collate utf8_unicode_ci default NULL,
  `description` text collate utf8_unicode_ci,
  `keywords` varchar(750) collate utf8_unicode_ci default NULL,
  `cover` text collate utf8_unicode_ci,
  `position` int(11) default NULL,
  `gen_or_uploaded` varchar(12) collate utf8_unicode_ci default NULL,
  `extraparams` varchar(255) collate utf8_unicode_ci default NULL,
  `date_c` datetime default NULL,
  `date_m` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_user_c` int(11) default NULL,
  `fk_user_m` int(11) default NULL,
  `acl` text collate utf8_unicode_ci,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_ecm_files` (`filepath`,`filename`,`entity`),
  KEY `idx_ecm_files_label` (`label`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `llx_ecm_files`
--

INSERT INTO `llx_ecm_files` (`rowid`, `ref`, `label`, `share`, `entity`, `filepath`, `filename`, `src_object_type`, `src_object_id`, `fullpath_orig`, `description`, `keywords`, `cover`, `position`, `gen_or_uploaded`, `extraparams`, `date_c`, `date_m`, `fk_user_c`, `fk_user_m`, `acl`) VALUES
(2, '7b4b72d3ad9beec588c288a53c357d40', 'bb35b0c17e05675dd26fedd44df42dde', NULL, 1, 'actividades/actividad/ESC_AVA', 'IMG-20180302-WA0000.jpg', NULL, NULL, 'IMG-20180302-WA0000.jpg', '', NULL, NULL, 1, 'uploaded', NULL, '2019-07-31 20:18:00', '2019-07-31 16:18:00', 1, NULL, NULL),
(3, '1646f82c2c33421e0495352444555e8e', 'a5f1958784357d6383c5cf0aa2c36b26', NULL, 1, 'expensereport/(PROV1)', '(PROV1).pdf', 'expensereport', 1, '', '', NULL, NULL, 1, 'generated', NULL, '2019-08-31 16:05:23', '2019-08-31 12:05:23', 1, NULL, NULL),
(4, '7e3a148c3f87e4ddb989e059ea213fea', '0629e06a6a0d2ad0bd63399aa2d07d1a', NULL, 1, 'expensereport/ER1908-0001', 'ER1908-0001.pdf', 'expensereport', 1, '', '', NULL, NULL, 1, 'generated', NULL, '2019-08-31 16:05:48', '2019-08-31 14:06:08', 1, 1, NULL),
(6, 'f398c6448df68e015be8d52090424bc2', '0cf8a946801f29b7563367abad41e232', NULL, 1, 'propale/(PROV2)', '(PROV2).pdf', 'propal', 2, '', '', NULL, NULL, 1, 'generated', NULL, '2019-09-07 08:41:53', '2019-09-07 06:45:26', 1, 1, NULL),
(7, '7508c4d80b8a2d9c9eeba1b837dea8bf', '2ab88c2ac114992f25da18b0fbc9b455', NULL, 1, 'propale/PR1909-0001', 'PR1909-0001.pdf', 'propal', 2, '', '', NULL, NULL, 1, 'generated', NULL, '2019-09-07 08:45:48', '2019-09-07 06:49:40', 1, 1, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_element_contact`
--

CREATE TABLE `llx_element_contact` (
  `rowid` int(11) NOT NULL auto_increment,
  `datecreate` datetime default NULL,
  `statut` smallint(6) default '5',
  `element_id` int(11) NOT NULL,
  `fk_c_type_contact` int(11) NOT NULL,
  `fk_socpeople` int(11) NOT NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `idx_element_contact_idx1` (`element_id`,`fk_c_type_contact`,`fk_socpeople`),
  KEY `fk_element_contact_fk_c_type_contact` (`fk_c_type_contact`),
  KEY `idx_element_contact_fk_socpeople` (`fk_socpeople`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_element_element`
--

CREATE TABLE `llx_element_element` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_source` int(11) NOT NULL,
  `sourcetype` varchar(32) collate utf8_unicode_ci NOT NULL,
  `fk_target` int(11) NOT NULL,
  `targettype` varchar(32) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `idx_element_element_idx1` (`fk_source`,`sourcetype`,`fk_target`,`targettype`),
  KEY `idx_element_element_fk_target` (`fk_target`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_element_resources`
--

CREATE TABLE `llx_element_resources` (
  `rowid` int(11) NOT NULL auto_increment,
  `element_id` int(11) default NULL,
  `element_type` varchar(64) collate utf8_unicode_ci default NULL,
  `resource_id` int(11) default NULL,
  `resource_type` varchar(64) collate utf8_unicode_ci default NULL,
  `busy` int(11) default NULL,
  `mandatory` int(11) default NULL,
  `duree` double default NULL,
  `fk_user_create` int(11) default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `idx_element_resources_idx1` (`resource_id`,`resource_type`,`element_id`,`element_type`),
  KEY `idx_element_element_element_id` (`element_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `llx_element_resources`
--

INSERT INTO `llx_element_resources` (`rowid`, `element_id`, `element_type`, `resource_id`, `resource_type`, `busy`, `mandatory`, `duree`, `fk_user_create`, `tms`) VALUES
(1, 7, 'action', 1, 'dolresource', 1, 1, NULL, NULL, '2019-08-31 15:01:35');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_emailcollector_emailcollector`
--

CREATE TABLE `llx_emailcollector_emailcollector` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `ref` varchar(128) collate utf8_unicode_ci NOT NULL,
  `label` varchar(255) collate utf8_unicode_ci default NULL,
  `description` text collate utf8_unicode_ci,
  `host` varchar(255) collate utf8_unicode_ci default NULL,
  `login` varchar(128) collate utf8_unicode_ci default NULL,
  `password` varchar(128) collate utf8_unicode_ci default NULL,
  `source_directory` varchar(255) collate utf8_unicode_ci NOT NULL,
  `target_directory` varchar(255) collate utf8_unicode_ci default NULL,
  `maxemailpercollect` int(11) default '100',
  `datelastresult` datetime default NULL,
  `codelastresult` varchar(16) collate utf8_unicode_ci default NULL,
  `lastresult` varchar(255) collate utf8_unicode_ci default NULL,
  `datelastok` datetime default NULL,
  `note_public` text collate utf8_unicode_ci,
  `note_private` text collate utf8_unicode_ci,
  `date_creation` datetime NOT NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_user_creat` int(11) NOT NULL,
  `fk_user_modif` int(11) default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_emailcollector_entity` (`entity`),
  KEY `idx_emailcollector_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_emailcollector_emailcollectoraction`
--

CREATE TABLE `llx_emailcollector_emailcollectoraction` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_emailcollector` int(11) NOT NULL,
  `type` varchar(128) collate utf8_unicode_ci NOT NULL,
  `actionparam` varchar(255) collate utf8_unicode_ci default NULL,
  `date_creation` datetime NOT NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_user_creat` int(11) NOT NULL,
  `fk_user_modif` int(11) default NULL,
  `position` int(11) default '0',
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_emailcollector_emailcollectoraction` (`fk_emailcollector`,`type`),
  KEY `idx_emailcollector_fk_emailcollector` (`fk_emailcollector`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_emailcollector_emailcollectorfilter`
--

CREATE TABLE `llx_emailcollector_emailcollectorfilter` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_emailcollector` int(11) NOT NULL,
  `type` varchar(128) collate utf8_unicode_ci NOT NULL,
  `rulevalue` varchar(128) collate utf8_unicode_ci default NULL,
  `date_creation` datetime NOT NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_user_creat` int(11) NOT NULL,
  `fk_user_modif` int(11) default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_emailcollector_emailcollectorfilter` (`fk_emailcollector`,`type`,`rulevalue`),
  KEY `idx_emailcollector_fk_emailcollector` (`fk_emailcollector`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_entrepot`
--

CREATE TABLE `llx_entrepot` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(255) collate utf8_unicode_ci NOT NULL,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `entity` int(11) NOT NULL default '1',
  `description` text collate utf8_unicode_ci,
  `lieu` varchar(64) collate utf8_unicode_ci default NULL,
  `address` varchar(255) collate utf8_unicode_ci default NULL,
  `zip` varchar(10) collate utf8_unicode_ci default NULL,
  `town` varchar(50) collate utf8_unicode_ci default NULL,
  `fk_departement` int(11) default NULL,
  `fk_pays` int(11) default '0',
  `statut` tinyint(4) default '1',
  `fk_user_author` int(11) default NULL,
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `fk_parent` int(11) default '0',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_entrepot_label` (`ref`,`entity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_establishment`
--

CREATE TABLE `llx_establishment` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `name` varchar(50) collate utf8_unicode_ci default NULL,
  `address` varchar(255) collate utf8_unicode_ci default NULL,
  `zip` varchar(25) collate utf8_unicode_ci default NULL,
  `town` varchar(50) collate utf8_unicode_ci default NULL,
  `fk_state` int(11) default '0',
  `fk_country` int(11) default '0',
  `profid1` varchar(20) collate utf8_unicode_ci default NULL,
  `profid2` varchar(20) collate utf8_unicode_ci default NULL,
  `profid3` varchar(20) collate utf8_unicode_ci default NULL,
  `phone` varchar(20) collate utf8_unicode_ci default NULL,
  `fk_user_author` int(11) NOT NULL,
  `fk_user_mod` int(11) default NULL,
  `datec` datetime NOT NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `status` tinyint(4) default '1',
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_events`
--

CREATE TABLE `llx_events` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `type` varchar(32) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `dateevent` datetime default NULL,
  `fk_user` int(11) default NULL,
  `description` varchar(250) collate utf8_unicode_ci NOT NULL,
  `ip` varchar(250) collate utf8_unicode_ci NOT NULL,
  `user_agent` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_object` int(11) default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_events_dateevent` (`dateevent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_event_element`
--

CREATE TABLE `llx_event_element` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_source` int(11) NOT NULL,
  `fk_target` int(11) NOT NULL,
  `targettype` varchar(32) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_expedition`
--

CREATE TABLE `llx_expedition` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `ref` varchar(30) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `fk_soc` int(11) NOT NULL,
  `fk_projet` int(11) default NULL,
  `ref_ext` varchar(255) collate utf8_unicode_ci default NULL,
  `ref_int` varchar(255) collate utf8_unicode_ci default NULL,
  `ref_customer` varchar(255) collate utf8_unicode_ci default NULL,
  `date_creation` datetime default NULL,
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `date_valid` datetime default NULL,
  `fk_user_valid` int(11) default NULL,
  `date_delivery` datetime default NULL,
  `date_expedition` datetime default NULL,
  `fk_address` int(11) default NULL,
  `fk_shipping_method` int(11) default NULL,
  `tracking_number` varchar(50) collate utf8_unicode_ci default NULL,
  `fk_statut` smallint(6) default '0',
  `billed` smallint(6) default '0',
  `height` float default NULL,
  `width` float default NULL,
  `size_units` int(11) default NULL,
  `size` float default NULL,
  `weight_units` int(11) default NULL,
  `weight` float default NULL,
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  `last_main_doc` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_incoterms` int(11) default NULL,
  `location_incoterms` varchar(255) collate utf8_unicode_ci default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `extraparams` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `idx_expedition_uk_ref` (`ref`,`entity`),
  KEY `idx_expedition_fk_soc` (`fk_soc`),
  KEY `idx_expedition_fk_user_author` (`fk_user_author`),
  KEY `idx_expedition_fk_user_valid` (`fk_user_valid`),
  KEY `idx_expedition_fk_shipping_method` (`fk_shipping_method`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_expeditiondet`
--

CREATE TABLE `llx_expeditiondet` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_expedition` int(11) NOT NULL,
  `fk_origin_line` int(11) default NULL,
  `fk_entrepot` int(11) default NULL,
  `qty` double default NULL,
  `rang` int(11) default '0',
  PRIMARY KEY  (`rowid`),
  KEY `idx_expeditiondet_fk_expedition` (`fk_expedition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_expeditiondet_batch`
--

CREATE TABLE `llx_expeditiondet_batch` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_expeditiondet` int(11) NOT NULL,
  `eatby` date default NULL,
  `sellby` date default NULL,
  `batch` varchar(30) collate utf8_unicode_ci default NULL,
  `qty` double NOT NULL default '0',
  `fk_origin_stock` int(11) NOT NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_fk_expeditiondet` (`fk_expeditiondet`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_expeditiondet_extrafields`
--

CREATE TABLE `llx_expeditiondet_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_expeditiondet_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_expedition_extrafields`
--

CREATE TABLE `llx_expedition_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_expedition_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_expensereport`
--

CREATE TABLE `llx_expensereport` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(50) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `ref_number_int` int(11) default NULL,
  `ref_ext` int(11) default NULL,
  `total_ht` double(24,8) default '0.00000000',
  `total_tva` double(24,8) default '0.00000000',
  `localtax1` double(24,8) default '0.00000000',
  `localtax2` double(24,8) default '0.00000000',
  `total_ttc` double(24,8) default '0.00000000',
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `date_create` datetime NOT NULL,
  `date_valid` datetime default NULL,
  `date_approve` datetime default NULL,
  `date_refuse` datetime default NULL,
  `date_cancel` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_user_author` int(11) NOT NULL,
  `fk_user_modif` int(11) default NULL,
  `fk_user_valid` int(11) default NULL,
  `fk_user_validator` int(11) default NULL,
  `fk_user_approve` int(11) default NULL,
  `fk_user_refuse` int(11) default NULL,
  `fk_user_cancel` int(11) default NULL,
  `fk_statut` int(11) NOT NULL,
  `fk_c_paiement` int(11) default NULL,
  `paid` smallint(6) NOT NULL default '0',
  `note_public` text collate utf8_unicode_ci,
  `note_private` text collate utf8_unicode_ci,
  `detail_refuse` varchar(255) collate utf8_unicode_ci default NULL,
  `detail_cancel` varchar(255) collate utf8_unicode_ci default NULL,
  `integration_compta` int(11) default NULL,
  `fk_bank_account` int(11) default NULL,
  `model_pdf` varchar(50) collate utf8_unicode_ci default NULL,
  `fk_multicurrency` int(11) default NULL,
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_tx` double(24,8) default '1.00000000',
  `multicurrency_total_ht` double(24,8) default '0.00000000',
  `multicurrency_total_tva` double(24,8) default '0.00000000',
  `multicurrency_total_ttc` double(24,8) default '0.00000000',
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `extraparams` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `idx_expensereport_uk_ref` (`ref`,`entity`),
  KEY `idx_expensereport_date_debut` (`date_debut`),
  KEY `idx_expensereport_date_fin` (`date_fin`),
  KEY `idx_expensereport_fk_statut` (`fk_statut`),
  KEY `idx_expensereport_fk_user_author` (`fk_user_author`),
  KEY `idx_expensereport_fk_user_valid` (`fk_user_valid`),
  KEY `idx_expensereport_fk_user_approve` (`fk_user_approve`),
  KEY `idx_expensereport_fk_refuse` (`fk_user_approve`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `llx_expensereport`
--

INSERT INTO `llx_expensereport` (`rowid`, `ref`, `entity`, `ref_number_int`, `ref_ext`, `total_ht`, `total_tva`, `localtax1`, `localtax2`, `total_ttc`, `date_debut`, `date_fin`, `date_create`, `date_valid`, `date_approve`, `date_refuse`, `date_cancel`, `tms`, `fk_user_author`, `fk_user_modif`, `fk_user_valid`, `fk_user_validator`, `fk_user_approve`, `fk_user_refuse`, `fk_user_cancel`, `fk_statut`, `fk_c_paiement`, `paid`, `note_public`, `note_private`, `detail_refuse`, `detail_cancel`, `integration_compta`, `fk_bank_account`, `model_pdf`, `fk_multicurrency`, `multicurrency_code`, `multicurrency_tx`, `multicurrency_total_ht`, `multicurrency_total_tva`, `multicurrency_total_ttc`, `import_key`, `extraparams`) VALUES
(1, 'ER1908-0001', 1, NULL, NULL, 6.00000000, 0.00000000, 0.00000000, 0.00000000, 6.00000000, '2019-08-25', '2019-09-20', '2019-08-31 16:03:11', '2019-08-31 16:05:48', NULL, NULL, NULL, '2019-08-31 14:06:08', 2, NULL, 1, 1, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1.00000000, 0.00000000, 0.00000000, 0.00000000, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_expensereport_det`
--

CREATE TABLE `llx_expensereport_det` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_expensereport` int(11) NOT NULL,
  `docnumber` varchar(128) collate utf8_unicode_ci default NULL,
  `fk_c_type_fees` int(11) NOT NULL,
  `fk_c_exp_tax_cat` int(11) default NULL,
  `fk_projet` int(11) default NULL,
  `comments` text collate utf8_unicode_ci NOT NULL,
  `product_type` int(11) default '-1',
  `qty` double NOT NULL,
  `subprice` double(24,8) NOT NULL default '0.00000000',
  `value_unit` double(24,8) NOT NULL,
  `remise_percent` double default NULL,
  `vat_src_code` varchar(10) collate utf8_unicode_ci default '',
  `tva_tx` double(6,3) default NULL,
  `localtax1_tx` double(6,3) default '0.000',
  `localtax1_type` varchar(10) collate utf8_unicode_ci default NULL,
  `localtax2_tx` double(6,3) default '0.000',
  `localtax2_type` varchar(10) collate utf8_unicode_ci default NULL,
  `total_ht` double(24,8) NOT NULL default '0.00000000',
  `total_tva` double(24,8) NOT NULL default '0.00000000',
  `total_localtax1` double(24,8) default '0.00000000',
  `total_localtax2` double(24,8) default '0.00000000',
  `total_ttc` double(24,8) NOT NULL default '0.00000000',
  `date` date NOT NULL,
  `info_bits` int(11) default '0',
  `special_code` int(11) default '0',
  `fk_multicurrency` int(11) default NULL,
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_subprice` double(24,8) default '0.00000000',
  `multicurrency_total_ht` double(24,8) default '0.00000000',
  `multicurrency_total_tva` double(24,8) default '0.00000000',
  `multicurrency_total_ttc` double(24,8) default '0.00000000',
  `fk_facture` int(11) default '0',
  `fk_ecm_files` int(11) default NULL,
  `fk_code_ventilation` int(11) default '0',
  `rang` int(11) default '0',
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `rule_warning_message` text collate utf8_unicode_ci,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `llx_expensereport_det`
--

INSERT INTO `llx_expensereport_det` (`rowid`, `fk_expensereport`, `docnumber`, `fk_c_type_fees`, `fk_c_exp_tax_cat`, `fk_projet`, `comments`, `product_type`, `qty`, `subprice`, `value_unit`, `remise_percent`, `vat_src_code`, `tva_tx`, `localtax1_tx`, `localtax1_type`, `localtax2_tx`, `localtax2_type`, `total_ht`, `total_tva`, `total_localtax1`, `total_localtax2`, `total_ttc`, `date`, `info_bits`, `special_code`, `fk_multicurrency`, `multicurrency_code`, `multicurrency_subprice`, `multicurrency_total_ht`, `multicurrency_total_tva`, `multicurrency_total_ttc`, `fk_facture`, `fk_ecm_files`, `fk_code_ventilation`, `rang`, `import_key`, `rule_warning_message`) VALUES
(1, 1, NULL, 4, 0, NULL, '', -1, 1, 0.00000000, 6.00000000, NULL, '', 0.000, 0.000, NULL, 0.000, NULL, 6.00000000, 0.00000000, 0.00000000, 0.00000000, 6.00000000, '2019-08-31', 0, 0, NULL, NULL, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0, NULL, 0, 0, NULL, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_expensereport_extrafields`
--

CREATE TABLE `llx_expensereport_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_expensereport_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_expensereport_ik`
--

CREATE TABLE `llx_expensereport_ik` (
  `rowid` int(11) NOT NULL auto_increment,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_c_exp_tax_cat` int(11) NOT NULL default '0',
  `fk_range` int(11) NOT NULL default '0',
  `coef` double NOT NULL default '0',
  `ikoffset` double NOT NULL default '0',
  `active` int(11) default '1',
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Volcado de datos para la tabla `llx_expensereport_ik`
--

INSERT INTO `llx_expensereport_ik` (`rowid`, `datec`, `tms`, `fk_c_exp_tax_cat`, `fk_range`, `coef`, `ikoffset`, `active`) VALUES
(1, NULL, '2019-07-29 14:24:47', 4, 1, 0.41, 0, 1),
(2, NULL, '2019-07-29 14:24:47', 4, 2, 0.244, 824, 1),
(3, NULL, '2019-07-29 14:24:47', 4, 3, 0.286, 0, 1),
(4, NULL, '2019-07-29 14:24:47', 5, 4, 0.493, 0, 1),
(5, NULL, '2019-07-29 14:24:47', 5, 5, 0.277, 1082, 1),
(6, NULL, '2019-07-29 14:24:47', 5, 6, 0.332, 0, 1),
(7, NULL, '2019-07-29 14:24:47', 6, 7, 0.543, 0, 1),
(8, NULL, '2019-07-29 14:24:47', 6, 8, 0.305, 1180, 1),
(9, NULL, '2019-07-29 14:24:47', 6, 9, 0.364, 0, 1),
(10, NULL, '2019-07-29 14:24:47', 7, 10, 0.568, 0, 1),
(11, NULL, '2019-07-29 14:24:47', 7, 11, 0.32, 1244, 1),
(12, NULL, '2019-07-29 14:24:47', 7, 12, 0.382, 0, 1),
(13, NULL, '2019-07-29 14:24:47', 8, 13, 0.595, 0, 1),
(14, NULL, '2019-07-29 14:24:47', 8, 14, 0.337, 1288, 1),
(15, NULL, '2019-07-29 14:24:47', 8, 15, 0.401, 0, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_expensereport_rules`
--

CREATE TABLE `llx_expensereport_rules` (
  `rowid` int(11) NOT NULL auto_increment,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `dates` datetime NOT NULL,
  `datee` datetime NOT NULL,
  `amount` double(24,8) NOT NULL,
  `restrictive` tinyint(4) NOT NULL,
  `fk_user` int(11) default NULL,
  `fk_usergroup` int(11) default NULL,
  `fk_c_type_fees` int(11) NOT NULL,
  `code_expense_rules_type` varchar(50) collate utf8_unicode_ci NOT NULL,
  `is_for_all` tinyint(4) default '0',
  `entity` int(11) default '1',
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_export_compta`
--

CREATE TABLE `llx_export_compta` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(12) collate utf8_unicode_ci NOT NULL,
  `date_export` datetime NOT NULL,
  `fk_user` int(11) NOT NULL,
  `note` text collate utf8_unicode_ci,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_export_model`
--

CREATE TABLE `llx_export_model` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_user` int(11) NOT NULL default '0',
  `label` varchar(50) collate utf8_unicode_ci NOT NULL,
  `type` varchar(20) collate utf8_unicode_ci NOT NULL,
  `field` text collate utf8_unicode_ci NOT NULL,
  `filter` text collate utf8_unicode_ci,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_export_model` (`label`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_extrafields`
--

CREATE TABLE `llx_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `name` varchar(64) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `elementtype` varchar(64) collate utf8_unicode_ci NOT NULL default 'member',
  `label` varchar(255) collate utf8_unicode_ci NOT NULL,
  `type` varchar(8) collate utf8_unicode_ci default NULL,
  `size` varchar(8) collate utf8_unicode_ci default NULL,
  `fieldcomputed` text collate utf8_unicode_ci,
  `fielddefault` varchar(255) collate utf8_unicode_ci default NULL,
  `fieldunique` int(11) default '0',
  `fieldrequired` int(11) default '0',
  `perms` varchar(255) collate utf8_unicode_ci default NULL,
  `enabled` varchar(255) collate utf8_unicode_ci default NULL,
  `pos` int(11) default '0',
  `alwayseditable` int(11) default '0',
  `param` text collate utf8_unicode_ci,
  `list` varchar(255) collate utf8_unicode_ci default '1',
  `totalizable` tinyint(1) default '0',
  `langs` varchar(64) collate utf8_unicode_ci default NULL,
  `help` text collate utf8_unicode_ci,
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_extrafields_name` (`name`,`entity`,`elementtype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_facture`
--

CREATE TABLE `llx_facture` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(30) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `ref_ext` varchar(255) collate utf8_unicode_ci default NULL,
  `ref_int` varchar(255) collate utf8_unicode_ci default NULL,
  `ref_client` varchar(255) collate utf8_unicode_ci default NULL,
  `type` smallint(6) NOT NULL default '0',
  `increment` varchar(10) collate utf8_unicode_ci default NULL,
  `fk_soc` int(11) NOT NULL,
  `datec` datetime default NULL,
  `datef` date default NULL,
  `date_pointoftax` date default NULL,
  `date_valid` date default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `paye` smallint(6) NOT NULL default '0',
  `amount` double(24,8) NOT NULL default '0.00000000',
  `remise_percent` double default '0',
  `remise_absolue` double default '0',
  `remise` double default '0',
  `close_code` varchar(16) collate utf8_unicode_ci default NULL,
  `close_note` varchar(128) collate utf8_unicode_ci default NULL,
  `tva` double(24,8) default '0.00000000',
  `localtax1` double(24,8) default '0.00000000',
  `localtax2` double(24,8) default '0.00000000',
  `revenuestamp` double(24,8) default '0.00000000',
  `total` double(24,8) default '0.00000000',
  `total_ttc` double(24,8) default '0.00000000',
  `fk_statut` smallint(6) NOT NULL default '0',
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `fk_user_valid` int(11) default NULL,
  `module_source` varchar(32) collate utf8_unicode_ci default NULL,
  `pos_source` varchar(32) collate utf8_unicode_ci default NULL,
  `fk_fac_rec_source` int(11) default NULL,
  `fk_facture_source` int(11) default NULL,
  `fk_projet` int(11) default NULL,
  `fk_account` int(11) default NULL,
  `fk_currency` varchar(3) collate utf8_unicode_ci default NULL,
  `fk_cond_reglement` int(11) NOT NULL default '1',
  `fk_mode_reglement` int(11) default NULL,
  `date_lim_reglement` date default NULL,
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  `last_main_doc` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_incoterms` int(11) default NULL,
  `location_incoterms` varchar(255) collate utf8_unicode_ci default NULL,
  `situation_cycle_ref` smallint(6) default NULL,
  `situation_counter` smallint(6) default NULL,
  `situation_final` smallint(6) default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `extraparams` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_multicurrency` int(11) default NULL,
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_tx` double(24,8) default '1.00000000',
  `multicurrency_total_ht` double(24,8) default '0.00000000',
  `multicurrency_total_tva` double(24,8) default '0.00000000',
  `multicurrency_total_ttc` double(24,8) default '0.00000000',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_facture_ref` (`ref`,`entity`),
  KEY `idx_facture_fk_soc` (`fk_soc`),
  KEY `idx_facture_fk_user_author` (`fk_user_author`),
  KEY `idx_facture_fk_user_valid` (`fk_user_valid`),
  KEY `idx_facture_fk_facture_source` (`fk_facture_source`),
  KEY `idx_facture_fk_projet` (`fk_projet`),
  KEY `idx_facture_fk_account` (`fk_account`),
  KEY `idx_facture_fk_currency` (`fk_currency`),
  KEY `idx_facture_fk_statut` (`fk_statut`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_facturedet`
--

CREATE TABLE `llx_facturedet` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_facture` int(11) NOT NULL,
  `fk_parent_line` int(11) default NULL,
  `fk_product` int(11) default NULL,
  `label` varchar(255) collate utf8_unicode_ci default NULL,
  `description` text collate utf8_unicode_ci,
  `vat_src_code` varchar(10) collate utf8_unicode_ci default '',
  `tva_tx` double(6,3) default NULL,
  `localtax1_tx` double(6,3) default '0.000',
  `localtax1_type` varchar(10) collate utf8_unicode_ci default NULL,
  `localtax2_tx` double(6,3) default '0.000',
  `localtax2_type` varchar(10) collate utf8_unicode_ci default NULL,
  `qty` double default NULL,
  `remise_percent` double default '0',
  `remise` double default '0',
  `fk_remise_except` int(11) default NULL,
  `subprice` double(24,8) default NULL,
  `price` double(24,8) default NULL,
  `total_ht` double(24,8) default NULL,
  `total_tva` double(24,8) default NULL,
  `total_localtax1` double(24,8) default '0.00000000',
  `total_localtax2` double(24,8) default '0.00000000',
  `total_ttc` double(24,8) default NULL,
  `product_type` int(11) default '0',
  `date_start` datetime default NULL,
  `date_end` datetime default NULL,
  `info_bits` int(11) default '0',
  `buy_price_ht` double(24,8) default '0.00000000',
  `fk_product_fournisseur_price` int(11) default NULL,
  `special_code` int(11) default '0',
  `rang` int(11) default '0',
  `fk_contract_line` int(11) default NULL,
  `fk_unit` int(11) default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `fk_code_ventilation` int(11) NOT NULL default '0',
  `situation_percent` double default NULL,
  `fk_prev_id` int(11) default NULL,
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `fk_multicurrency` int(11) default NULL,
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_subprice` double(24,8) default '0.00000000',
  `multicurrency_total_ht` double(24,8) default '0.00000000',
  `multicurrency_total_tva` double(24,8) default '0.00000000',
  `multicurrency_total_ttc` double(24,8) default '0.00000000',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_fk_remise_except` (`fk_remise_except`,`fk_facture`),
  KEY `idx_facturedet_fk_facture` (`fk_facture`),
  KEY `idx_facturedet_fk_product` (`fk_product`),
  KEY `idx_facturedet_fk_code_ventilation` (`fk_code_ventilation`),
  KEY `fk_facturedet_fk_unit` (`fk_unit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_facturedet_extrafields`
--

CREATE TABLE `llx_facturedet_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_facturedet_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_facturedet_rec`
--

CREATE TABLE `llx_facturedet_rec` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_facture` int(11) NOT NULL,
  `fk_parent_line` int(11) default NULL,
  `fk_product` int(11) default NULL,
  `product_type` int(11) default '0',
  `label` varchar(255) collate utf8_unicode_ci default NULL,
  `description` text collate utf8_unicode_ci,
  `vat_src_code` varchar(10) collate utf8_unicode_ci default '',
  `tva_tx` double(6,3) default NULL,
  `localtax1_tx` double(6,3) default '0.000',
  `localtax1_type` varchar(10) collate utf8_unicode_ci default NULL,
  `localtax2_tx` double(6,3) default '0.000',
  `localtax2_type` varchar(10) collate utf8_unicode_ci default NULL,
  `qty` double default NULL,
  `remise_percent` double default '0',
  `remise` double default '0',
  `subprice` double(24,8) default NULL,
  `price` double(24,8) default NULL,
  `total_ht` double(24,8) default NULL,
  `total_tva` double(24,8) default NULL,
  `total_localtax1` double(24,8) default '0.00000000',
  `total_localtax2` double(24,8) default '0.00000000',
  `total_ttc` double(24,8) default NULL,
  `date_start_fill` int(11) default '0',
  `date_end_fill` int(11) default '0',
  `info_bits` int(11) default '0',
  `buy_price_ht` double(24,8) default '0.00000000',
  `fk_product_fournisseur_price` int(11) default NULL,
  `special_code` int(10) unsigned default '0',
  `rang` int(11) default '0',
  `fk_contract_line` int(11) default NULL,
  `fk_unit` int(11) default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `fk_multicurrency` int(11) default NULL,
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_subprice` double(24,8) default '0.00000000',
  `multicurrency_total_ht` double(24,8) default '0.00000000',
  `multicurrency_total_tva` double(24,8) default '0.00000000',
  `multicurrency_total_ttc` double(24,8) default '0.00000000',
  PRIMARY KEY  (`rowid`),
  KEY `fk_facturedet_rec_fk_unit` (`fk_unit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_facturedet_rec_extrafields`
--

CREATE TABLE `llx_facturedet_rec_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_facturedet_rec_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_facture_extrafields`
--

CREATE TABLE `llx_facture_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_facture_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_facture_fourn`
--

CREATE TABLE `llx_facture_fourn` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(180) collate utf8_unicode_ci NOT NULL,
  `ref_supplier` varchar(180) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `ref_ext` varchar(255) collate utf8_unicode_ci default NULL,
  `type` smallint(6) NOT NULL default '0',
  `fk_soc` int(11) NOT NULL,
  `datec` datetime default NULL,
  `datef` date default NULL,
  `date_pointoftax` date default NULL,
  `date_valid` date default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `libelle` varchar(255) collate utf8_unicode_ci default NULL,
  `paye` smallint(6) NOT NULL default '0',
  `amount` double(24,8) NOT NULL default '0.00000000',
  `remise` double(24,8) default '0.00000000',
  `close_code` varchar(16) collate utf8_unicode_ci default NULL,
  `close_note` varchar(128) collate utf8_unicode_ci default NULL,
  `tva` double(24,8) default '0.00000000',
  `localtax1` double(24,8) default '0.00000000',
  `localtax2` double(24,8) default '0.00000000',
  `total` double(24,8) default '0.00000000',
  `total_ht` double(24,8) default '0.00000000',
  `total_tva` double(24,8) default '0.00000000',
  `total_ttc` double(24,8) default '0.00000000',
  `fk_statut` smallint(6) NOT NULL default '0',
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `fk_user_valid` int(11) default NULL,
  `fk_facture_source` int(11) default NULL,
  `fk_projet` int(11) default NULL,
  `fk_account` int(11) default NULL,
  `fk_cond_reglement` int(11) default NULL,
  `fk_mode_reglement` int(11) default NULL,
  `date_lim_reglement` date default NULL,
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `fk_incoterms` int(11) default NULL,
  `location_incoterms` varchar(255) collate utf8_unicode_ci default NULL,
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  `last_main_doc` varchar(255) collate utf8_unicode_ci default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `extraparams` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_multicurrency` int(11) default NULL,
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_tx` double(24,8) default '1.00000000',
  `multicurrency_total_ht` double(24,8) default '0.00000000',
  `multicurrency_total_tva` double(24,8) default '0.00000000',
  `multicurrency_total_ttc` double(24,8) default '0.00000000',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_facture_fourn_ref` (`ref`,`entity`),
  UNIQUE KEY `uk_facture_fourn_ref_supplier` (`ref_supplier`,`fk_soc`,`entity`),
  KEY `idx_facture_fourn_date_lim_reglement` (`date_lim_reglement`),
  KEY `idx_facture_fourn_fk_soc` (`fk_soc`),
  KEY `idx_facture_fourn_fk_user_author` (`fk_user_author`),
  KEY `idx_facture_fourn_fk_user_valid` (`fk_user_valid`),
  KEY `idx_facture_fourn_fk_projet` (`fk_projet`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_facture_fourn_det`
--

CREATE TABLE `llx_facture_fourn_det` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_facture_fourn` int(11) NOT NULL,
  `fk_parent_line` int(11) default NULL,
  `fk_product` int(11) default NULL,
  `ref` varchar(50) collate utf8_unicode_ci default NULL,
  `label` varchar(255) collate utf8_unicode_ci default NULL,
  `description` text collate utf8_unicode_ci,
  `pu_ht` double(24,8) default NULL,
  `pu_ttc` double(24,8) default NULL,
  `qty` double default NULL,
  `remise_percent` double default '0',
  `vat_src_code` varchar(10) collate utf8_unicode_ci default '',
  `tva_tx` double(6,3) default NULL,
  `localtax1_tx` double(6,3) default '0.000',
  `localtax1_type` varchar(10) collate utf8_unicode_ci default NULL,
  `localtax2_tx` double(6,3) default '0.000',
  `localtax2_type` varchar(10) collate utf8_unicode_ci default NULL,
  `total_ht` double(24,8) default NULL,
  `tva` double(24,8) default NULL,
  `total_localtax1` double(24,8) default '0.00000000',
  `total_localtax2` double(24,8) default '0.00000000',
  `total_ttc` double(24,8) default NULL,
  `product_type` int(11) default '0',
  `date_start` datetime default NULL,
  `date_end` datetime default NULL,
  `info_bits` int(11) default '0',
  `fk_code_ventilation` int(11) NOT NULL default '0',
  `special_code` int(11) default '0',
  `rang` int(11) default '0',
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `fk_unit` int(11) default NULL,
  `fk_multicurrency` int(11) default NULL,
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_subprice` double(24,8) default '0.00000000',
  `multicurrency_total_ht` double(24,8) default '0.00000000',
  `multicurrency_total_tva` double(24,8) default '0.00000000',
  `multicurrency_total_ttc` double(24,8) default '0.00000000',
  PRIMARY KEY  (`rowid`),
  KEY `idx_facture_fourn_det_fk_facture` (`fk_facture_fourn`),
  KEY `idx_facture_fourn_det_fk_product` (`fk_product`),
  KEY `idx_facture_fourn_det_fk_code_ventilation` (`fk_code_ventilation`),
  KEY `fk_facture_fourn_det_fk_unit` (`fk_unit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_facture_fourn_det_extrafields`
--

CREATE TABLE `llx_facture_fourn_det_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_facture_fourn_det_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_facture_fourn_extrafields`
--

CREATE TABLE `llx_facture_fourn_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_facture_fourn_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_facture_rec`
--

CREATE TABLE `llx_facture_rec` (
  `rowid` int(11) NOT NULL auto_increment,
  `titre` varchar(100) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `fk_soc` int(11) NOT NULL,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `suspended` int(11) default '0',
  `amount` double(24,8) NOT NULL default '0.00000000',
  `remise` double default '0',
  `remise_percent` double default '0',
  `remise_absolue` double default '0',
  `vat_src_code` varchar(10) collate utf8_unicode_ci default '',
  `tva` double(24,8) default '0.00000000',
  `localtax1` double(24,8) default '0.00000000',
  `localtax2` double(24,8) default '0.00000000',
  `revenuestamp` double(24,8) default '0.00000000',
  `total` double(24,8) default '0.00000000',
  `total_ttc` double(24,8) default '0.00000000',
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `fk_projet` int(11) default NULL,
  `fk_cond_reglement` int(11) default '0',
  `fk_mode_reglement` int(11) default '0',
  `date_lim_reglement` date default NULL,
  `fk_account` int(11) default NULL,
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `modelpdf` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_multicurrency` int(11) default NULL,
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_tx` double(24,8) default '1.00000000',
  `multicurrency_total_ht` double(24,8) default '0.00000000',
  `multicurrency_total_tva` double(24,8) default '0.00000000',
  `multicurrency_total_ttc` double(24,8) default '0.00000000',
  `usenewprice` int(11) default '0',
  `frequency` int(11) default NULL,
  `unit_frequency` varchar(2) collate utf8_unicode_ci default 'm',
  `date_when` datetime default NULL,
  `date_last_gen` datetime default NULL,
  `nb_gen_done` int(11) default NULL,
  `nb_gen_max` int(11) default NULL,
  `auto_validate` int(11) default '0',
  `generate_pdf` int(11) default '1',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `idx_facture_rec_uk_titre` (`titre`,`entity`),
  KEY `idx_facture_rec_fk_soc` (`fk_soc`),
  KEY `idx_facture_rec_fk_user_author` (`fk_user_author`),
  KEY `idx_facture_rec_fk_projet` (`fk_projet`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_facture_rec_extrafields`
--

CREATE TABLE `llx_facture_rec_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_facture_rec_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_fichinter`
--

CREATE TABLE `llx_fichinter` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_soc` int(11) NOT NULL,
  `fk_projet` int(11) default '0',
  `fk_contrat` int(11) default '0',
  `ref` varchar(30) collate utf8_unicode_ci NOT NULL,
  `ref_ext` varchar(255) collate utf8_unicode_ci default NULL,
  `entity` int(11) NOT NULL default '1',
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datec` datetime default NULL,
  `date_valid` datetime default NULL,
  `datei` date default NULL,
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `fk_user_valid` int(11) default NULL,
  `fk_statut` smallint(6) default '0',
  `dateo` date default NULL,
  `datee` date default NULL,
  `datet` date default NULL,
  `duree` double default NULL,
  `description` text collate utf8_unicode_ci,
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  `last_main_doc` varchar(255) collate utf8_unicode_ci default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `extraparams` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_fichinter_ref` (`ref`,`entity`),
  KEY `idx_fichinter_fk_soc` (`fk_soc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_fichinterdet`
--

CREATE TABLE `llx_fichinterdet` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_fichinter` int(11) default NULL,
  `fk_parent_line` int(11) default NULL,
  `date` datetime default NULL,
  `description` text collate utf8_unicode_ci,
  `duree` int(11) default NULL,
  `rang` int(11) default '0',
  PRIMARY KEY  (`rowid`),
  KEY `idx_fichinterdet_fk_fichinter` (`fk_fichinter`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_fichinterdet_extrafields`
--

CREATE TABLE `llx_fichinterdet_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_ficheinterdet_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_fichinterdet_rec`
--

CREATE TABLE `llx_fichinterdet_rec` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_fichinter` int(11) NOT NULL,
  `date` datetime default NULL,
  `description` text collate utf8_unicode_ci,
  `duree` int(11) default NULL,
  `rang` int(11) default '0',
  `total_ht` double(24,8) default NULL,
  `subprice` double(24,8) default NULL,
  `fk_parent_line` int(11) default NULL,
  `fk_product` int(11) default NULL,
  `label` varchar(255) collate utf8_unicode_ci default NULL,
  `tva_tx` double(6,3) default NULL,
  `localtax1_tx` double(6,3) default '0.000',
  `localtax1_type` varchar(1) collate utf8_unicode_ci default NULL,
  `localtax2_tx` double(6,3) default '0.000',
  `localtax2_type` varchar(1) collate utf8_unicode_ci default NULL,
  `qty` double default NULL,
  `remise_percent` double default '0',
  `remise` double default '0',
  `fk_remise_except` int(11) default NULL,
  `price` double(24,8) default NULL,
  `total_tva` double(24,8) default NULL,
  `total_localtax1` double(24,8) default '0.00000000',
  `total_localtax2` double(24,8) default '0.00000000',
  `total_ttc` double(24,8) default NULL,
  `product_type` int(11) default '0',
  `date_start` datetime default NULL,
  `date_end` datetime default NULL,
  `info_bits` int(11) default '0',
  `buy_price_ht` double(24,8) default '0.00000000',
  `fk_product_fournisseur_price` int(11) default NULL,
  `fk_code_ventilation` int(11) NOT NULL default '0',
  `fk_export_commpta` int(11) NOT NULL default '0',
  `special_code` int(10) unsigned default '0',
  `fk_unit` int(11) default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_fichinter_extrafields`
--

CREATE TABLE `llx_fichinter_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_ficheinter_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_fichinter_rec`
--

CREATE TABLE `llx_fichinter_rec` (
  `rowid` int(11) NOT NULL auto_increment,
  `titre` varchar(50) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `fk_soc` int(11) default NULL,
  `datec` datetime default NULL,
  `fk_contrat` int(11) default '0',
  `fk_user_author` int(11) default NULL,
  `fk_projet` int(11) default NULL,
  `duree` double default NULL,
  `description` text collate utf8_unicode_ci,
  `modelpdf` varchar(50) collate utf8_unicode_ci default NULL,
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `frequency` int(11) default NULL,
  `unit_frequency` varchar(2) collate utf8_unicode_ci default 'm',
  `date_when` datetime default NULL,
  `date_last_gen` datetime default NULL,
  `nb_gen_done` int(11) default NULL,
  `nb_gen_max` int(11) default NULL,
  `auto_validate` int(11) default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `idx_fichinter_rec_uk_titre` (`titre`,`entity`),
  KEY `idx_fichinter_rec_fk_soc` (`fk_soc`),
  KEY `idx_fichinter_rec_fk_user_author` (`fk_user_author`),
  KEY `idx_fichinter_rec_fk_projet` (`fk_projet`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_holiday`
--

CREATE TABLE `llx_holiday` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(30) collate utf8_unicode_ci default NULL,
  `ref_ext` varchar(255) collate utf8_unicode_ci default NULL,
  `entity` int(11) NOT NULL default '1',
  `fk_user` int(11) NOT NULL,
  `fk_user_create` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `fk_type` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `description` varchar(255) collate utf8_unicode_ci NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `halfday` int(11) default '0',
  `statut` int(11) NOT NULL default '1',
  `fk_validator` int(11) NOT NULL,
  `date_valid` datetime default NULL,
  `fk_user_valid` int(11) default NULL,
  `date_refuse` datetime default NULL,
  `fk_user_refuse` int(11) default NULL,
  `date_cancel` datetime default NULL,
  `fk_user_cancel` int(11) default NULL,
  `detail_refuse` varchar(250) collate utf8_unicode_ci default NULL,
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `extraparams` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_holiday_entity` (`entity`),
  KEY `idx_holiday_fk_user` (`fk_user`),
  KEY `idx_holiday_fk_user_create` (`fk_user_create`),
  KEY `idx_holiday_date_create` (`date_create`),
  KEY `idx_holiday_date_debut` (`date_debut`),
  KEY `idx_holiday_date_fin` (`date_fin`),
  KEY `idx_holiday_fk_validator` (`fk_validator`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_holiday_config`
--

CREATE TABLE `llx_holiday_config` (
  `rowid` int(11) NOT NULL auto_increment,
  `name` varchar(128) collate utf8_unicode_ci NOT NULL,
  `value` text collate utf8_unicode_ci,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `idx_holiday_config` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `llx_holiday_config`
--

INSERT INTO `llx_holiday_config` (`rowid`, `name`, `value`) VALUES
(1, 'lastUpdate', '20190831155437');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_holiday_logs`
--

CREATE TABLE `llx_holiday_logs` (
  `rowid` int(11) NOT NULL auto_increment,
  `date_action` datetime NOT NULL,
  `fk_user_action` int(11) NOT NULL,
  `fk_user_update` int(11) NOT NULL,
  `fk_type` int(11) NOT NULL,
  `type_action` varchar(255) collate utf8_unicode_ci NOT NULL,
  `prev_solde` varchar(255) collate utf8_unicode_ci NOT NULL,
  `new_solde` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_holiday_users`
--

CREATE TABLE `llx_holiday_users` (
  `fk_user` int(11) NOT NULL,
  `fk_type` int(11) NOT NULL,
  `nb_holiday` double NOT NULL default '0',
  UNIQUE KEY `uk_holiday_users` (`fk_user`,`fk_type`,`nb_holiday`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_import_model`
--

CREATE TABLE `llx_import_model` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_user` int(11) NOT NULL default '0',
  `label` varchar(50) collate utf8_unicode_ci NOT NULL,
  `type` varchar(50) collate utf8_unicode_ci NOT NULL,
  `field` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_import_model` (`label`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_inventory`
--

CREATE TABLE `llx_inventory` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) default '0',
  `ref` varchar(48) collate utf8_unicode_ci default NULL,
  `date_creation` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `fk_user_valid` int(11) default NULL,
  `fk_warehouse` int(11) default NULL,
  `fk_product` int(11) default NULL,
  `status` int(11) default '0',
  `title` varchar(255) collate utf8_unicode_ci NOT NULL,
  `date_inventory` datetime default NULL,
  `date_validation` datetime default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_inventory_ref` (`ref`,`entity`),
  KEY `idx_inventory_tms` (`tms`),
  KEY `idx_inventory_date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_inventorydet`
--

CREATE TABLE `llx_inventorydet` (
  `rowid` int(11) NOT NULL auto_increment,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_inventory` int(11) default '0',
  `fk_warehouse` int(11) default '0',
  `fk_product` int(11) default '0',
  `batch` varchar(30) collate utf8_unicode_ci default NULL,
  `qty_view` double default NULL,
  `qty_stock` double default NULL,
  `qty_regulated` double default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_inventorydet_tms` (`tms`),
  KEY `idx_inventorydet_datec` (`datec`),
  KEY `idx_inventorydet_fk_inventory` (`fk_inventory`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_links`
--

CREATE TABLE `llx_links` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `datea` datetime NOT NULL,
  `url` varchar(255) collate utf8_unicode_ci NOT NULL,
  `label` varchar(255) collate utf8_unicode_ci NOT NULL,
  `objecttype` varchar(255) collate utf8_unicode_ci NOT NULL,
  `objectid` int(11) NOT NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_links` (`objectid`,`label`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_livraison`
--

CREATE TABLE `llx_livraison` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `ref` varchar(30) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `fk_soc` int(11) NOT NULL,
  `ref_ext` varchar(255) collate utf8_unicode_ci default NULL,
  `ref_int` varchar(255) collate utf8_unicode_ci default NULL,
  `ref_customer` varchar(255) collate utf8_unicode_ci default NULL,
  `date_creation` datetime default NULL,
  `fk_user_author` int(11) default NULL,
  `date_valid` datetime default NULL,
  `fk_user_valid` int(11) default NULL,
  `date_delivery` datetime default NULL,
  `fk_address` int(11) default NULL,
  `fk_statut` smallint(6) default '0',
  `total_ht` double(24,8) default '0.00000000',
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  `last_main_doc` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_incoterms` int(11) default NULL,
  `location_incoterms` varchar(255) collate utf8_unicode_ci default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `extraparams` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `idx_livraison_uk_ref` (`ref`,`entity`),
  KEY `idx_livraison_fk_soc` (`fk_soc`),
  KEY `idx_livraison_fk_user_author` (`fk_user_author`),
  KEY `idx_livraison_fk_user_valid` (`fk_user_valid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_livraisondet`
--

CREATE TABLE `llx_livraisondet` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_livraison` int(11) default NULL,
  `fk_origin_line` int(11) default NULL,
  `fk_product` int(11) default NULL,
  `description` text collate utf8_unicode_ci,
  `qty` double default NULL,
  `subprice` double(24,8) default '0.00000000',
  `total_ht` double(24,8) default '0.00000000',
  `rang` int(11) default '0',
  PRIMARY KEY  (`rowid`),
  KEY `idx_livraisondet_fk_expedition` (`fk_livraison`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_livraisondet_extrafields`
--

CREATE TABLE `llx_livraisondet_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_livraisondet_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_livraison_extrafields`
--

CREATE TABLE `llx_livraison_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_livraison_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_loan`
--

CREATE TABLE `llx_loan` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `label` varchar(80) collate utf8_unicode_ci NOT NULL,
  `fk_bank` int(11) default NULL,
  `capital` double(24,8) NOT NULL default '0.00000000',
  `insurance_amount` double(24,8) default '0.00000000',
  `datestart` date default NULL,
  `dateend` date default NULL,
  `nbterm` double default NULL,
  `rate` double NOT NULL,
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `capital_position` double(24,8) default '0.00000000',
  `date_position` date default NULL,
  `paid` smallint(6) NOT NULL default '0',
  `accountancy_account_capital` varchar(32) collate utf8_unicode_ci default NULL,
  `accountancy_account_insurance` varchar(32) collate utf8_unicode_ci default NULL,
  `accountancy_account_interest` varchar(32) collate utf8_unicode_ci default NULL,
  `fk_projet` int(11) default NULL,
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `active` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_loan_schedule`
--

CREATE TABLE `llx_loan_schedule` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_loan` int(11) default NULL,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datep` datetime default NULL,
  `amount_capital` double(24,8) default '0.00000000',
  `amount_insurance` double(24,8) default '0.00000000',
  `amount_interest` double(24,8) default '0.00000000',
  `fk_typepayment` int(11) NOT NULL,
  `num_payment` varchar(50) collate utf8_unicode_ci default NULL,
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `fk_bank` int(11) NOT NULL,
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_localtax`
--

CREATE TABLE `llx_localtax` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `localtaxtype` tinyint(4) default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datep` date default NULL,
  `datev` date default NULL,
  `amount` double default NULL,
  `label` varchar(255) collate utf8_unicode_ci default NULL,
  `note` text collate utf8_unicode_ci,
  `fk_bank` int(11) default NULL,
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_mailing`
--

CREATE TABLE `llx_mailing` (
  `rowid` int(11) NOT NULL auto_increment,
  `statut` smallint(6) default '0',
  `titre` varchar(128) collate utf8_unicode_ci default NULL,
  `entity` int(11) NOT NULL default '1',
  `sujet` varchar(128) collate utf8_unicode_ci default NULL,
  `body` mediumtext collate utf8_unicode_ci,
  `bgcolor` varchar(8) collate utf8_unicode_ci default NULL,
  `bgimage` varchar(255) collate utf8_unicode_ci default NULL,
  `cible` varchar(60) collate utf8_unicode_ci default NULL,
  `nbemail` int(11) default NULL,
  `email_from` varchar(160) collate utf8_unicode_ci default NULL,
  `email_replyto` varchar(160) collate utf8_unicode_ci default NULL,
  `email_errorsto` varchar(160) collate utf8_unicode_ci default NULL,
  `tag` varchar(128) collate utf8_unicode_ci default NULL,
  `date_creat` datetime default NULL,
  `date_valid` datetime default NULL,
  `date_appro` datetime default NULL,
  `date_envoi` datetime default NULL,
  `fk_user_creat` int(11) default NULL,
  `fk_user_valid` int(11) default NULL,
  `fk_user_appro` int(11) default NULL,
  `extraparams` varchar(255) collate utf8_unicode_ci default NULL,
  `joined_file1` varchar(255) collate utf8_unicode_ci default NULL,
  `joined_file2` varchar(255) collate utf8_unicode_ci default NULL,
  `joined_file3` varchar(255) collate utf8_unicode_ci default NULL,
  `joined_file4` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_mailing_cibles`
--

CREATE TABLE `llx_mailing_cibles` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_mailing` int(11) NOT NULL,
  `fk_contact` int(11) NOT NULL,
  `lastname` varchar(160) collate utf8_unicode_ci default NULL,
  `firstname` varchar(160) collate utf8_unicode_ci default NULL,
  `email` varchar(160) collate utf8_unicode_ci NOT NULL,
  `other` varchar(255) collate utf8_unicode_ci default NULL,
  `tag` varchar(128) collate utf8_unicode_ci default NULL,
  `statut` smallint(6) NOT NULL default '0',
  `source_url` varchar(255) collate utf8_unicode_ci default NULL,
  `source_id` int(11) default NULL,
  `source_type` varchar(16) collate utf8_unicode_ci default NULL,
  `date_envoi` datetime default NULL,
  `error_text` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_mailing_cibles` (`fk_mailing`,`email`),
  KEY `idx_mailing_cibles_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_mailing_unsubscribe`
--

CREATE TABLE `llx_mailing_unsubscribe` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `unsubscribegroup` varchar(128) collate utf8_unicode_ci default '',
  `ip` varchar(128) collate utf8_unicode_ci default NULL,
  `date_creat` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_mailing_unsubscribe` (`email`,`entity`,`unsubscribegroup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_menu`
--

CREATE TABLE `llx_menu` (
  `rowid` int(11) NOT NULL auto_increment,
  `menu_handler` varchar(16) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `module` varchar(64) collate utf8_unicode_ci default NULL,
  `type` varchar(4) collate utf8_unicode_ci NOT NULL,
  `mainmenu` varchar(100) collate utf8_unicode_ci NOT NULL,
  `leftmenu` varchar(100) collate utf8_unicode_ci default NULL,
  `fk_menu` int(11) NOT NULL,
  `fk_mainmenu` varchar(100) collate utf8_unicode_ci default NULL,
  `fk_leftmenu` varchar(100) collate utf8_unicode_ci default NULL,
  `position` int(11) NOT NULL,
  `url` varchar(255) collate utf8_unicode_ci NOT NULL,
  `target` varchar(100) collate utf8_unicode_ci default NULL,
  `titre` varchar(255) collate utf8_unicode_ci NOT NULL,
  `langs` varchar(100) collate utf8_unicode_ci default NULL,
  `level` smallint(6) default NULL,
  `perms` text collate utf8_unicode_ci,
  `enabled` varchar(255) collate utf8_unicode_ci default '1',
  `usertype` int(11) NOT NULL default '0',
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `idx_menu_uk_menu` (`menu_handler`,`fk_menu`,`position`,`url`,`entity`),
  KEY `idx_menu_menuhandler_type` (`menu_handler`,`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=352 ;

--
-- Volcado de datos para la tabla `llx_menu`
--

INSERT INTO `llx_menu` (`rowid`, `menu_handler`, `entity`, `module`, `type`, `mainmenu`, `leftmenu`, `fk_menu`, `fk_mainmenu`, `fk_leftmenu`, `position`, `url`, `target`, `titre`, `langs`, `level`, `perms`, `enabled`, `usertype`, `tms`) VALUES
(15, 'all', 1, 'resource', 'left', 'tools', 'resource', -1, 'tools', NULL, 100, '/resource/list.php', '', 'MenuResourceIndex', 'resource', NULL, '$user->rights->resource->read', '1', 0, '2019-07-29 14:32:32'),
(16, 'all', 1, 'resource', 'left', 'tools', 'resource_add', -1, 'tools', 'resource', 101, '/resource/card.php?action=create', '', 'MenuResourceAdd', 'resource', NULL, '$user->rights->resource->write', '1', 0, '2019-07-29 14:32:32'),
(17, 'all', 1, 'resource', 'left', 'tools', 'resource_list', -1, 'tools', 'resource', 102, '/resource/list.php', '', 'List', 'resource', NULL, '$user->rights->resource->read', '1', 0, '2019-07-29 14:32:32'),
(18, 'all', 1, 'modulebuilder', 'left', 'home', 'admintools_modulebuilder', -1, 'home', 'admintools', 100, '/modulebuilder/index.php?mainmenu=home&amp;leftmenu=admintools', '_modulebuilder', 'ModuleBuilder', 'modulebuilder', NULL, '1', '$conf->modulebuilder->enabled && preg_match(''/^(admintools|all)/'',$leftmenu) && ($user->admin || $conf->global->MODULEBUILDER_FOREVERYONE)', 0, '2019-07-29 14:32:52'),
(213, 'eldy', 1, '', 'left', '', NULL, 500100, NULL, NULL, 100, '/actividades/actividadesindex.php', '', 'Actividades', '', NULL, '1', '1', 0, '2019-08-03 10:37:48'),
(324, 'all', 1, 'actividades', 'top', 'actividades', NULL, 0, NULL, NULL, 1000, '/actividades/actividadesindex.php', '', 'Actividades', 'actividades@actividades', NULL, '1', '$conf->actividades->enabled', 0, '2019-08-30 13:25:33'),
(325, 'all', 1, 'actividades', 'left', 'actividades', 'actividades_actividad', 324, NULL, NULL, 1001, '/actividades/actividadesindex.php', '', 'Actividades', 'actividades@actividades', NULL, '1', '$conf->actividades->enabled', 0, '2019-08-30 13:25:33'),
(326, 'all', 1, 'actividades', 'left', 'actividades', 'actividades_actividad', 325, NULL, NULL, 1002, '/actividades/actividad_card.php?action=create', '', 'Nueva Actividad', 'actividades@actividades', NULL, '1', '$conf->actividades->enabled', 0, '2019-08-30 13:25:33'),
(327, 'all', 1, 'actividades', 'left', 'actividades', 'actividades_actividad', 325, NULL, NULL, 1003, '/actividades/actividad_list.php', '', 'Listado', 'actividades@actividades', NULL, '1', '$conf->actividades->enabled', 0, '2019-08-30 13:25:33'),
(328, 'all', 1, 'actividades', 'left', 'actividades', 'organizadores', -1, 'actividades', NULL, 1104, '/actividades/organizadoresindex.php', '', 'Organizadores', 'actividades@actividades', NULL, '1', '$conf->actividades->enabled', 0, '2019-08-30 13:25:33'),
(329, 'all', 1, 'actividades', 'left', 'actividades', 'organizadores_nuevo', -1, 'actividades', 'organizadores', 1105, '/actividades/organizador_card.php?action=create', '', 'Nuevo Organizador', 'actividades@actividades', NULL, '1', '$conf->actividades->enabled', 0, '2019-08-30 13:25:33'),
(330, 'all', 1, 'actividades', 'left', 'actividades', 'organizadores_lista', -1, 'actividades', 'organizadores', 1106, '/actividades/organizador_list.php', '', 'Listado', 'actividades@actividades', NULL, '1', '$conf->actividades->enabled', 0, '2019-08-30 13:25:33'),
(331, 'all', 1, 'actividades', 'left', 'actividades', 'asistentes', -1, 'actividades', NULL, 1207, '/actividades/asistente_list.php', '', 'Asistentes', 'actividades@actividades', NULL, '1', '$conf->actividades->enabled', 0, '2019-08-30 13:25:33'),
(332, 'all', 1, 'actividades', 'left', 'actividades', 'asistentes_nuevo', -1, 'actividades', 'asistentes', 1208, '/actividades/asistente_card.php?action=create', '', 'Nuevo Asistente', 'actividades@actividades', NULL, '1', '$conf->actividades->enabled', 0, '2019-08-30 13:25:33'),
(333, 'all', 1, 'actividades', 'left', 'actividades', 'asistentes_lista', -1, 'actividades', 'asistentes', 1209, '/actividades/asistente_list.php', '', 'Listado', 'actividades@actividades', NULL, '1', '$conf->actividades->enabled', 0, '2019-08-30 13:25:33'),
(343, 'all', 1, 'agenda', 'top', 'agenda', NULL, 0, NULL, NULL, 86, '/comm/action/index.php', '', 'TMenuAgenda', 'agenda', NULL, '$user->rights->agenda->myactions->read', '$conf->agenda->enabled', 2, '2019-09-07 06:21:17'),
(344, 'all', 1, 'agenda', 'left', 'agenda', NULL, 343, NULL, NULL, 100, '/comm/action/index.php?mainmenu=agenda&amp;leftmenu=agenda', '', 'Actions', 'agenda', NULL, '$user->rights->agenda->myactions->read', '$conf->agenda->enabled', 2, '2019-09-07 06:21:17'),
(345, 'all', 1, 'agenda', 'left', 'agenda', NULL, 344, NULL, NULL, 101, '/comm/action/card.php?mainmenu=agenda&amp;leftmenu=agenda&amp;action=create', '', 'Nueva actuacion', 'agenda', NULL, '($user->rights->agenda->myactions->create||$user->rights->agenda->allactions->create)', '$conf->agenda->enabled', 2, '2019-09-07 06:21:17'),
(346, 'all', 1, 'agenda', 'left', 'agenda', NULL, 344, NULL, NULL, 140, '/comm/action/index.php?action=default&amp;mainmenu=agenda&amp;leftmenu=agenda', '', 'Calendar', 'agenda', NULL, '$user->rights->agenda->myactions->read', '$conf->agenda->enabled', 2, '2019-09-07 06:21:17'),
(347, 'all', 1, 'agenda', 'left', 'agenda', NULL, 346, NULL, NULL, 141, '/comm/action/index.php?action=default&amp;mainmenu=agenda&amp;leftmenu=agenda&amp;status=todo&amp;filter=mine', '', 'MenuToDoMyActions', 'agenda', NULL, '$user->rights->agenda->myactions->read', '$conf->agenda->enabled', 2, '2019-09-07 06:21:17'),
(348, 'all', 1, 'agenda', 'left', 'agenda', NULL, 346, NULL, NULL, 142, '/comm/action/index.php?action=default&amp;mainmenu=agenda&amp;leftmenu=agenda&amp;status=done&amp;filter=mine', '', 'MenuDoneMyActions', 'agenda', NULL, '$user->rights->agenda->myactions->read', '$conf->agenda->enabled', 2, '2019-09-07 06:21:17'),
(349, 'all', 1, 'agenda', 'left', 'agenda', NULL, 346, NULL, NULL, 143, '/comm/action/index.php?action=default&amp;mainmenu=agenda&amp;leftmenu=agenda&amp;status=todo&amp;filtert=-1', '', 'MenuToDoActions', 'agenda', NULL, '$user->rights->agenda->allactions->read', '$user->rights->agenda->allactions->read', 2, '2019-09-07 06:21:17'),
(350, 'all', 1, 'agenda', 'left', 'agenda', NULL, 346, NULL, NULL, 144, '/comm/action/index.php?action=default&amp;mainmenu=agenda&amp;leftmenu=agenda&amp;status=done&amp;filtert=-1', '', 'MenuDoneActions', 'agenda', NULL, '$user->rights->agenda->allactions->read', '$user->rights->agenda->allactions->read', 2, '2019-09-07 06:21:17'),
(351, 'all', 1, 'agenda', 'left', 'agenda', NULL, 344, NULL, NULL, 160, '/comm/action/rapport/index.php?mainmenu=agenda&amp;leftmenu=agenda', '', 'Reportings', 'agenda', NULL, '$user->rights->agenda->allactions->read', '$conf->agenda->enabled', 2, '2019-09-07 06:21:17');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_multicurrency`
--

CREATE TABLE `llx_multicurrency` (
  `rowid` int(11) NOT NULL auto_increment,
  `date_create` datetime default NULL,
  `code` varchar(255) collate utf8_unicode_ci default NULL,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `entity` int(11) default '1',
  `fk_user` int(11) default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_multicurrency_rate`
--

CREATE TABLE `llx_multicurrency_rate` (
  `rowid` int(11) NOT NULL auto_increment,
  `date_sync` datetime default NULL,
  `rate` double NOT NULL default '0',
  `fk_multicurrency` int(11) NOT NULL,
  `entity` int(11) default '1',
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_notify`
--

CREATE TABLE `llx_notify` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `daten` datetime default NULL,
  `fk_action` int(11) NOT NULL,
  `fk_soc` int(11) default NULL,
  `fk_contact` int(11) default NULL,
  `fk_user` int(11) default NULL,
  `type` varchar(16) collate utf8_unicode_ci default 'email',
  `type_target` varchar(16) collate utf8_unicode_ci default NULL,
  `objet_type` varchar(24) collate utf8_unicode_ci NOT NULL,
  `objet_id` int(11) NOT NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_notify_def`
--

CREATE TABLE `llx_notify_def` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datec` date default NULL,
  `fk_action` int(11) NOT NULL,
  `fk_soc` int(11) default NULL,
  `fk_contact` int(11) default NULL,
  `fk_user` int(11) default NULL,
  `type` varchar(16) collate utf8_unicode_ci default 'email',
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_notify_def_object`
--

CREATE TABLE `llx_notify_def_object` (
  `id` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `objet_type` varchar(16) collate utf8_unicode_ci default NULL,
  `objet_id` int(11) NOT NULL,
  `type_notif` varchar(16) collate utf8_unicode_ci default 'browser',
  `date_notif` datetime default NULL,
  `user_id` int(11) default NULL,
  `moreparam` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_oauth_state`
--

CREATE TABLE `llx_oauth_state` (
  `rowid` int(11) NOT NULL auto_increment,
  `service` varchar(36) collate utf8_unicode_ci default NULL,
  `state` varchar(128) collate utf8_unicode_ci default NULL,
  `fk_user` int(11) default NULL,
  `fk_adherent` int(11) default NULL,
  `entity` int(11) default '1',
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_oauth_token`
--

CREATE TABLE `llx_oauth_token` (
  `rowid` int(11) NOT NULL auto_increment,
  `service` varchar(36) collate utf8_unicode_ci default NULL,
  `token` text collate utf8_unicode_ci,
  `tokenstring` text collate utf8_unicode_ci,
  `fk_user` int(11) default NULL,
  `fk_adherent` int(11) default NULL,
  `entity` int(11) default '1',
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_onlinesignature`
--

CREATE TABLE `llx_onlinesignature` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `object_type` varchar(32) collate utf8_unicode_ci NOT NULL,
  `object_id` int(11) NOT NULL,
  `datec` datetime NOT NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `ip` varchar(128) collate utf8_unicode_ci default NULL,
  `pathoffile` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_opensurvey_comments`
--

CREATE TABLE `llx_opensurvey_comments` (
  `id_comment` int(10) unsigned NOT NULL auto_increment,
  `id_sondage` char(16) collate utf8_unicode_ci NOT NULL,
  `comment` text collate utf8_unicode_ci NOT NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `usercomment` text collate utf8_unicode_ci,
  PRIMARY KEY  (`id_comment`),
  KEY `idx_id_comment` (`id_comment`),
  KEY `idx_id_sondage` (`id_sondage`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_opensurvey_formquestions`
--

CREATE TABLE `llx_opensurvey_formquestions` (
  `rowid` int(11) NOT NULL auto_increment,
  `id_sondage` varchar(16) collate utf8_unicode_ci default NULL,
  `question` text collate utf8_unicode_ci,
  `available_answers` text collate utf8_unicode_ci,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_opensurvey_sondage`
--

CREATE TABLE `llx_opensurvey_sondage` (
  `id_sondage` varchar(16) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `commentaires` text collate utf8_unicode_ci,
  `mail_admin` varchar(128) collate utf8_unicode_ci default NULL,
  `nom_admin` varchar(64) collate utf8_unicode_ci default NULL,
  `fk_user_creat` int(11) NOT NULL,
  `titre` text collate utf8_unicode_ci NOT NULL,
  `date_fin` datetime default NULL,
  `status` int(11) default '1',
  `format` varchar(2) collate utf8_unicode_ci NOT NULL,
  `mailsonde` tinyint(4) NOT NULL default '0',
  `allow_comments` tinyint(4) NOT NULL default '1',
  `allow_spy` tinyint(4) NOT NULL default '1',
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `sujet` text collate utf8_unicode_ci,
  PRIMARY KEY  (`id_sondage`),
  KEY `idx_date_fin` (`date_fin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_opensurvey_user_formanswers`
--

CREATE TABLE `llx_opensurvey_user_formanswers` (
  `fk_user_survey` int(11) NOT NULL,
  `fk_question` int(11) NOT NULL,
  `reponses` text collate utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_opensurvey_user_studs`
--

CREATE TABLE `llx_opensurvey_user_studs` (
  `id_users` int(11) NOT NULL auto_increment,
  `nom` varchar(64) collate utf8_unicode_ci NOT NULL,
  `id_sondage` varchar(16) collate utf8_unicode_ci NOT NULL,
  `reponses` varchar(100) collate utf8_unicode_ci NOT NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id_users`),
  KEY `idx_opensurvey_user_studs_id_users` (`id_users`),
  KEY `idx_opensurvey_user_studs_nom` (`nom`),
  KEY `idx_opensurvey_user_studs_id_sondage` (`id_sondage`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_organizador_actividades`
--

CREATE TABLE `llx_organizador_actividades` (
  `rowid` int(11) NOT NULL auto_increment,
  `organizador` int(11) NOT NULL,
  `actividad` int(11) NOT NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `rowid` (`rowid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=31 ;

--
-- Volcado de datos para la tabla `llx_organizador_actividades`
--

INSERT INTO `llx_organizador_actividades` (`rowid`, `organizador`, `actividad`) VALUES
(2, 13, 41),
(25, 12, 43),
(26, 9, 49),
(27, 6, 49),
(28, 15, 48),
(29, 14, 50),
(30, 6, 45);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_overwrite_trans`
--

CREATE TABLE `llx_overwrite_trans` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `lang` varchar(5) collate utf8_unicode_ci default NULL,
  `transkey` varchar(128) collate utf8_unicode_ci default NULL,
  `transvalue` text collate utf8_unicode_ci,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_overwrite_trans` (`lang`,`transkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_paiement`
--

CREATE TABLE `llx_paiement` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(30) collate utf8_unicode_ci default NULL,
  `entity` int(11) NOT NULL default '1',
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datep` datetime default NULL,
  `amount` double(24,8) default '0.00000000',
  `multicurrency_amount` double(24,8) default '0.00000000',
  `fk_paiement` int(11) NOT NULL,
  `num_paiement` varchar(50) collate utf8_unicode_ci default NULL,
  `note` text collate utf8_unicode_ci,
  `ext_payment_id` varchar(128) collate utf8_unicode_ci default NULL,
  `ext_payment_site` varchar(128) collate utf8_unicode_ci default NULL,
  `fk_bank` int(11) NOT NULL default '0',
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `statut` smallint(6) NOT NULL default '0',
  `fk_export_compta` int(11) NOT NULL default '0',
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_paiementcharge`
--

CREATE TABLE `llx_paiementcharge` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_charge` int(11) default NULL,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datep` datetime default NULL,
  `amount` double(24,8) default '0.00000000',
  `fk_typepaiement` int(11) NOT NULL,
  `num_paiement` varchar(50) collate utf8_unicode_ci default NULL,
  `note` text collate utf8_unicode_ci,
  `fk_bank` int(11) NOT NULL,
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_paiementfourn`
--

CREATE TABLE `llx_paiementfourn` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(30) collate utf8_unicode_ci default NULL,
  `entity` int(11) default '1',
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datec` datetime default NULL,
  `datep` datetime default NULL,
  `amount` double(24,8) default '0.00000000',
  `multicurrency_amount` double(24,8) default '0.00000000',
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `fk_paiement` int(11) NOT NULL,
  `num_paiement` varchar(50) collate utf8_unicode_ci default NULL,
  `note` text collate utf8_unicode_ci,
  `fk_bank` int(11) NOT NULL,
  `statut` smallint(6) NOT NULL default '0',
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_paiementfourn_facturefourn`
--

CREATE TABLE `llx_paiementfourn_facturefourn` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_paiementfourn` int(11) default NULL,
  `fk_facturefourn` int(11) default NULL,
  `amount` double(24,8) default '0.00000000',
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_tx` double(24,8) default '1.00000000',
  `multicurrency_amount` double(24,8) default '0.00000000',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_paiementfourn_facturefourn` (`fk_paiementfourn`,`fk_facturefourn`),
  KEY `idx_paiementfourn_facturefourn_fk_facture` (`fk_facturefourn`),
  KEY `idx_paiementfourn_facturefourn_fk_paiement` (`fk_paiementfourn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_paiement_facture`
--

CREATE TABLE `llx_paiement_facture` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_paiement` int(11) default NULL,
  `fk_facture` int(11) default NULL,
  `amount` double(24,8) default '0.00000000',
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_tx` double(24,8) default '1.00000000',
  `multicurrency_amount` double(24,8) default '0.00000000',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_paiement_facture` (`fk_paiement`,`fk_facture`),
  KEY `idx_paiement_facture_fk_facture` (`fk_facture`),
  KEY `idx_paiement_facture_fk_paiement` (`fk_paiement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_payment_donation`
--

CREATE TABLE `llx_payment_donation` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_donation` int(11) default NULL,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datep` datetime default NULL,
  `amount` double(24,8) default '0.00000000',
  `fk_typepayment` int(11) NOT NULL,
  `num_payment` varchar(50) collate utf8_unicode_ci default NULL,
  `note` text collate utf8_unicode_ci,
  `fk_bank` int(11) NOT NULL,
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_payment_expensereport`
--

CREATE TABLE `llx_payment_expensereport` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_expensereport` int(11) default NULL,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datep` datetime default NULL,
  `amount` double(24,8) default '0.00000000',
  `fk_typepayment` int(11) NOT NULL,
  `num_payment` varchar(50) collate utf8_unicode_ci default NULL,
  `note` text collate utf8_unicode_ci,
  `fk_bank` int(11) NOT NULL,
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_payment_loan`
--

CREATE TABLE `llx_payment_loan` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_loan` int(11) default NULL,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datep` datetime default NULL,
  `amount_capital` double(24,8) default '0.00000000',
  `amount_insurance` double(24,8) default '0.00000000',
  `amount_interest` double(24,8) default '0.00000000',
  `fk_typepayment` int(11) NOT NULL,
  `num_payment` varchar(50) collate utf8_unicode_ci default NULL,
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `fk_bank` int(11) NOT NULL,
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_payment_salary`
--

CREATE TABLE `llx_payment_salary` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(30) collate utf8_unicode_ci default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datec` datetime default NULL,
  `fk_user` int(11) NOT NULL,
  `datep` date default NULL,
  `datev` date default NULL,
  `salary` double(24,8) default NULL,
  `amount` double(24,8) NOT NULL default '0.00000000',
  `fk_projet` int(11) default NULL,
  `fk_typepayment` int(11) NOT NULL,
  `num_payment` varchar(50) collate utf8_unicode_ci default NULL,
  `label` varchar(255) collate utf8_unicode_ci default NULL,
  `datesp` date default NULL,
  `dateep` date default NULL,
  `entity` int(11) NOT NULL default '1',
  `note` text collate utf8_unicode_ci,
  `fk_bank` int(11) default NULL,
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_payment_salary_ref` (`num_payment`),
  KEY `idx_payment_salary_user` (`fk_user`,`entity`),
  KEY `idx_payment_salary_datep` (`datep`),
  KEY `idx_payment_salary_datesp` (`datesp`),
  KEY `idx_payment_salary_dateep` (`dateep`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_payment_various`
--

CREATE TABLE `llx_payment_various` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(30) collate utf8_unicode_ci default NULL,
  `num_payment` varchar(50) collate utf8_unicode_ci default NULL,
  `label` varchar(255) collate utf8_unicode_ci default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datec` datetime default NULL,
  `datep` date default NULL,
  `datev` date default NULL,
  `sens` smallint(6) NOT NULL default '0',
  `amount` double(24,8) NOT NULL default '0.00000000',
  `fk_typepayment` int(11) NOT NULL,
  `accountancy_code` varchar(32) collate utf8_unicode_ci default NULL,
  `subledger_account` varchar(32) collate utf8_unicode_ci default NULL,
  `fk_projet` int(11) default NULL,
  `entity` int(11) NOT NULL default '1',
  `note` text collate utf8_unicode_ci,
  `fk_bank` int(11) default NULL,
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_pos_cash_fence`
--

CREATE TABLE `llx_pos_cash_fence` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `ref` varchar(64) collate utf8_unicode_ci default NULL,
  `label` varchar(255) collate utf8_unicode_ci default NULL,
  `opening` double(24,8) default '0.00000000',
  `cash` double(24,8) default '0.00000000',
  `card` double(24,8) default '0.00000000',
  `cheque` double(24,8) default '0.00000000',
  `status` int(11) default NULL,
  `date_creation` datetime NOT NULL,
  `date_valid` datetime default NULL,
  `day_close` int(11) default NULL,
  `month_close` int(11) default NULL,
  `year_close` int(11) default NULL,
  `posmodule` varchar(30) collate utf8_unicode_ci default NULL,
  `posnumber` varchar(30) collate utf8_unicode_ci default NULL,
  `fk_user_creat` int(11) default NULL,
  `fk_user_valid` int(11) default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_prelevement_bons`
--

CREATE TABLE `llx_prelevement_bons` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(12) collate utf8_unicode_ci default NULL,
  `entity` int(11) NOT NULL default '1',
  `datec` datetime default NULL,
  `amount` double(24,8) default '0.00000000',
  `statut` smallint(6) default '0',
  `credite` smallint(6) default '0',
  `note` text collate utf8_unicode_ci,
  `date_trans` datetime default NULL,
  `method_trans` smallint(6) default NULL,
  `fk_user_trans` int(11) default NULL,
  `date_credit` datetime default NULL,
  `fk_user_credit` int(11) default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_prelevement_bons_ref` (`ref`,`entity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_prelevement_facture`
--

CREATE TABLE `llx_prelevement_facture` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_facture` int(11) NOT NULL,
  `fk_prelevement_lignes` int(11) NOT NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_prelevement_facture_fk_prelevement_lignes` (`fk_prelevement_lignes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_prelevement_facture_demande`
--

CREATE TABLE `llx_prelevement_facture_demande` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `fk_facture` int(11) NOT NULL,
  `sourcetype` varchar(32) collate utf8_unicode_ci default NULL,
  `amount` double(24,8) NOT NULL,
  `date_demande` datetime NOT NULL,
  `traite` smallint(6) default '0',
  `date_traite` datetime default NULL,
  `fk_prelevement_bons` int(11) default NULL,
  `fk_user_demande` int(11) NOT NULL,
  `code_banque` varchar(128) collate utf8_unicode_ci default NULL,
  `code_guichet` varchar(6) collate utf8_unicode_ci default NULL,
  `number` varchar(255) collate utf8_unicode_ci default NULL,
  `cle_rib` varchar(5) collate utf8_unicode_ci default NULL,
  `ext_payment_id` varchar(128) collate utf8_unicode_ci default NULL,
  `ext_payment_site` varchar(128) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_prelevement_lignes`
--

CREATE TABLE `llx_prelevement_lignes` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_prelevement_bons` int(11) default NULL,
  `fk_soc` int(11) NOT NULL,
  `statut` smallint(6) default '0',
  `client_nom` varchar(255) collate utf8_unicode_ci default NULL,
  `amount` double(24,8) default '0.00000000',
  `code_banque` varchar(128) collate utf8_unicode_ci default NULL,
  `code_guichet` varchar(6) collate utf8_unicode_ci default NULL,
  `number` varchar(255) collate utf8_unicode_ci default NULL,
  `cle_rib` varchar(5) collate utf8_unicode_ci default NULL,
  `note` text collate utf8_unicode_ci,
  PRIMARY KEY  (`rowid`),
  KEY `idx_prelevement_lignes_fk_prelevement_bons` (`fk_prelevement_bons`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_prelevement_rejet`
--

CREATE TABLE `llx_prelevement_rejet` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_prelevement_lignes` int(11) default NULL,
  `date_rejet` datetime default NULL,
  `motif` int(11) default NULL,
  `date_creation` datetime default NULL,
  `fk_user_creation` int(11) default NULL,
  `note` text collate utf8_unicode_ci,
  `afacturer` tinyint(4) default '0',
  `fk_facture` int(11) default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_printing`
--

CREATE TABLE `llx_printing` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datec` datetime default NULL,
  `printer_name` text collate utf8_unicode_ci NOT NULL,
  `printer_location` text collate utf8_unicode_ci NOT NULL,
  `printer_id` varchar(255) collate utf8_unicode_ci NOT NULL,
  `copy` int(11) NOT NULL default '1',
  `module` varchar(16) collate utf8_unicode_ci NOT NULL,
  `driver` varchar(16) collate utf8_unicode_ci NOT NULL,
  `userid` int(11) default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product`
--

CREATE TABLE `llx_product` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(128) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `ref_ext` varchar(128) collate utf8_unicode_ci default NULL,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_parent` int(11) default '0',
  `label` varchar(255) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `note` text collate utf8_unicode_ci,
  `customcode` varchar(32) collate utf8_unicode_ci default NULL,
  `fk_country` int(11) default NULL,
  `price` double(24,8) default '0.00000000',
  `price_ttc` double(24,8) default '0.00000000',
  `price_min` double(24,8) default '0.00000000',
  `price_min_ttc` double(24,8) default '0.00000000',
  `price_base_type` varchar(3) collate utf8_unicode_ci default 'HT',
  `cost_price` double(24,8) default NULL,
  `default_vat_code` varchar(10) collate utf8_unicode_ci default NULL,
  `tva_tx` double(6,3) default NULL,
  `recuperableonly` int(11) NOT NULL default '0',
  `localtax1_tx` double(6,3) default '0.000',
  `localtax1_type` varchar(10) collate utf8_unicode_ci NOT NULL default '0',
  `localtax2_tx` double(6,3) default '0.000',
  `localtax2_type` varchar(10) collate utf8_unicode_ci NOT NULL default '0',
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `tosell` tinyint(4) default '1',
  `tobuy` tinyint(4) default '1',
  `onportal` tinyint(4) default '0',
  `tobatch` tinyint(4) NOT NULL default '0',
  `fk_product_type` int(11) default '0',
  `duration` varchar(6) collate utf8_unicode_ci default NULL,
  `seuil_stock_alerte` int(11) default NULL,
  `url` varchar(255) collate utf8_unicode_ci default NULL,
  `barcode` varchar(180) collate utf8_unicode_ci default NULL,
  `fk_barcode_type` int(11) default NULL,
  `accountancy_code_sell` varchar(32) collate utf8_unicode_ci default NULL,
  `accountancy_code_sell_intra` varchar(32) collate utf8_unicode_ci default NULL,
  `accountancy_code_sell_export` varchar(32) collate utf8_unicode_ci default NULL,
  `accountancy_code_buy` varchar(32) collate utf8_unicode_ci default NULL,
  `partnumber` varchar(32) collate utf8_unicode_ci default NULL,
  `weight` float default NULL,
  `weight_units` tinyint(4) default NULL,
  `length` float default NULL,
  `length_units` tinyint(4) default NULL,
  `width` float default NULL,
  `width_units` tinyint(4) default NULL,
  `height` float default NULL,
  `height_units` tinyint(4) default NULL,
  `surface` float default NULL,
  `surface_units` tinyint(4) default NULL,
  `volume` float default NULL,
  `volume_units` tinyint(4) default NULL,
  `stock` double default NULL,
  `pmp` double(24,8) NOT NULL default '0.00000000',
  `fifo` double(24,8) default NULL,
  `lifo` double(24,8) default NULL,
  `fk_default_warehouse` int(11) default NULL,
  `canvas` varchar(32) collate utf8_unicode_ci default NULL,
  `finished` tinyint(4) default NULL,
  `hidden` tinyint(4) default '0',
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_price_expression` int(11) default NULL,
  `desiredstock` int(11) default '0',
  `fk_unit` int(11) default NULL,
  `price_autogen` tinyint(4) default '0',
  `fk_project` int(11) default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_product_ref` (`ref`,`entity`),
  UNIQUE KEY `uk_product_barcode` (`barcode`,`fk_barcode_type`,`entity`),
  KEY `idx_product_label` (`label`),
  KEY `idx_product_barcode` (`barcode`),
  KEY `idx_product_import_key` (`import_key`),
  KEY `idx_product_seuil_stock_alerte` (`seuil_stock_alerte`),
  KEY `idx_product_fk_country` (`fk_country`),
  KEY `idx_product_fk_user_author` (`fk_user_author`),
  KEY `idx_product_fk_barcode_type` (`fk_barcode_type`),
  KEY `idx_product_fk_project` (`fk_project`),
  KEY `fk_product_fk_unit` (`fk_unit`),
  KEY `fk_product_default_warehouse` (`fk_default_warehouse`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `llx_product`
--

INSERT INTO `llx_product` (`rowid`, `ref`, `entity`, `ref_ext`, `datec`, `tms`, `fk_parent`, `label`, `description`, `note_public`, `note`, `customcode`, `fk_country`, `price`, `price_ttc`, `price_min`, `price_min_ttc`, `price_base_type`, `cost_price`, `default_vat_code`, `tva_tx`, `recuperableonly`, `localtax1_tx`, `localtax1_type`, `localtax2_tx`, `localtax2_type`, `fk_user_author`, `fk_user_modif`, `tosell`, `tobuy`, `onportal`, `tobatch`, `fk_product_type`, `duration`, `seuil_stock_alerte`, `url`, `barcode`, `fk_barcode_type`, `accountancy_code_sell`, `accountancy_code_sell_intra`, `accountancy_code_sell_export`, `accountancy_code_buy`, `partnumber`, `weight`, `weight_units`, `length`, `length_units`, `width`, `width_units`, `height`, `height_units`, `surface`, `surface_units`, `volume`, `volume_units`, `stock`, `pmp`, `fifo`, `lifo`, `fk_default_warehouse`, `canvas`, `finished`, `hidden`, `import_key`, `model_pdf`, `fk_price_expression`, `desiredstock`, `fk_unit`, `price_autogen`, `fk_project`) VALUES
(1, 'ACT_HOR', 1, NULL, '2019-09-07 08:44:06', '2019-09-07 06:48:23', 0, 'Actuación 1 hora', 'Actuación de 1 hora. Contendrá\r\n- 5 piezas de baile\r\n- 1 instrumental\r\n- 10 jotas cantadas', NULL, '', '', NULL, 550.00000000, 550.00000000, 500.00000000, 500.00000000, 'TTC', NULL, NULL, 0.000, 0, 0.000, '0', 0.000, '0', 1, 1, 1, 0, 0, 0, 1, 'h', NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, 0.00000000, NULL, NULL, NULL, '', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_association`
--

CREATE TABLE `llx_product_association` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_product_pere` int(11) NOT NULL default '0',
  `fk_product_fils` int(11) NOT NULL default '0',
  `qty` double default NULL,
  `incdec` int(11) default '1',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_product_association` (`fk_product_pere`,`fk_product_fils`),
  KEY `idx_product_association_fils` (`fk_product_fils`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_attribute`
--

CREATE TABLE `llx_product_attribute` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(255) collate utf8_unicode_ci NOT NULL,
  `label` varchar(255) collate utf8_unicode_ci NOT NULL,
  `rang` int(11) NOT NULL default '0',
  `entity` int(11) NOT NULL default '1',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_product_attribute_ref` (`ref`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_attribute_combination`
--

CREATE TABLE `llx_product_attribute_combination` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_product_parent` int(11) NOT NULL,
  `fk_product_child` int(11) NOT NULL,
  `variation_price` float NOT NULL,
  `variation_price_percentage` int(11) default NULL,
  `variation_weight` float NOT NULL,
  `entity` int(11) NOT NULL default '1',
  PRIMARY KEY  (`rowid`),
  KEY `idx_product_att_com_product_parent` (`fk_product_parent`),
  KEY `idx_product_att_com_product_child` (`fk_product_child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_attribute_combination2val`
--

CREATE TABLE `llx_product_attribute_combination2val` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_prod_combination` int(11) NOT NULL,
  `fk_prod_attr` int(11) NOT NULL,
  `fk_prod_attr_val` int(11) NOT NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_attribute_value`
--

CREATE TABLE `llx_product_attribute_value` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_product_attribute` int(11) NOT NULL,
  `ref` varchar(180) collate utf8_unicode_ci default NULL,
  `value` varchar(255) collate utf8_unicode_ci default NULL,
  `entity` int(11) NOT NULL default '1',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_product_attribute_value` (`fk_product_attribute`,`ref`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_batch`
--

CREATE TABLE `llx_product_batch` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_product_stock` int(11) NOT NULL,
  `eatby` datetime default NULL,
  `sellby` datetime default NULL,
  `batch` varchar(30) collate utf8_unicode_ci NOT NULL,
  `qty` double NOT NULL default '0',
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_product_batch` (`fk_product_stock`,`batch`),
  KEY `idx_fk_product_stock` (`fk_product_stock`),
  KEY `idx_batch` (`batch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_customer_price`
--

CREATE TABLE `llx_product_customer_price` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_product` int(11) NOT NULL,
  `fk_soc` int(11) NOT NULL,
  `price` double(24,8) default '0.00000000',
  `price_ttc` double(24,8) default '0.00000000',
  `price_min` double(24,8) default '0.00000000',
  `price_min_ttc` double(24,8) default '0.00000000',
  `price_base_type` varchar(3) collate utf8_unicode_ci default 'HT',
  `default_vat_code` varchar(10) collate utf8_unicode_ci default NULL,
  `tva_tx` double(6,3) default NULL,
  `recuperableonly` int(11) NOT NULL default '0',
  `localtax1_tx` double(6,3) default '0.000',
  `localtax1_type` varchar(10) collate utf8_unicode_ci NOT NULL default '0',
  `localtax2_tx` double(6,3) default '0.000',
  `localtax2_type` varchar(10) collate utf8_unicode_ci NOT NULL default '0',
  `fk_user` int(11) default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_customer_price_fk_product_fk_soc` (`fk_product`,`fk_soc`),
  KEY `idx_product_customer_price_fk_user` (`fk_user`),
  KEY `idx_product_customer_price_fk_soc` (`fk_soc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_customer_price_log`
--

CREATE TABLE `llx_product_customer_price_log` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `datec` datetime default NULL,
  `fk_product` int(11) NOT NULL,
  `fk_soc` int(11) NOT NULL default '0',
  `price` double(24,8) default '0.00000000',
  `price_ttc` double(24,8) default '0.00000000',
  `price_min` double(24,8) default '0.00000000',
  `price_min_ttc` double(24,8) default '0.00000000',
  `price_base_type` varchar(3) collate utf8_unicode_ci default 'HT',
  `default_vat_code` varchar(10) collate utf8_unicode_ci default NULL,
  `tva_tx` double(6,3) default NULL,
  `recuperableonly` int(11) NOT NULL default '0',
  `localtax1_tx` double(6,3) default '0.000',
  `localtax1_type` varchar(10) collate utf8_unicode_ci NOT NULL default '0',
  `localtax2_tx` double(6,3) default '0.000',
  `localtax2_type` varchar(10) collate utf8_unicode_ci NOT NULL default '0',
  `fk_user` int(11) default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_extrafields`
--

CREATE TABLE `llx_product_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_product_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_fournisseur_price`
--

CREATE TABLE `llx_product_fournisseur_price` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_product` int(11) default NULL,
  `fk_soc` int(11) default NULL,
  `ref_fourn` varchar(30) collate utf8_unicode_ci default NULL,
  `desc_fourn` text collate utf8_unicode_ci,
  `fk_availability` int(11) default NULL,
  `price` double(24,8) default '0.00000000',
  `quantity` double default NULL,
  `remise_percent` double NOT NULL default '0',
  `remise` double NOT NULL default '0',
  `unitprice` double(24,8) default '0.00000000',
  `charges` double(24,8) default '0.00000000',
  `default_vat_code` varchar(10) collate utf8_unicode_ci default NULL,
  `barcode` varchar(180) collate utf8_unicode_ci default NULL,
  `fk_barcode_type` int(11) default NULL,
  `tva_tx` double(6,3) NOT NULL,
  `localtax1_tx` double(6,3) default '0.000',
  `localtax1_type` varchar(10) collate utf8_unicode_ci NOT NULL default '0',
  `localtax2_tx` double(6,3) default '0.000',
  `localtax2_type` varchar(10) collate utf8_unicode_ci NOT NULL default '0',
  `info_bits` int(11) NOT NULL default '0',
  `fk_user` int(11) default NULL,
  `fk_supplier_price_expression` int(11) default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `delivery_time_days` int(11) default NULL,
  `supplier_reputation` varchar(10) collate utf8_unicode_ci default NULL,
  `fk_multicurrency` int(11) default NULL,
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_tx` double(24,8) default '1.00000000',
  `multicurrency_unitprice` double(24,8) default NULL,
  `multicurrency_price` double(24,8) default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_product_fournisseur_price_ref` (`ref_fourn`,`fk_soc`,`quantity`,`entity`),
  UNIQUE KEY `uk_product_barcode` (`barcode`,`fk_barcode_type`,`entity`),
  KEY `idx_product_fournisseur_price_fk_user` (`fk_user`),
  KEY `idx_product_fourn_price_fk_product` (`fk_product`,`entity`),
  KEY `idx_product_fourn_price_fk_soc` (`fk_soc`,`entity`),
  KEY `idx_product_barcode` (`barcode`),
  KEY `idx_product_fk_barcode_type` (`fk_barcode_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_fournisseur_price_log`
--

CREATE TABLE `llx_product_fournisseur_price_log` (
  `rowid` int(11) NOT NULL auto_increment,
  `datec` datetime default NULL,
  `fk_product_fournisseur` int(11) NOT NULL,
  `price` double(24,8) default '0.00000000',
  `quantity` double default NULL,
  `fk_user` int(11) default NULL,
  `fk_multicurrency` int(11) default NULL,
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_tx` double(24,8) default '1.00000000',
  `multicurrency_unitprice` double(24,8) default NULL,
  `multicurrency_price` double(24,8) default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_lang`
--

CREATE TABLE `llx_product_lang` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_product` int(11) NOT NULL default '0',
  `lang` varchar(5) collate utf8_unicode_ci NOT NULL default '0',
  `label` varchar(255) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci,
  `note` text collate utf8_unicode_ci,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_product_lang` (`fk_product`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_lot`
--

CREATE TABLE `llx_product_lot` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) default '1',
  `fk_product` int(11) NOT NULL,
  `batch` varchar(30) collate utf8_unicode_ci default NULL,
  `eatby` date default NULL,
  `sellby` date default NULL,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `import_key` int(11) default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_product_lot` (`fk_product`,`batch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_lot_extrafields`
--

CREATE TABLE `llx_product_lot_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_product_lot_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_price`
--

CREATE TABLE `llx_product_price` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_product` int(11) NOT NULL,
  `date_price` datetime NOT NULL,
  `price_level` smallint(6) default '1',
  `price` double(24,8) default NULL,
  `price_ttc` double(24,8) default NULL,
  `price_min` double(24,8) default NULL,
  `price_min_ttc` double(24,8) default NULL,
  `price_base_type` varchar(3) collate utf8_unicode_ci default 'HT',
  `default_vat_code` varchar(10) collate utf8_unicode_ci default NULL,
  `tva_tx` double(6,3) NOT NULL,
  `recuperableonly` int(11) NOT NULL default '0',
  `localtax1_tx` double(6,3) default '0.000',
  `localtax1_type` varchar(10) collate utf8_unicode_ci NOT NULL default '0',
  `localtax2_tx` double(6,3) default '0.000',
  `localtax2_type` varchar(10) collate utf8_unicode_ci NOT NULL default '0',
  `fk_user_author` int(11) default NULL,
  `tosell` tinyint(4) default '1',
  `price_by_qty` int(11) NOT NULL default '0',
  `fk_price_expression` int(11) default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `fk_multicurrency` int(11) default NULL,
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_tx` double(24,8) default '1.00000000',
  `multicurrency_price` double(24,8) default NULL,
  `multicurrency_price_ttc` double(24,8) default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_product_price_fk_user_author` (`fk_user_author`),
  KEY `idx_product_price_fk_product` (`fk_product`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `llx_product_price`
--

INSERT INTO `llx_product_price` (`rowid`, `entity`, `tms`, `fk_product`, `date_price`, `price_level`, `price`, `price_ttc`, `price_min`, `price_min_ttc`, `price_base_type`, `default_vat_code`, `tva_tx`, `recuperableonly`, `localtax1_tx`, `localtax1_type`, `localtax2_tx`, `localtax2_type`, `fk_user_author`, `tosell`, `price_by_qty`, `fk_price_expression`, `import_key`, `fk_multicurrency`, `multicurrency_code`, `multicurrency_tx`, `multicurrency_price`, `multicurrency_price_ttc`) VALUES
(1, 1, '2019-09-07 06:44:06', 1, '2019-09-07 08:44:06', 1, 21.00000000, 21.00000000, 0.00000000, 0.00000000, 'TTC', NULL, 0.000, 0, 0.000, '0', 0.000, '0', 1, 1, 0, NULL, NULL, NULL, NULL, 1.00000000, NULL, NULL),
(2, 1, '2019-09-07 06:48:23', 1, '2019-09-07 08:48:23', 1, 550.00000000, 550.00000000, 500.00000000, 500.00000000, 'TTC', NULL, 0.000, 0, 0.000, '0', 0.000, '0', 1, 1, 0, NULL, NULL, NULL, NULL, 1.00000000, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_pricerules`
--

CREATE TABLE `llx_product_pricerules` (
  `rowid` int(11) NOT NULL auto_increment,
  `level` int(11) NOT NULL,
  `fk_level` int(11) NOT NULL,
  `var_percent` float NOT NULL,
  `var_min_percent` float NOT NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `unique_level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_price_by_qty`
--

CREATE TABLE `llx_product_price_by_qty` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_product_price` int(11) NOT NULL,
  `price` double(24,8) default '0.00000000',
  `price_base_type` varchar(3) collate utf8_unicode_ci default 'HT',
  `quantity` double default NULL,
  `remise_percent` double NOT NULL default '0',
  `remise` double NOT NULL default '0',
  `unitprice` double(24,8) default '0.00000000',
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `fk_multicurrency` int(11) default NULL,
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_tx` double(24,8) default '1.00000000',
  `multicurrency_price` double(24,8) default NULL,
  `multicurrency_price_ttc` double(24,8) default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_product_price_by_qty_level` (`fk_product_price`,`quantity`),
  KEY `idx_product_price_by_qty_fk_product_price` (`fk_product_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_stock`
--

CREATE TABLE `llx_product_stock` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_product` int(11) NOT NULL,
  `fk_entrepot` int(11) NOT NULL,
  `reel` double default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_product_stock` (`fk_product`,`fk_entrepot`),
  KEY `idx_product_stock_fk_product` (`fk_product`),
  KEY `idx_product_stock_fk_entrepot` (`fk_entrepot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_product_warehouse_properties`
--

CREATE TABLE `llx_product_warehouse_properties` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_product` int(11) NOT NULL,
  `fk_entrepot` int(11) NOT NULL,
  `seuil_stock_alerte` int(11) default '0',
  `desiredstock` int(11) default '0',
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_projet`
--

CREATE TABLE `llx_projet` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_soc` int(11) default NULL,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `dateo` date default NULL,
  `datee` date default NULL,
  `ref` varchar(50) collate utf8_unicode_ci default NULL,
  `entity` int(11) NOT NULL default '1',
  `title` varchar(255) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci,
  `fk_user_creat` int(11) NOT NULL,
  `fk_user_modif` int(11) default NULL,
  `public` int(11) default NULL,
  `fk_statut` int(11) NOT NULL default '0',
  `fk_opp_status` int(11) default NULL,
  `opp_percent` double(5,2) default NULL,
  `date_close` datetime default NULL,
  `fk_user_close` int(11) default NULL,
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `opp_amount` double(24,8) default NULL,
  `budget_amount` double(24,8) default NULL,
  `bill_time` int(11) default '0',
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_projet_ref` (`ref`,`entity`),
  KEY `idx_projet_fk_soc` (`fk_soc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_projet_extrafields`
--

CREATE TABLE `llx_projet_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_projet_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_projet_task`
--

CREATE TABLE `llx_projet_task` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(50) collate utf8_unicode_ci default NULL,
  `entity` int(11) NOT NULL default '1',
  `fk_projet` int(11) NOT NULL,
  `fk_task_parent` int(11) NOT NULL default '0',
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `dateo` datetime default NULL,
  `datee` datetime default NULL,
  `datev` datetime default NULL,
  `label` varchar(255) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci,
  `duration_effective` double default '0',
  `planned_workload` double default '0',
  `progress` int(11) default '0',
  `priority` int(11) default '0',
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `fk_user_valid` int(11) default NULL,
  `fk_statut` smallint(6) NOT NULL default '0',
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `rang` int(11) default '0',
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_projet_task_ref` (`ref`,`entity`),
  KEY `idx_projet_task_fk_projet` (`fk_projet`),
  KEY `idx_projet_task_fk_user_creat` (`fk_user_creat`),
  KEY `idx_projet_task_fk_user_valid` (`fk_user_valid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_projet_task_extrafields`
--

CREATE TABLE `llx_projet_task_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_projet_task_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_projet_task_time`
--

CREATE TABLE `llx_projet_task_time` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_task` int(11) NOT NULL,
  `task_date` date default NULL,
  `task_datehour` datetime default NULL,
  `task_date_withhour` int(11) default '0',
  `task_duration` double default NULL,
  `fk_user` int(11) default NULL,
  `thm` double(24,8) default NULL,
  `invoice_id` int(11) default NULL,
  `invoice_line_id` int(11) default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `datec` date default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `note` text collate utf8_unicode_ci,
  PRIMARY KEY  (`rowid`),
  KEY `idx_projet_task_time_task` (`fk_task`),
  KEY `idx_projet_task_time_date` (`task_date`),
  KEY `idx_projet_task_time_datehour` (`task_datehour`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_propal`
--

CREATE TABLE `llx_propal` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(30) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `ref_ext` varchar(255) collate utf8_unicode_ci default NULL,
  `ref_int` varchar(255) collate utf8_unicode_ci default NULL,
  `ref_client` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_soc` int(11) default NULL,
  `fk_projet` int(11) default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datec` datetime default NULL,
  `datep` date default NULL,
  `fin_validite` datetime default NULL,
  `date_valid` datetime default NULL,
  `date_cloture` datetime default NULL,
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `fk_user_valid` int(11) default NULL,
  `fk_user_cloture` int(11) default NULL,
  `fk_statut` smallint(6) NOT NULL default '0',
  `price` double default '0',
  `remise_percent` double default '0',
  `remise_absolue` double default '0',
  `remise` double default '0',
  `total_ht` double(24,8) default '0.00000000',
  `tva` double(24,8) default '0.00000000',
  `localtax1` double(24,8) default '0.00000000',
  `localtax2` double(24,8) default '0.00000000',
  `total` double(24,8) default '0.00000000',
  `fk_account` int(11) default NULL,
  `fk_currency` varchar(3) collate utf8_unicode_ci default NULL,
  `fk_cond_reglement` int(11) default NULL,
  `fk_mode_reglement` int(11) default NULL,
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  `last_main_doc` varchar(255) collate utf8_unicode_ci default NULL,
  `date_livraison` date default NULL,
  `fk_shipping_method` int(11) default NULL,
  `fk_availability` int(11) default NULL,
  `fk_input_reason` int(11) default NULL,
  `fk_incoterms` int(11) default NULL,
  `location_incoterms` varchar(255) collate utf8_unicode_ci default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `extraparams` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_delivery_address` int(11) default NULL,
  `fk_multicurrency` int(11) default NULL,
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_tx` double(24,8) default '1.00000000',
  `multicurrency_total_ht` double(24,8) default '0.00000000',
  `multicurrency_total_tva` double(24,8) default '0.00000000',
  `multicurrency_total_ttc` double(24,8) default '0.00000000',
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_propal_ref` (`ref`,`entity`),
  KEY `idx_propal_fk_soc` (`fk_soc`),
  KEY `idx_propal_fk_user_author` (`fk_user_author`),
  KEY `idx_propal_fk_user_valid` (`fk_user_valid`),
  KEY `idx_propal_fk_user_cloture` (`fk_user_cloture`),
  KEY `idx_propal_fk_projet` (`fk_projet`),
  KEY `idx_propal_fk_account` (`fk_account`),
  KEY `idx_propal_fk_currency` (`fk_currency`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `llx_propal`
--

INSERT INTO `llx_propal` (`rowid`, `ref`, `entity`, `ref_ext`, `ref_int`, `ref_client`, `fk_soc`, `fk_projet`, `tms`, `datec`, `datep`, `fin_validite`, `date_valid`, `date_cloture`, `fk_user_author`, `fk_user_modif`, `fk_user_valid`, `fk_user_cloture`, `fk_statut`, `price`, `remise_percent`, `remise_absolue`, `remise`, `total_ht`, `tva`, `localtax1`, `localtax2`, `total`, `fk_account`, `fk_currency`, `fk_cond_reglement`, `fk_mode_reglement`, `note_private`, `note_public`, `model_pdf`, `last_main_doc`, `date_livraison`, `fk_shipping_method`, `fk_availability`, `fk_input_reason`, `fk_incoterms`, `location_incoterms`, `import_key`, `extraparams`, `fk_delivery_address`, `fk_multicurrency`, `multicurrency_code`, `multicurrency_tx`, `multicurrency_total_ht`, `multicurrency_total_tva`, `multicurrency_total_ttc`) VALUES
(2, 'PR1909-0001', 1, NULL, NULL, 'Ayto. Fraga', 1, NULL, '2019-09-07 06:49:40', '2019-09-07 08:41:52', '2019-10-04', '2019-10-19 12:00:00', '2019-09-07 08:49:40', NULL, 1, NULL, 1, NULL, 1, 0, NULL, NULL, 0, 550.00000000, 0.00000000, 0.00000000, 0.00000000, 550.00000000, NULL, NULL, 5, 3, '', '', 'azur', 'propale/PR1909-0001/PR1909-0001.pdf', '2019-10-05', NULL, 1, 11, 0, '', NULL, NULL, NULL, 0, 'EUR', 1.00000000, 550.00000000, 0.00000000, 550.00000000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_propaldet`
--

CREATE TABLE `llx_propaldet` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_propal` int(11) NOT NULL,
  `fk_parent_line` int(11) default NULL,
  `fk_product` int(11) default NULL,
  `label` varchar(255) collate utf8_unicode_ci default NULL,
  `description` text collate utf8_unicode_ci,
  `fk_remise_except` int(11) default NULL,
  `vat_src_code` varchar(10) collate utf8_unicode_ci default '',
  `tva_tx` double(6,3) default '0.000',
  `localtax1_tx` double(6,3) default '0.000',
  `localtax1_type` varchar(10) collate utf8_unicode_ci default NULL,
  `localtax2_tx` double(6,3) default '0.000',
  `localtax2_type` varchar(10) collate utf8_unicode_ci default NULL,
  `qty` double default NULL,
  `remise_percent` double default '0',
  `remise` double default '0',
  `price` double default NULL,
  `subprice` double(24,8) default '0.00000000',
  `total_ht` double(24,8) default '0.00000000',
  `total_tva` double(24,8) default '0.00000000',
  `total_localtax1` double(24,8) default '0.00000000',
  `total_localtax2` double(24,8) default '0.00000000',
  `total_ttc` double(24,8) default '0.00000000',
  `product_type` int(11) default '0',
  `date_start` datetime default NULL,
  `date_end` datetime default NULL,
  `info_bits` int(11) default '0',
  `buy_price_ht` double(24,8) default '0.00000000',
  `fk_product_fournisseur_price` int(11) default NULL,
  `special_code` int(11) default '0',
  `rang` int(11) default '0',
  `fk_unit` int(11) default NULL,
  `fk_multicurrency` int(11) default NULL,
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_subprice` double(24,8) default '0.00000000',
  `multicurrency_total_ht` double(24,8) default '0.00000000',
  `multicurrency_total_tva` double(24,8) default '0.00000000',
  `multicurrency_total_ttc` double(24,8) default '0.00000000',
  PRIMARY KEY  (`rowid`),
  KEY `idx_propaldet_fk_propal` (`fk_propal`),
  KEY `idx_propaldet_fk_product` (`fk_product`),
  KEY `fk_propaldet_fk_unit` (`fk_unit`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `llx_propaldet`
--

INSERT INTO `llx_propaldet` (`rowid`, `fk_propal`, `fk_parent_line`, `fk_product`, `label`, `description`, `fk_remise_except`, `vat_src_code`, `tva_tx`, `localtax1_tx`, `localtax1_type`, `localtax2_tx`, `localtax2_type`, `qty`, `remise_percent`, `remise`, `price`, `subprice`, `total_ht`, `total_tva`, `total_localtax1`, `total_localtax2`, `total_ttc`, `product_type`, `date_start`, `date_end`, `info_bits`, `buy_price_ht`, `fk_product_fournisseur_price`, `special_code`, `rang`, `fk_unit`, `fk_multicurrency`, `multicurrency_code`, `multicurrency_subprice`, `multicurrency_total_ht`, `multicurrency_total_tva`, `multicurrency_total_ttc`) VALUES
(2, 2, NULL, 1, NULL, 'Actuación de 1 hora. Contendrá\r\n- 5 piezas de baile\r\n- 1 instrumental\r\n- 10 jotas cantadas', NULL, '', 0.000, 0.000, '3', 0.000, '5', 1, 0, 0, NULL, 550.00000000, 550.00000000, 0.00000000, 0.00000000, 0.00000000, 550.00000000, 1, '2019-10-05 00:00:00', '2019-10-05 00:00:00', 0, 0.00000000, NULL, 0, 1, NULL, NULL, 'EUR', 550.00000000, 550.00000000, 0.00000000, 550.00000000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_propaldet_extrafields`
--

CREATE TABLE `llx_propaldet_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_propaldet_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_propal_extrafields`
--

CREATE TABLE `llx_propal_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_propal_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_propal_merge_pdf_product`
--

CREATE TABLE `llx_propal_merge_pdf_product` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_product` int(11) NOT NULL,
  `file_name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `lang` varchar(5) collate utf8_unicode_ci default NULL,
  `fk_user_author` int(11) default NULL,
  `fk_user_mod` int(11) NOT NULL,
  `datec` datetime NOT NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_reception`
--

CREATE TABLE `llx_reception` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `ref` varchar(30) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `fk_soc` int(11) NOT NULL,
  `fk_projet` int(11) default NULL,
  `ref_ext` varchar(30) collate utf8_unicode_ci default NULL,
  `ref_int` varchar(30) collate utf8_unicode_ci default NULL,
  `ref_supplier` varchar(30) collate utf8_unicode_ci default NULL,
  `date_creation` datetime default NULL,
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `date_valid` datetime default NULL,
  `fk_user_valid` int(11) default NULL,
  `date_delivery` datetime default NULL,
  `date_reception` datetime default NULL,
  `fk_shipping_method` int(11) default NULL,
  `tracking_number` varchar(50) collate utf8_unicode_ci default NULL,
  `fk_statut` smallint(6) default '0',
  `billed` smallint(6) default '0',
  `height` float default NULL,
  `width` float default NULL,
  `size_units` int(11) default NULL,
  `size` float default NULL,
  `weight_units` int(11) default NULL,
  `weight` float default NULL,
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_incoterms` int(11) default NULL,
  `location_incoterms` varchar(255) collate utf8_unicode_ci default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `extraparams` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `idx_reception_uk_ref` (`ref`,`entity`),
  KEY `idx_reception_fk_soc` (`fk_soc`),
  KEY `idx_reception_fk_user_author` (`fk_user_author`),
  KEY `idx_reception_fk_user_valid` (`fk_user_valid`),
  KEY `idx_reception_fk_shipping_method` (`fk_shipping_method`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_reception_extrafields`
--

CREATE TABLE `llx_reception_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_reception_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_resource`
--

CREATE TABLE `llx_resource` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `ref` varchar(255) collate utf8_unicode_ci default NULL,
  `asset_number` varchar(255) collate utf8_unicode_ci default NULL,
  `description` text collate utf8_unicode_ci,
  `fk_code_type_resource` varchar(32) collate utf8_unicode_ci default NULL,
  `datec` datetime default NULL,
  `date_valid` datetime default NULL,
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `fk_user_valid` int(11) default NULL,
  `fk_statut` smallint(6) NOT NULL default '0',
  `note_public` text collate utf8_unicode_ci,
  `note_private` text collate utf8_unicode_ci,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `extraparams` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_country` int(11) default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_resource_ref` (`ref`,`entity`),
  KEY `fk_code_type_resource_idx` (`fk_code_type_resource`),
  KEY `idx_resource_fk_country` (`fk_country`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `llx_resource`
--

INSERT INTO `llx_resource` (`rowid`, `entity`, `ref`, `asset_number`, `description`, `fk_code_type_resource`, `datec`, `date_valid`, `fk_user_author`, `fk_user_modif`, `fk_user_valid`, `fk_statut`, `note_public`, `note_private`, `import_key`, `extraparams`, `fk_country`, `tms`) VALUES
(2, 1, 'Falda novia (roja)', NULL, 'Falda de seda de color rojo', 'RES_VES', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 4, '2019-09-07 05:02:49'),
(3, 1, 'Pañuelo de chinos - blanco', NULL, 'Pañuelo de novia bordado con motivos chinos', 'RES_VES', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 4, '2019-09-07 05:03:51'),
(4, 1, 'Mesa de mezclas', NULL, 'Mesa de mezclas para actuaciones', 'RES_MUS', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 4, '2019-09-07 05:04:36'),
(5, 1, 'Bolsa de cuerdas instrumentos', NULL, 'Cuerdas de guitarra, bandurria y laud', 'RES_SUM', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 4, '2019-09-07 05:05:31'),
(6, 1, 'Agua', NULL, 'Botellas de agua', 'RES_SUM', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 4, '2019-09-07 05:06:04');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_resource_extrafields`
--

CREATE TABLE `llx_resource_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_resource_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_rights_def`
--

CREATE TABLE `llx_rights_def` (
  `id` int(11) NOT NULL,
  `libelle` varchar(255) collate utf8_unicode_ci default NULL,
  `module` varchar(64) collate utf8_unicode_ci default NULL,
  `entity` int(11) NOT NULL default '1',
  `perms` varchar(50) collate utf8_unicode_ci default NULL,
  `subperms` varchar(50) collate utf8_unicode_ci default NULL,
  `type` varchar(1) collate utf8_unicode_ci default NULL,
  `bydefault` tinyint(4) default '0',
  PRIMARY KEY  (`id`,`entity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `llx_rights_def`
--

INSERT INTO `llx_rights_def` (`id`, `libelle`, `module`, `entity`, `perms`, `subperms`, `type`, `bydefault`) VALUES
(21, 'Read commercial proposals', 'propale', 1, 'lire', NULL, 'r', 0),
(22, 'Create and update commercial proposals', 'propale', 1, 'creer', NULL, 'w', 0),
(24, 'Validate commercial proposals', 'propale', 1, 'propal_advance', 'validate', 'd', 0),
(25, 'Send commercial proposals to customers', 'propale', 1, 'propal_advance', 'send', 'd', 0),
(26, 'Close commercial proposals', 'propale', 1, 'cloturer', NULL, 'd', 0),
(27, 'Delete commercial proposals', 'propale', 1, 'supprimer', NULL, 'd', 0),
(28, 'Exporting commercial proposals and attributes', 'propale', 1, 'export', NULL, 'r', 0),
(71, 'Read members'' card', 'adherent', 1, 'lire', NULL, 'r', 0),
(72, 'Create/modify members (need also user module permissions if member linked to a user)', 'adherent', 1, 'creer', NULL, 'w', 0),
(74, 'Remove members', 'adherent', 1, 'supprimer', NULL, 'd', 0),
(75, 'Setup types of membership', 'adherent', 1, 'configurer', NULL, 'w', 0),
(76, 'Export members', 'adherent', 1, 'export', NULL, 'r', 0),
(78, 'Read subscriptions', 'adherent', 1, 'cotisation', 'lire', 'r', 0),
(79, 'Create/modify/remove subscriptions', 'adherent', 1, 'cotisation', 'creer', 'w', 0),
(121, 'Read third parties', 'societe', 1, 'lire', NULL, 'r', 0),
(122, 'Create and update third parties', 'societe', 1, 'creer', NULL, 'w', 0),
(125, 'Delete third parties', 'societe', 1, 'supprimer', NULL, 'd', 0),
(126, 'Export third parties', 'societe', 1, 'export', NULL, 'r', 0),
(241, 'Lire les categories', 'categorie', 1, 'lire', NULL, 'r', 0),
(242, 'Creer/modifier les categories', 'categorie', 1, 'creer', NULL, 'w', 0),
(243, 'Supprimer les categories', 'categorie', 1, 'supprimer', NULL, 'd', 0),
(251, 'Consulter les autres utilisateurs', 'user', 1, 'user', 'lire', 'r', 0),
(252, 'Consulter les permissions des autres utilisateurs', 'user', 1, 'user_advance', 'readperms', 'r', 0),
(253, 'Creer/modifier utilisateurs internes et externes', 'user', 1, 'user', 'creer', 'w', 0),
(254, 'Creer/modifier utilisateurs externes seulement', 'user', 1, 'user_advance', 'write', 'w', 0),
(255, 'Modifier le mot de passe des autres utilisateurs', 'user', 1, 'user', 'password', 'w', 0),
(256, 'Supprimer ou desactiver les autres utilisateurs', 'user', 1, 'user', 'supprimer', 'd', 0),
(262, 'Read all third parties by internal users (otherwise only if commercial contact). Not effective for external users (limited to themselves).', 'societe', 1, 'client', 'voir', 'r', 0),
(281, 'Read contacts', 'societe', 1, 'contact', 'lire', 'r', 0),
(282, 'Create and update contact', 'societe', 1, 'contact', 'creer', 'w', 0),
(283, 'Delete contacts', 'societe', 1, 'contact', 'supprimer', 'd', 0),
(286, 'Export contacts', 'societe', 1, 'contact', 'export', 'd', 0),
(341, 'Consulter ses propres permissions', 'user', 1, 'self_advance', 'readperms', 'r', 0),
(342, 'Creer/modifier ses propres infos utilisateur', 'user', 1, 'self', 'creer', 'w', 0),
(343, 'Modifier son propre mot de passe', 'user', 1, 'self', 'password', 'w', 0),
(344, 'Modifier ses propres permissions', 'user', 1, 'self_advance', 'writeperms', 'w', 0),
(351, 'Consulter les groupes', 'user', 1, 'group_advance', 'read', 'r', 0),
(352, 'Consulter les permissions des groupes', 'user', 1, 'group_advance', 'readperms', 'r', 0),
(353, 'Creer/modifier les groupes et leurs permissions', 'user', 1, 'group_advance', 'write', 'w', 0),
(354, 'Supprimer ou desactiver les groupes', 'user', 1, 'group_advance', 'delete', 'd', 0),
(358, 'Exporter les utilisateurs', 'user', 1, 'user', 'export', 'r', 0),
(531, 'Read services', 'service', 1, 'lire', NULL, 'r', 0),
(532, 'Create/modify services', 'service', 1, 'creer', NULL, 'w', 0),
(534, 'Delete les services', 'service', 1, 'supprimer', NULL, 'd', 0),
(538, 'Export services', 'service', 1, 'export', NULL, 'r', 0),
(771, 'Read expense reports (yours and your subordinates)', 'expensereport', 1, 'lire', NULL, 'r', 0),
(772, 'Create/modify expense reports', 'expensereport', 1, 'creer', NULL, 'w', 0),
(773, 'Delete expense reports', 'expensereport', 1, 'supprimer', NULL, 'd', 0),
(775, 'Approve expense reports', 'expensereport', 1, 'approve', NULL, 'w', 0),
(776, 'Pay expense reports', 'expensereport', 1, 'to_paid', NULL, 'w', 0),
(777, 'Read expense reports of everybody', 'expensereport', 1, 'readall', NULL, 'r', 0),
(778, 'Create expense reports for everybody', 'expensereport', 1, 'writeall_advance', NULL, 'w', 0),
(779, 'Export expense reports', 'expensereport', 1, 'export', NULL, 'r', 0),
(2401, 'Read actions/tasks linked to his account', 'agenda', 1, 'myactions', 'read', 'r', 0),
(2402, 'Create/modify actions/tasks linked to his account', 'agenda', 1, 'myactions', 'create', 'w', 0),
(2403, 'Delete actions/tasks linked to his account', 'agenda', 1, 'myactions', 'delete', 'w', 0),
(2411, 'Read actions/tasks of others', 'agenda', 1, 'allactions', 'read', 'r', 0),
(2412, 'Create/modify actions/tasks of others', 'agenda', 1, 'allactions', 'create', 'w', 0),
(2413, 'Delete actions/tasks of others', 'agenda', 1, 'allactions', 'delete', 'w', 0),
(2414, 'Export actions/tasks of others', 'agenda', 1, 'export', NULL, 'w', 0),
(63001, 'Read resources', 'resource', 1, 'read', NULL, 'w', 0),
(63002, 'Create/Modify resources', 'resource', 1, 'write', NULL, 'w', 0),
(63003, 'Delete resources', 'resource', 1, 'delete', NULL, 'w', 0),
(63004, 'Link resources to agenda events', 'resource', 1, 'link', NULL, 'w', 0),
(500100, 'Read objects of Actividades', 'actividades', 1, 'read', NULL, 'w', 0),
(500101, 'Create/Update objects of Actividades', 'actividades', 1, 'write', NULL, 'w', 0),
(500102, 'Delete objects of Actividades', 'actividades', 1, 'delete', NULL, 'w', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_societe`
--

CREATE TABLE `llx_societe` (
  `rowid` int(11) NOT NULL auto_increment,
  `nom` varchar(128) collate utf8_unicode_ci default NULL,
  `name_alias` varchar(128) collate utf8_unicode_ci default NULL,
  `entity` int(11) NOT NULL default '1',
  `ref_ext` varchar(255) collate utf8_unicode_ci default NULL,
  `ref_int` varchar(255) collate utf8_unicode_ci default NULL,
  `statut` tinyint(4) default '0',
  `parent` int(11) default NULL,
  `status` tinyint(4) default '1',
  `code_client` varchar(24) collate utf8_unicode_ci default NULL,
  `code_fournisseur` varchar(24) collate utf8_unicode_ci default NULL,
  `code_compta` varchar(24) collate utf8_unicode_ci default NULL,
  `code_compta_fournisseur` varchar(24) collate utf8_unicode_ci default NULL,
  `address` varchar(255) collate utf8_unicode_ci default NULL,
  `zip` varchar(25) collate utf8_unicode_ci default NULL,
  `town` varchar(50) collate utf8_unicode_ci default NULL,
  `fk_departement` int(11) default '0',
  `fk_pays` int(11) default '0',
  `fk_account` int(11) default '0',
  `phone` varchar(20) collate utf8_unicode_ci default NULL,
  `fax` varchar(20) collate utf8_unicode_ci default NULL,
  `url` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(128) collate utf8_unicode_ci default NULL,
  `skype` varchar(255) collate utf8_unicode_ci default NULL,
  `twitter` varchar(255) collate utf8_unicode_ci default NULL,
  `facebook` varchar(255) collate utf8_unicode_ci default NULL,
  `linkedin` varchar(255) collate utf8_unicode_ci default NULL,
  `instagram` varchar(255) collate utf8_unicode_ci default NULL,
  `snapchat` varchar(255) collate utf8_unicode_ci default NULL,
  `googleplus` varchar(255) collate utf8_unicode_ci default NULL,
  `youtube` varchar(255) collate utf8_unicode_ci default NULL,
  `whatsapp` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_effectif` int(11) default '0',
  `fk_typent` int(11) default '0',
  `fk_forme_juridique` int(11) default '0',
  `fk_currency` varchar(3) collate utf8_unicode_ci default NULL,
  `siren` varchar(128) collate utf8_unicode_ci default NULL,
  `siret` varchar(128) collate utf8_unicode_ci default NULL,
  `ape` varchar(128) collate utf8_unicode_ci default NULL,
  `idprof4` varchar(128) collate utf8_unicode_ci default NULL,
  `idprof5` varchar(128) collate utf8_unicode_ci default NULL,
  `idprof6` varchar(128) collate utf8_unicode_ci default NULL,
  `tva_intra` varchar(20) collate utf8_unicode_ci default NULL,
  `capital` double(24,8) default NULL,
  `fk_stcomm` int(11) NOT NULL default '0',
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  `prefix_comm` varchar(5) collate utf8_unicode_ci default NULL,
  `client` tinyint(4) default '0',
  `fournisseur` tinyint(4) default '0',
  `supplier_account` varchar(32) collate utf8_unicode_ci default NULL,
  `fk_prospectlevel` varchar(12) collate utf8_unicode_ci default NULL,
  `fk_incoterms` int(11) default NULL,
  `location_incoterms` varchar(255) collate utf8_unicode_ci default NULL,
  `customer_bad` tinyint(4) default '0',
  `customer_rate` double default '0',
  `supplier_rate` double default '0',
  `remise_client` double default '0',
  `remise_supplier` double default '0',
  `mode_reglement` tinyint(4) default NULL,
  `cond_reglement` tinyint(4) default NULL,
  `mode_reglement_supplier` tinyint(4) default NULL,
  `cond_reglement_supplier` tinyint(4) default NULL,
  `fk_shipping_method` int(11) default NULL,
  `tva_assuj` tinyint(4) default '1',
  `localtax1_assuj` tinyint(4) default '0',
  `localtax1_value` double(6,3) default NULL,
  `localtax2_assuj` tinyint(4) default '0',
  `localtax2_value` double(6,3) default NULL,
  `barcode` varchar(180) collate utf8_unicode_ci default NULL,
  `fk_barcode_type` int(11) default '0',
  `price_level` int(11) default NULL,
  `outstanding_limit` double(24,8) default NULL,
  `order_min_amount` double(24,8) default NULL,
  `supplier_order_min_amount` double(24,8) default NULL,
  `default_lang` varchar(6) collate utf8_unicode_ci default NULL,
  `logo` varchar(255) collate utf8_unicode_ci default NULL,
  `canvas` varchar(32) collate utf8_unicode_ci default NULL,
  `fk_entrepot` int(11) default '0',
  `webservices_url` varchar(255) collate utf8_unicode_ci default NULL,
  `webservices_key` varchar(128) collate utf8_unicode_ci default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datec` datetime default NULL,
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `fk_multicurrency` int(11) default NULL,
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_societe_prefix_comm` (`prefix_comm`,`entity`),
  UNIQUE KEY `uk_societe_code_client` (`code_client`,`entity`),
  UNIQUE KEY `uk_societe_code_fournisseur` (`code_fournisseur`,`entity`),
  UNIQUE KEY `uk_societe_barcode` (`barcode`,`fk_barcode_type`,`entity`),
  KEY `idx_societe_user_creat` (`fk_user_creat`),
  KEY `idx_societe_user_modif` (`fk_user_modif`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `llx_societe`
--

INSERT INTO `llx_societe` (`rowid`, `nom`, `name_alias`, `entity`, `ref_ext`, `ref_int`, `statut`, `parent`, `status`, `code_client`, `code_fournisseur`, `code_compta`, `code_compta_fournisseur`, `address`, `zip`, `town`, `fk_departement`, `fk_pays`, `fk_account`, `phone`, `fax`, `url`, `email`, `skype`, `twitter`, `facebook`, `linkedin`, `instagram`, `snapchat`, `googleplus`, `youtube`, `whatsapp`, `fk_effectif`, `fk_typent`, `fk_forme_juridique`, `fk_currency`, `siren`, `siret`, `ape`, `idprof4`, `idprof5`, `idprof6`, `tva_intra`, `capital`, `fk_stcomm`, `note_private`, `note_public`, `model_pdf`, `prefix_comm`, `client`, `fournisseur`, `supplier_account`, `fk_prospectlevel`, `fk_incoterms`, `location_incoterms`, `customer_bad`, `customer_rate`, `supplier_rate`, `remise_client`, `remise_supplier`, `mode_reglement`, `cond_reglement`, `mode_reglement_supplier`, `cond_reglement_supplier`, `fk_shipping_method`, `tva_assuj`, `localtax1_assuj`, `localtax1_value`, `localtax2_assuj`, `localtax2_value`, `barcode`, `fk_barcode_type`, `price_level`, `outstanding_limit`, `order_min_amount`, `supplier_order_min_amount`, `default_lang`, `logo`, `canvas`, `fk_entrepot`, `webservices_url`, `webservices_key`, `tms`, `datec`, `fk_user_creat`, `fk_user_modif`, `fk_multicurrency`, `multicurrency_code`, `import_key`) VALUES
(1, 'Ayto. Fraga', '', 1, NULL, NULL, 0, NULL, 1, 'CU1908-00001', NULL, NULL, NULL, 'Plaza España, 0', '22520', 'Fraga', 539, 4, 0, '9744520135', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 5, NULL, NULL, '', '', '', '', '', '', '', NULL, 0, NULL, NULL, NULL, NULL, 3, 0, NULL, '', 0, NULL, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0.000, NULL, 0.000, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2019-09-10 19:17:35', '2019-08-31 16:24:53', 1, 1, 0, '', NULL),
(2, 'Pedro Casas', '', 1, NULL, NULL, 0, NULL, 1, 'CU1909-00002', NULL, NULL, NULL, 'asasdf', '22520', 'Fraga', 539, 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '', '', '', '', '', '', '', NULL, 0, NULL, NULL, NULL, NULL, 1, 0, NULL, '', 0, NULL, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0.000, NULL, 0.000, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2019-09-07 06:25:57', '2019-09-07 07:57:39', 1, 1, 0, '', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_societe_account`
--

CREATE TABLE `llx_societe_account` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) default '1',
  `key_account` varchar(128) collate utf8_unicode_ci default NULL,
  `login` varchar(128) collate utf8_unicode_ci NOT NULL,
  `pass_encoding` varchar(24) collate utf8_unicode_ci default NULL,
  `pass_crypted` varchar(128) collate utf8_unicode_ci default NULL,
  `pass_temp` varchar(128) collate utf8_unicode_ci default NULL,
  `fk_soc` int(11) default NULL,
  `site` varchar(128) collate utf8_unicode_ci default NULL,
  `fk_website` int(11) default NULL,
  `note_private` text collate utf8_unicode_ci,
  `date_last_login` datetime default NULL,
  `date_previous_login` datetime default NULL,
  `date_creation` datetime NOT NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_user_creat` int(11) NOT NULL,
  `fk_user_modif` int(11) default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `status` int(11) default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_societe_account_login_website_soc` (`entity`,`fk_soc`,`login`,`site`,`fk_website`),
  UNIQUE KEY `uk_societe_account_key_account_soc` (`entity`,`fk_soc`,`key_account`,`site`,`fk_website`),
  KEY `idx_societe_account_rowid` (`rowid`),
  KEY `idx_societe_account_login` (`login`),
  KEY `idx_societe_account_status` (`status`),
  KEY `idx_societe_account_fk_website` (`fk_website`),
  KEY `idx_societe_account_fk_soc` (`fk_soc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_societe_address`
--

CREATE TABLE `llx_societe_address` (
  `rowid` int(11) NOT NULL auto_increment,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `label` varchar(30) collate utf8_unicode_ci default NULL,
  `fk_soc` int(11) default '0',
  `name` varchar(60) collate utf8_unicode_ci default NULL,
  `address` varchar(255) collate utf8_unicode_ci default NULL,
  `zip` varchar(10) collate utf8_unicode_ci default NULL,
  `town` varchar(50) collate utf8_unicode_ci default NULL,
  `fk_pays` int(11) default '0',
  `phone` varchar(20) collate utf8_unicode_ci default NULL,
  `fax` varchar(20) collate utf8_unicode_ci default NULL,
  `note` text collate utf8_unicode_ci,
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_societe_commerciaux`
--

CREATE TABLE `llx_societe_commerciaux` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_soc` int(11) default NULL,
  `fk_user` int(11) default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_societe_commerciaux` (`fk_soc`,`fk_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_societe_extrafields`
--

CREATE TABLE `llx_societe_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_societe_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_societe_log`
--

CREATE TABLE `llx_societe_log` (
  `id` int(11) NOT NULL auto_increment,
  `datel` datetime default NULL,
  `fk_soc` int(11) default NULL,
  `fk_statut` int(11) default NULL,
  `fk_user` int(11) default NULL,
  `author` varchar(30) collate utf8_unicode_ci default NULL,
  `label` varchar(128) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_societe_prices`
--

CREATE TABLE `llx_societe_prices` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_soc` int(11) default '0',
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datec` datetime default NULL,
  `fk_user_author` int(11) default NULL,
  `price_level` tinyint(4) default '1',
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_societe_remise`
--

CREATE TABLE `llx_societe_remise` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `fk_soc` int(11) NOT NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datec` datetime default NULL,
  `fk_user_author` int(11) default NULL,
  `remise_client` double(6,3) NOT NULL default '0.000',
  `note` text collate utf8_unicode_ci,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_societe_remise_except`
--

CREATE TABLE `llx_societe_remise_except` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `fk_soc` int(11) NOT NULL,
  `discount_type` int(11) NOT NULL default '0',
  `datec` datetime default NULL,
  `amount_ht` double(24,8) NOT NULL,
  `amount_tva` double(24,8) NOT NULL default '0.00000000',
  `amount_ttc` double(24,8) NOT NULL default '0.00000000',
  `tva_tx` double(6,3) NOT NULL default '0.000',
  `fk_user` int(11) NOT NULL,
  `fk_facture_line` int(11) default NULL,
  `fk_facture` int(11) default NULL,
  `fk_facture_source` int(11) default NULL,
  `fk_invoice_supplier_line` int(11) default NULL,
  `fk_invoice_supplier` int(11) default NULL,
  `fk_invoice_supplier_source` int(11) default NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `multicurrency_amount_ht` double(24,8) NOT NULL default '0.00000000',
  `multicurrency_amount_tva` double(24,8) NOT NULL default '0.00000000',
  `multicurrency_amount_ttc` double(24,8) NOT NULL default '0.00000000',
  PRIMARY KEY  (`rowid`),
  KEY `idx_societe_remise_except_fk_user` (`fk_user`),
  KEY `idx_societe_remise_except_fk_soc` (`fk_soc`),
  KEY `idx_societe_remise_except_fk_facture_line` (`fk_facture_line`),
  KEY `idx_societe_remise_except_fk_facture` (`fk_facture`),
  KEY `idx_societe_remise_except_fk_facture_source` (`fk_facture_source`),
  KEY `idx_societe_remise_except_discount_type` (`discount_type`),
  KEY `fk_soc_remise_fk_invoice_supplier_line` (`fk_invoice_supplier_line`),
  KEY `fk_societe_remise_fk_invoice_supplier_source` (`fk_invoice_supplier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_societe_remise_supplier`
--

CREATE TABLE `llx_societe_remise_supplier` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `fk_soc` int(11) NOT NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datec` datetime default NULL,
  `fk_user_author` int(11) default NULL,
  `remise_supplier` double(6,3) NOT NULL default '0.000',
  `note` text collate utf8_unicode_ci,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_societe_rib`
--

CREATE TABLE `llx_societe_rib` (
  `rowid` int(11) NOT NULL auto_increment,
  `type` varchar(32) collate utf8_unicode_ci NOT NULL default 'ban',
  `label` varchar(30) collate utf8_unicode_ci default NULL,
  `fk_soc` int(11) NOT NULL,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `bank` varchar(255) collate utf8_unicode_ci default NULL,
  `code_banque` varchar(128) collate utf8_unicode_ci default NULL,
  `code_guichet` varchar(6) collate utf8_unicode_ci default NULL,
  `number` varchar(255) collate utf8_unicode_ci default NULL,
  `cle_rib` varchar(5) collate utf8_unicode_ci default NULL,
  `bic` varchar(20) collate utf8_unicode_ci default NULL,
  `iban_prefix` varchar(34) collate utf8_unicode_ci default NULL,
  `domiciliation` varchar(255) collate utf8_unicode_ci default NULL,
  `proprio` varchar(60) collate utf8_unicode_ci default NULL,
  `owner_address` varchar(255) collate utf8_unicode_ci default NULL,
  `default_rib` smallint(6) NOT NULL default '0',
  `rum` varchar(32) collate utf8_unicode_ci default NULL,
  `date_rum` date default NULL,
  `frstrecur` varchar(16) collate utf8_unicode_ci default 'FRST',
  `last_four` varchar(4) collate utf8_unicode_ci default NULL,
  `card_type` varchar(255) collate utf8_unicode_ci default NULL,
  `cvn` varchar(255) collate utf8_unicode_ci default NULL,
  `exp_date_month` int(11) default NULL,
  `exp_date_year` int(11) default NULL,
  `country_code` varchar(10) collate utf8_unicode_ci default NULL,
  `approved` int(11) default '0',
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `ending_date` date default NULL,
  `max_total_amount_of_all_payments` double(24,8) default NULL,
  `preapproval_key` varchar(255) collate utf8_unicode_ci default NULL,
  `starting_date` date default NULL,
  `total_amount_of_all_payments` double(24,8) default NULL,
  `stripe_card_ref` varchar(128) collate utf8_unicode_ci default NULL,
  `comment` varchar(255) collate utf8_unicode_ci default NULL,
  `ipaddress` varchar(68) collate utf8_unicode_ci default NULL,
  `status` int(11) NOT NULL default '1',
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_societe_rib` (`label`,`fk_soc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_socpeople`
--

CREATE TABLE `llx_socpeople` (
  `rowid` int(11) NOT NULL auto_increment,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_soc` int(11) default NULL,
  `entity` int(11) NOT NULL default '1',
  `ref_ext` varchar(255) collate utf8_unicode_ci default NULL,
  `civility` varchar(6) collate utf8_unicode_ci default NULL,
  `lastname` varchar(50) collate utf8_unicode_ci default NULL,
  `firstname` varchar(50) collate utf8_unicode_ci default NULL,
  `address` varchar(255) collate utf8_unicode_ci default NULL,
  `zip` varchar(25) collate utf8_unicode_ci default NULL,
  `town` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_departement` int(11) default NULL,
  `fk_pays` int(11) default '0',
  `birthday` date default NULL,
  `poste` varchar(80) collate utf8_unicode_ci default NULL,
  `phone` varchar(30) collate utf8_unicode_ci default NULL,
  `phone_perso` varchar(30) collate utf8_unicode_ci default NULL,
  `phone_mobile` varchar(30) collate utf8_unicode_ci default NULL,
  `fax` varchar(30) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `jabberid` varchar(255) collate utf8_unicode_ci default NULL,
  `skype` varchar(255) collate utf8_unicode_ci default NULL,
  `twitter` varchar(255) collate utf8_unicode_ci default NULL,
  `facebook` varchar(255) collate utf8_unicode_ci default NULL,
  `linkedin` varchar(255) collate utf8_unicode_ci default NULL,
  `instagram` varchar(255) collate utf8_unicode_ci default NULL,
  `snapchat` varchar(255) collate utf8_unicode_ci default NULL,
  `googleplus` varchar(255) collate utf8_unicode_ci default NULL,
  `youtube` varchar(255) collate utf8_unicode_ci default NULL,
  `whatsapp` varchar(255) collate utf8_unicode_ci default NULL,
  `photo` varchar(255) collate utf8_unicode_ci default NULL,
  `no_email` smallint(6) NOT NULL default '0',
  `priv` smallint(6) NOT NULL default '0',
  `fk_user_creat` int(11) default '0',
  `fk_user_modif` int(11) default NULL,
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `default_lang` varchar(6) collate utf8_unicode_ci default NULL,
  `canvas` varchar(32) collate utf8_unicode_ci default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `statut` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`rowid`),
  KEY `idx_socpeople_fk_soc` (`fk_soc`),
  KEY `idx_socpeople_fk_user_creat` (`fk_user_creat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_socpeople_extrafields`
--

CREATE TABLE `llx_socpeople_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_socpeople_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_stock_mouvement`
--

CREATE TABLE `llx_stock_mouvement` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datem` datetime default NULL,
  `fk_product` int(11) NOT NULL,
  `batch` varchar(30) collate utf8_unicode_ci default NULL,
  `eatby` date default NULL,
  `sellby` date default NULL,
  `fk_entrepot` int(11) NOT NULL,
  `value` double default NULL,
  `price` double(24,8) default '0.00000000',
  `type_mouvement` smallint(6) default NULL,
  `fk_user_author` int(11) default NULL,
  `label` varchar(255) collate utf8_unicode_ci default NULL,
  `inventorycode` varchar(128) collate utf8_unicode_ci default NULL,
  `fk_project` int(11) default NULL,
  `fk_origin` int(11) default NULL,
  `origintype` varchar(32) collate utf8_unicode_ci default NULL,
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_stock_mouvement_fk_product` (`fk_product`),
  KEY `idx_stock_mouvement_fk_entrepot` (`fk_entrepot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_subscription`
--

CREATE TABLE `llx_subscription` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datec` datetime default NULL,
  `fk_adherent` int(11) default NULL,
  `fk_type` int(11) default NULL,
  `dateadh` datetime default NULL,
  `datef` date default NULL,
  `subscription` double(24,8) default NULL,
  `fk_bank` int(11) default NULL,
  `note` text collate utf8_unicode_ci,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_subscription` (`fk_adherent`,`dateadh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_supplier_proposal`
--

CREATE TABLE `llx_supplier_proposal` (
  `rowid` int(11) NOT NULL auto_increment,
  `ref` varchar(30) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `ref_ext` varchar(255) collate utf8_unicode_ci default NULL,
  `ref_int` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_soc` int(11) default NULL,
  `fk_projet` int(11) default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datec` datetime default NULL,
  `date_valid` datetime default NULL,
  `date_cloture` datetime default NULL,
  `fk_user_author` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `fk_user_valid` int(11) default NULL,
  `fk_user_cloture` int(11) default NULL,
  `fk_statut` smallint(6) NOT NULL default '0',
  `price` double default '0',
  `remise_percent` double default '0',
  `remise_absolue` double default '0',
  `remise` double default '0',
  `total_ht` double(24,8) default '0.00000000',
  `tva` double(24,8) default '0.00000000',
  `localtax1` double(24,8) default '0.00000000',
  `localtax2` double(24,8) default '0.00000000',
  `total` double(24,8) default '0.00000000',
  `fk_account` int(11) default NULL,
  `fk_currency` varchar(3) collate utf8_unicode_ci default NULL,
  `fk_cond_reglement` int(11) default NULL,
  `fk_mode_reglement` int(11) default NULL,
  `note_private` text collate utf8_unicode_ci,
  `note_public` text collate utf8_unicode_ci,
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  `last_main_doc` varchar(255) collate utf8_unicode_ci default NULL,
  `date_livraison` date default NULL,
  `fk_shipping_method` int(11) default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `extraparams` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_multicurrency` int(11) default NULL,
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_tx` double(24,8) default '1.00000000',
  `multicurrency_total_ht` double(24,8) default '0.00000000',
  `multicurrency_total_tva` double(24,8) default '0.00000000',
  `multicurrency_total_ttc` double(24,8) default '0.00000000',
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_supplier_proposaldet`
--

CREATE TABLE `llx_supplier_proposaldet` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_supplier_proposal` int(11) NOT NULL,
  `fk_parent_line` int(11) default NULL,
  `fk_product` int(11) default NULL,
  `label` varchar(255) collate utf8_unicode_ci default NULL,
  `description` text collate utf8_unicode_ci,
  `fk_remise_except` int(11) default NULL,
  `vat_src_code` varchar(10) collate utf8_unicode_ci default '',
  `tva_tx` double(6,3) default '0.000',
  `localtax1_tx` double(6,3) default '0.000',
  `localtax1_type` varchar(10) collate utf8_unicode_ci default NULL,
  `localtax2_tx` double(6,3) default '0.000',
  `localtax2_type` varchar(10) collate utf8_unicode_ci default NULL,
  `qty` double default NULL,
  `remise_percent` double default '0',
  `remise` double default '0',
  `price` double default NULL,
  `subprice` double(24,8) default '0.00000000',
  `total_ht` double(24,8) default '0.00000000',
  `total_tva` double(24,8) default '0.00000000',
  `total_localtax1` double(24,8) default '0.00000000',
  `total_localtax2` double(24,8) default '0.00000000',
  `total_ttc` double(24,8) default '0.00000000',
  `product_type` int(11) default '0',
  `info_bits` int(11) default '0',
  `buy_price_ht` double(24,8) default '0.00000000',
  `fk_product_fournisseur_price` int(11) default NULL,
  `special_code` int(11) default '0',
  `rang` int(11) default '0',
  `ref_fourn` varchar(30) collate utf8_unicode_ci default NULL,
  `fk_multicurrency` int(11) default NULL,
  `multicurrency_code` varchar(255) collate utf8_unicode_ci default NULL,
  `multicurrency_subprice` double(24,8) default '0.00000000',
  `multicurrency_total_ht` double(24,8) default '0.00000000',
  `multicurrency_total_tva` double(24,8) default '0.00000000',
  `multicurrency_total_ttc` double(24,8) default '0.00000000',
  `fk_unit` int(11) default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_supplier_proposaldet_fk_supplier_proposal` (`fk_supplier_proposal`),
  KEY `idx_supplier_proposaldet_fk_product` (`fk_product`),
  KEY `fk_supplier_proposaldet_fk_unit` (`fk_unit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_supplier_proposaldet_extrafields`
--

CREATE TABLE `llx_supplier_proposaldet_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_supplier_proposal_extrafields`
--

CREATE TABLE `llx_supplier_proposal_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_takepos_floor_tables`
--

CREATE TABLE `llx_takepos_floor_tables` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `label` varchar(255) collate utf8_unicode_ci default NULL,
  `leftpos` float default NULL,
  `toppos` float default NULL,
  `floor` smallint(6) default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_ticket`
--

CREATE TABLE `llx_ticket` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) default '1',
  `ref` varchar(128) collate utf8_unicode_ci NOT NULL,
  `track_id` varchar(128) collate utf8_unicode_ci NOT NULL,
  `fk_soc` int(11) default '0',
  `fk_project` int(11) default '0',
  `origin_email` varchar(128) collate utf8_unicode_ci default NULL,
  `fk_user_create` int(11) default NULL,
  `fk_user_assign` int(11) default NULL,
  `subject` varchar(255) collate utf8_unicode_ci default NULL,
  `message` text collate utf8_unicode_ci,
  `fk_statut` int(11) default NULL,
  `resolution` int(11) default NULL,
  `progress` varchar(100) collate utf8_unicode_ci default NULL,
  `timing` varchar(20) collate utf8_unicode_ci default NULL,
  `type_code` varchar(32) collate utf8_unicode_ci default NULL,
  `category_code` varchar(32) collate utf8_unicode_ci default NULL,
  `severity_code` varchar(32) collate utf8_unicode_ci default NULL,
  `datec` datetime default NULL,
  `date_read` datetime default NULL,
  `date_close` datetime default NULL,
  `notify_tiers_at_create` tinyint(4) default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_ticket_track_id` (`track_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_ticket_extrafields`
--

CREATE TABLE `llx_ticket_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_ticket_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_tva`
--

CREATE TABLE `llx_tva` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `datec` datetime default NULL,
  `datep` date default NULL,
  `datev` date default NULL,
  `amount` double(24,8) NOT NULL default '0.00000000',
  `fk_typepayment` int(11) default NULL,
  `num_payment` varchar(50) collate utf8_unicode_ci default NULL,
  `label` varchar(255) collate utf8_unicode_ci default NULL,
  `entity` int(11) NOT NULL default '1',
  `note` text collate utf8_unicode_ci,
  `fk_bank` int(11) default NULL,
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_user`
--

CREATE TABLE `llx_user` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `ref_ext` varchar(50) collate utf8_unicode_ci default NULL,
  `ref_int` varchar(50) collate utf8_unicode_ci default NULL,
  `employee` tinyint(4) default '1',
  `fk_establishment` int(11) default '0',
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `login` varchar(50) collate utf8_unicode_ci NOT NULL,
  `pass_encoding` varchar(24) collate utf8_unicode_ci default NULL,
  `pass` varchar(128) collate utf8_unicode_ci default NULL,
  `pass_crypted` varchar(128) collate utf8_unicode_ci default NULL,
  `pass_temp` varchar(128) collate utf8_unicode_ci default NULL,
  `api_key` varchar(128) collate utf8_unicode_ci default NULL,
  `gender` varchar(10) collate utf8_unicode_ci default NULL,
  `civility` varchar(6) collate utf8_unicode_ci default NULL,
  `lastname` varchar(50) collate utf8_unicode_ci default NULL,
  `firstname` varchar(50) collate utf8_unicode_ci default NULL,
  `address` varchar(255) collate utf8_unicode_ci default NULL,
  `zip` varchar(25) collate utf8_unicode_ci default NULL,
  `town` varchar(50) collate utf8_unicode_ci default NULL,
  `fk_state` int(11) default '0',
  `fk_country` int(11) default '0',
  `birth` date default NULL,
  `job` varchar(128) collate utf8_unicode_ci default NULL,
  `office_phone` varchar(20) collate utf8_unicode_ci default NULL,
  `office_fax` varchar(20) collate utf8_unicode_ci default NULL,
  `user_mobile` varchar(20) collate utf8_unicode_ci default NULL,
  `personal_mobile` varchar(20) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `personal_email` varchar(255) collate utf8_unicode_ci default NULL,
  `jabberid` varchar(255) collate utf8_unicode_ci default NULL,
  `skype` varchar(255) collate utf8_unicode_ci default NULL,
  `twitter` varchar(255) collate utf8_unicode_ci default NULL,
  `facebook` varchar(255) collate utf8_unicode_ci default NULL,
  `linkedin` varchar(255) collate utf8_unicode_ci default NULL,
  `instagram` varchar(255) collate utf8_unicode_ci default NULL,
  `snapchat` varchar(255) collate utf8_unicode_ci default NULL,
  `googleplus` varchar(255) collate utf8_unicode_ci default NULL,
  `youtube` varchar(255) collate utf8_unicode_ci default NULL,
  `whatsapp` varchar(255) collate utf8_unicode_ci default NULL,
  `signature` text collate utf8_unicode_ci,
  `admin` smallint(6) default '0',
  `module_comm` smallint(6) default '1',
  `module_compta` smallint(6) default '1',
  `fk_soc` int(11) default NULL,
  `fk_socpeople` int(11) default NULL,
  `fk_member` int(11) default NULL,
  `fk_user` int(11) default NULL,
  `fk_user_expense_validator` int(11) default NULL,
  `fk_user_holiday_validator` int(11) default NULL,
  `note_public` text collate utf8_unicode_ci,
  `note` text collate utf8_unicode_ci,
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  `datelastlogin` datetime default NULL,
  `datepreviouslogin` datetime default NULL,
  `egroupware_id` int(11) default NULL,
  `ldap_sid` varchar(255) collate utf8_unicode_ci default NULL,
  `openid` varchar(255) collate utf8_unicode_ci default NULL,
  `statut` tinyint(4) default '1',
  `photo` varchar(255) collate utf8_unicode_ci default NULL,
  `lang` varchar(6) collate utf8_unicode_ci default NULL,
  `color` varchar(6) collate utf8_unicode_ci default NULL,
  `barcode` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_barcode_type` int(11) default '0',
  `accountancy_code` varchar(32) collate utf8_unicode_ci default NULL,
  `nb_holiday` int(11) default '0',
  `thm` double(24,8) default NULL,
  `tjm` double(24,8) default NULL,
  `salary` double(24,8) default NULL,
  `salaryextra` double(24,8) default NULL,
  `dateemployment` date default NULL,
  `dateemploymentend` date default NULL,
  `weeklyhours` double(16,8) default NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  `default_range` int(11) default NULL,
  `default_c_exp_tax_cat` int(11) default NULL,
  `fk_warehouse` int(11) default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_user_login` (`login`,`entity`),
  UNIQUE KEY `uk_user_fk_socpeople` (`fk_socpeople`),
  UNIQUE KEY `uk_user_fk_member` (`fk_member`),
  UNIQUE KEY `uk_user_api_key` (`api_key`),
  KEY `idx_user_fk_societe` (`fk_soc`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `llx_user`
--

INSERT INTO `llx_user` (`rowid`, `entity`, `ref_ext`, `ref_int`, `employee`, `fk_establishment`, `datec`, `tms`, `fk_user_creat`, `fk_user_modif`, `login`, `pass_encoding`, `pass`, `pass_crypted`, `pass_temp`, `api_key`, `gender`, `civility`, `lastname`, `firstname`, `address`, `zip`, `town`, `fk_state`, `fk_country`, `birth`, `job`, `office_phone`, `office_fax`, `user_mobile`, `personal_mobile`, `email`, `personal_email`, `jabberid`, `skype`, `twitter`, `facebook`, `linkedin`, `instagram`, `snapchat`, `googleplus`, `youtube`, `whatsapp`, `signature`, `admin`, `module_comm`, `module_compta`, `fk_soc`, `fk_socpeople`, `fk_member`, `fk_user`, `fk_user_expense_validator`, `fk_user_holiday_validator`, `note_public`, `note`, `model_pdf`, `datelastlogin`, `datepreviouslogin`, `egroupware_id`, `ldap_sid`, `openid`, `statut`, `photo`, `lang`, `color`, `barcode`, `fk_barcode_type`, `accountancy_code`, `nb_holiday`, `thm`, `tjm`, `salary`, `salaryextra`, `dateemployment`, `dateemploymentend`, `weeklyhours`, `import_key`, `default_range`, `default_c_exp_tax_cat`, `fk_warehouse`) VALUES
(1, 0, NULL, NULL, 1, 0, '2019-07-29 16:31:46', '2019-07-29 14:31:46', NULL, NULL, 'admin', NULL, NULL, '$2y$10$HV4kedeAa/VVofufwSq2G.F2adY8aoI3t5crGZpsjeCX6eQSQxdV6', NULL, NULL, '', NULL, 'SuperAdmin', '', '', '', '', NULL, NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, '', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '2019-09-10 19:11:26', '2019-09-10 18:47:16', NULL, '', NULL, 1, NULL, NULL, '', NULL, 0, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 1, NULL, NULL, 1, 0, '2019-07-29 17:52:59', '2019-07-30 14:49:49', NULL, NULL, 'ElisaRP', NULL, NULL, '$2y$10$Xl.xBw0deZp7WiCMCRexNe9fKCNNFNL3/.ZP1DyWOC7ssX8sb07o2', NULL, '0sbqztj1', 'woman', NULL, 'Ruiz Perez', 'Elisa', 'Calle Arriba 2º 1ª', '22520', 'Fraga', NULL, NULL, '1995-07-03', '', '', '', '678952109', '', '', '', NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, '', 0, 1, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '', NULL, '2019-09-10 19:10:52', NULL, NULL, '', NULL, 1, NULL, NULL, '', NULL, 0, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_usergroup`
--

CREATE TABLE `llx_usergroup` (
  `rowid` int(11) NOT NULL auto_increment,
  `nom` varchar(180) collate utf8_unicode_ci NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `note` text collate utf8_unicode_ci,
  `model_pdf` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_usergroup_name` (`nom`,`entity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_usergroup_extrafields`
--

CREATE TABLE `llx_usergroup_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_usergroup_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_usergroup_rights`
--

CREATE TABLE `llx_usergroup_rights` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `fk_usergroup` int(11) NOT NULL,
  `fk_id` int(11) NOT NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_usergroup_rights` (`entity`,`fk_usergroup`,`fk_id`),
  KEY `fk_usergroup_rights_fk_usergroup` (`fk_usergroup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_usergroup_user`
--

CREATE TABLE `llx_usergroup_user` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `fk_user` int(11) NOT NULL,
  `fk_usergroup` int(11) NOT NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_usergroup_user` (`entity`,`fk_user`,`fk_usergroup`),
  KEY `fk_usergroup_user_fk_user` (`fk_user`),
  KEY `fk_usergroup_user_fk_usergroup` (`fk_usergroup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_user_alert`
--

CREATE TABLE `llx_user_alert` (
  `rowid` int(11) NOT NULL auto_increment,
  `type` int(11) default NULL,
  `fk_contact` int(11) default NULL,
  `fk_user` int(11) default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_user_clicktodial`
--

CREATE TABLE `llx_user_clicktodial` (
  `fk_user` int(11) NOT NULL,
  `url` varchar(255) collate utf8_unicode_ci default NULL,
  `login` varchar(32) collate utf8_unicode_ci default NULL,
  `pass` varchar(64) collate utf8_unicode_ci default NULL,
  `poste` varchar(20) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`fk_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_user_employment`
--

CREATE TABLE `llx_user_employment` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `ref` varchar(50) collate utf8_unicode_ci default NULL,
  `ref_ext` varchar(50) collate utf8_unicode_ci default NULL,
  `fk_user` int(11) default NULL,
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `job` varchar(128) collate utf8_unicode_ci default NULL,
  `status` int(11) NOT NULL,
  `salary` double(24,8) default NULL,
  `salaryextra` double(24,8) default NULL,
  `weeklyhours` double(16,8) default NULL,
  `dateemployment` date default NULL,
  `dateemploymentend` date default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_user_employment` (`ref`,`entity`),
  KEY `fk_user_employment_fk_user` (`fk_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_user_extrafields`
--

CREATE TABLE `llx_user_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_user_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_user_param`
--

CREATE TABLE `llx_user_param` (
  `fk_user` int(11) NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `param` varchar(180) collate utf8_unicode_ci NOT NULL,
  `value` text collate utf8_unicode_ci NOT NULL,
  UNIQUE KEY `uk_user_param` (`fk_user`,`param`,`entity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_user_rib`
--

CREATE TABLE `llx_user_rib` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_user` int(11) NOT NULL,
  `entity` int(11) NOT NULL default '1',
  `datec` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `label` varchar(30) collate utf8_unicode_ci default NULL,
  `bank` varchar(255) collate utf8_unicode_ci default NULL,
  `code_banque` varchar(128) collate utf8_unicode_ci default NULL,
  `code_guichet` varchar(6) collate utf8_unicode_ci default NULL,
  `number` varchar(255) collate utf8_unicode_ci default NULL,
  `cle_rib` varchar(5) collate utf8_unicode_ci default NULL,
  `bic` varchar(11) collate utf8_unicode_ci default NULL,
  `iban_prefix` varchar(34) collate utf8_unicode_ci default NULL,
  `domiciliation` varchar(255) collate utf8_unicode_ci default NULL,
  `proprio` varchar(60) collate utf8_unicode_ci default NULL,
  `owner_address` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_user_rights`
--

CREATE TABLE `llx_user_rights` (
  `rowid` int(11) NOT NULL auto_increment,
  `entity` int(11) NOT NULL default '1',
  `fk_user` int(11) NOT NULL,
  `fk_id` int(11) NOT NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_user_rights` (`entity`,`fk_user`,`fk_id`),
  KEY `fk_user_rights_fk_user_user` (`fk_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=513 ;

--
-- Volcado de datos para la tabla `llx_user_rights`
--

INSERT INTO `llx_user_rights` (`rowid`, `entity`, `fk_user`, `fk_id`) VALUES
(381, 1, 1, 21),
(374, 1, 1, 22),
(375, 1, 1, 24),
(376, 1, 1, 25),
(378, 1, 1, 26),
(380, 1, 1, 27),
(382, 1, 1, 28),
(405, 1, 1, 31),
(400, 1, 1, 32),
(402, 1, 1, 34),
(404, 1, 1, 38),
(406, 1, 1, 39),
(31, 1, 1, 71),
(26, 1, 1, 72),
(28, 1, 1, 74),
(32, 1, 1, 75),
(30, 1, 1, 76),
(34, 1, 1, 78),
(35, 1, 1, 79),
(388, 1, 1, 121),
(385, 1, 1, 122),
(387, 1, 1, 125),
(389, 1, 1, 126),
(425, 1, 1, 241),
(424, 1, 1, 242),
(426, 1, 1, 243),
(390, 1, 1, 262),
(396, 1, 1, 281),
(393, 1, 1, 282),
(395, 1, 1, 283),
(397, 1, 1, 286),
(412, 1, 1, 531),
(409, 1, 1, 532),
(411, 1, 1, 534),
(413, 1, 1, 538),
(370, 1, 1, 771),
(359, 1, 1, 772),
(361, 1, 1, 773),
(363, 1, 1, 775),
(365, 1, 1, 776),
(367, 1, 1, 777),
(369, 1, 1, 778),
(371, 1, 1, 779),
(417, 1, 1, 1001),
(416, 1, 1, 1002),
(418, 1, 1, 1003),
(420, 1, 1, 1004),
(421, 1, 1, 1005),
(441, 1, 1, 2401),
(440, 1, 1, 2402),
(442, 1, 1, 2403),
(446, 1, 1, 2411),
(445, 1, 1, 2412),
(447, 1, 1, 2413),
(448, 1, 1, 2414),
(90, 1, 1, 20001),
(81, 1, 1, 20002),
(83, 1, 1, 20003),
(87, 1, 1, 20004),
(89, 1, 1, 20005),
(91, 1, 1, 20006),
(85, 1, 1, 20007),
(17, 1, 1, 63001),
(14, 1, 1, 63002),
(16, 1, 1, 63003),
(18, 1, 1, 63004),
(355, 1, 1, 500100),
(354, 1, 1, 500101),
(356, 1, 1, 500102),
(496, 1, 2, 21),
(497, 1, 2, 22),
(495, 1, 2, 24),
(494, 1, 2, 25),
(493, 1, 2, 26),
(491, 1, 2, 27),
(489, 1, 2, 28),
(48, 1, 2, 71),
(43, 1, 2, 72),
(45, 1, 2, 74),
(47, 1, 2, 75),
(49, 1, 2, 76),
(51, 1, 2, 78),
(52, 1, 2, 79),
(459, 1, 2, 121),
(456, 1, 2, 122),
(458, 1, 2, 125),
(460, 1, 2, 126),
(452, 1, 2, 241),
(451, 1, 2, 242),
(453, 1, 2, 243),
(470, 1, 2, 251),
(461, 1, 2, 262),
(467, 1, 2, 281),
(464, 1, 2, 282),
(466, 1, 2, 283),
(468, 1, 2, 286),
(469, 1, 2, 342),
(472, 1, 2, 343),
(471, 1, 2, 351),
(478, 1, 2, 531),
(475, 1, 2, 532),
(477, 1, 2, 534),
(479, 1, 2, 538),
(511, 1, 2, 771),
(500, 1, 2, 772),
(502, 1, 2, 773),
(504, 1, 2, 775),
(506, 1, 2, 776),
(508, 1, 2, 777),
(510, 1, 2, 778),
(512, 1, 2, 779),
(56, 1, 2, 2401),
(55, 1, 2, 2402),
(57, 1, 2, 2403),
(61, 1, 2, 2411),
(60, 1, 2, 2412),
(62, 1, 2, 2413),
(63, 1, 2, 2414),
(486, 1, 2, 63001),
(487, 1, 2, 63002),
(485, 1, 2, 63003),
(483, 1, 2, 63004),
(39, 1, 2, 500100),
(38, 1, 2, 500101),
(40, 1, 2, 500102);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_website`
--

CREATE TABLE `llx_website` (
  `rowid` int(11) NOT NULL auto_increment,
  `type_container` varchar(16) collate utf8_unicode_ci NOT NULL default 'page',
  `entity` int(11) NOT NULL default '1',
  `ref` varchar(128) collate utf8_unicode_ci NOT NULL,
  `description` varchar(255) collate utf8_unicode_ci default NULL,
  `maincolor` varchar(16) collate utf8_unicode_ci default NULL,
  `maincolorbis` varchar(16) collate utf8_unicode_ci default NULL,
  `status` int(11) default '1',
  `fk_default_home` int(11) default NULL,
  `virtualhost` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `date_creation` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_website_ref` (`ref`,`entity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_website_extrafields`
--

CREATE TABLE `llx_website_extrafields` (
  `rowid` int(11) NOT NULL auto_increment,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `fk_object` int(11) NOT NULL,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  KEY `idx_website_extrafields` (`fk_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llx_website_page`
--

CREATE TABLE `llx_website_page` (
  `rowid` int(11) NOT NULL auto_increment,
  `fk_website` int(11) NOT NULL,
  `type_container` varchar(16) collate utf8_unicode_ci NOT NULL default 'page',
  `pageurl` varchar(255) collate utf8_unicode_ci NOT NULL,
  `aliasalt` varchar(255) collate utf8_unicode_ci default NULL,
  `title` varchar(255) collate utf8_unicode_ci default NULL,
  `description` varchar(255) collate utf8_unicode_ci default NULL,
  `image` varchar(255) collate utf8_unicode_ci default NULL,
  `keywords` varchar(255) collate utf8_unicode_ci default NULL,
  `lang` varchar(6) collate utf8_unicode_ci default NULL,
  `fk_page` int(11) default NULL,
  `htmlheader` text collate utf8_unicode_ci,
  `content` mediumtext collate utf8_unicode_ci,
  `status` int(11) default '1',
  `grabbed_from` varchar(255) collate utf8_unicode_ci default NULL,
  `fk_user_creat` int(11) default NULL,
  `fk_user_modif` int(11) default NULL,
  `date_creation` datetime default NULL,
  `tms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `import_key` varchar(14) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`rowid`),
  UNIQUE KEY `uk_website_page_url` (`fk_website`,`pageurl`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `llx_accounting_account`
--
ALTER TABLE `llx_accounting_account`
  ADD CONSTRAINT `fk_accounting_account_fk_pcg_version` FOREIGN KEY (`fk_pcg_version`) REFERENCES `llx_accounting_system` (`pcg_version`);

--
-- Filtros para la tabla `llx_adherent`
--
ALTER TABLE `llx_adherent`
  ADD CONSTRAINT `adherent_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`),
  ADD CONSTRAINT `fk_adherent_adherent_type` FOREIGN KEY (`fk_adherent_type`) REFERENCES `llx_adherent_type` (`rowid`);

--
-- Filtros para la tabla `llx_asset`
--
ALTER TABLE `llx_asset`
  ADD CONSTRAINT `fk_asset_asset_type` FOREIGN KEY (`fk_asset_type`) REFERENCES `llx_asset_type` (`rowid`);

--
-- Filtros para la tabla `llx_bank_account`
--
ALTER TABLE `llx_bank_account`
  ADD CONSTRAINT `fk_bank_account_accountancy_journal` FOREIGN KEY (`fk_accountancy_journal`) REFERENCES `llx_accounting_journal` (`rowid`);

--
-- Filtros para la tabla `llx_bom_bom`
--
ALTER TABLE `llx_bom_bom`
  ADD CONSTRAINT `llx_bom_bom_fk_user_creat` FOREIGN KEY (`fk_user_creat`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_bom_bomline`
--
ALTER TABLE `llx_bom_bomline`
  ADD CONSTRAINT `llx_bom_bomline_fk_bom` FOREIGN KEY (`fk_bom`) REFERENCES `llx_bom_bom` (`rowid`);

--
-- Filtros para la tabla `llx_boxes`
--
ALTER TABLE `llx_boxes`
  ADD CONSTRAINT `fk_boxes_box_id` FOREIGN KEY (`box_id`) REFERENCES `llx_boxes_def` (`rowid`);

--
-- Filtros para la tabla `llx_budget_lines`
--
ALTER TABLE `llx_budget_lines`
  ADD CONSTRAINT `fk_budget_lines_budget` FOREIGN KEY (`fk_budget`) REFERENCES `llx_budget` (`rowid`);

--
-- Filtros para la tabla `llx_categorie_account`
--
ALTER TABLE `llx_categorie_account`
  ADD CONSTRAINT `fk_categorie_account_categorie_rowid` FOREIGN KEY (`fk_categorie`) REFERENCES `llx_categorie` (`rowid`),
  ADD CONSTRAINT `fk_categorie_account_fk_account` FOREIGN KEY (`fk_account`) REFERENCES `llx_bank_account` (`rowid`);

--
-- Filtros para la tabla `llx_categorie_contact`
--
ALTER TABLE `llx_categorie_contact`
  ADD CONSTRAINT `fk_categorie_contact_categorie_rowid` FOREIGN KEY (`fk_categorie`) REFERENCES `llx_categorie` (`rowid`),
  ADD CONSTRAINT `fk_categorie_contact_fk_socpeople` FOREIGN KEY (`fk_socpeople`) REFERENCES `llx_socpeople` (`rowid`);

--
-- Filtros para la tabla `llx_categorie_fournisseur`
--
ALTER TABLE `llx_categorie_fournisseur`
  ADD CONSTRAINT `fk_categorie_fournisseur_categorie_rowid` FOREIGN KEY (`fk_categorie`) REFERENCES `llx_categorie` (`rowid`),
  ADD CONSTRAINT `fk_categorie_fournisseur_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`);

--
-- Filtros para la tabla `llx_categorie_lang`
--
ALTER TABLE `llx_categorie_lang`
  ADD CONSTRAINT `fk_category_lang_fk_category` FOREIGN KEY (`fk_category`) REFERENCES `llx_categorie` (`rowid`);

--
-- Filtros para la tabla `llx_categorie_member`
--
ALTER TABLE `llx_categorie_member`
  ADD CONSTRAINT `fk_categorie_member_categorie_rowid` FOREIGN KEY (`fk_categorie`) REFERENCES `llx_categorie` (`rowid`),
  ADD CONSTRAINT `fk_categorie_member_member_rowid` FOREIGN KEY (`fk_member`) REFERENCES `llx_adherent` (`rowid`);

--
-- Filtros para la tabla `llx_categorie_product`
--
ALTER TABLE `llx_categorie_product`
  ADD CONSTRAINT `fk_categorie_product_categorie_rowid` FOREIGN KEY (`fk_categorie`) REFERENCES `llx_categorie` (`rowid`),
  ADD CONSTRAINT `fk_categorie_product_product_rowid` FOREIGN KEY (`fk_product`) REFERENCES `llx_product` (`rowid`);

--
-- Filtros para la tabla `llx_categorie_project`
--
ALTER TABLE `llx_categorie_project`
  ADD CONSTRAINT `fk_categorie_project_categorie_rowid` FOREIGN KEY (`fk_categorie`) REFERENCES `llx_categorie` (`rowid`),
  ADD CONSTRAINT `fk_categorie_project_fk_project_rowid` FOREIGN KEY (`fk_project`) REFERENCES `llx_projet` (`rowid`);

--
-- Filtros para la tabla `llx_categorie_societe`
--
ALTER TABLE `llx_categorie_societe`
  ADD CONSTRAINT `fk_categorie_societe_categorie_rowid` FOREIGN KEY (`fk_categorie`) REFERENCES `llx_categorie` (`rowid`),
  ADD CONSTRAINT `fk_categorie_societe_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`);

--
-- Filtros para la tabla `llx_categorie_user`
--
ALTER TABLE `llx_categorie_user`
  ADD CONSTRAINT `fk_categorie_user_categorie_rowid` FOREIGN KEY (`fk_categorie`) REFERENCES `llx_categorie` (`rowid`),
  ADD CONSTRAINT `fk_categorie_user_fk_user` FOREIGN KEY (`fk_user`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_commande`
--
ALTER TABLE `llx_commande`
  ADD CONSTRAINT `fk_commande_fk_projet` FOREIGN KEY (`fk_projet`) REFERENCES `llx_projet` (`rowid`),
  ADD CONSTRAINT `fk_commande_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`),
  ADD CONSTRAINT `fk_commande_fk_user_author` FOREIGN KEY (`fk_user_author`) REFERENCES `llx_user` (`rowid`),
  ADD CONSTRAINT `fk_commande_fk_user_cloture` FOREIGN KEY (`fk_user_cloture`) REFERENCES `llx_user` (`rowid`),
  ADD CONSTRAINT `fk_commande_fk_user_valid` FOREIGN KEY (`fk_user_valid`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_commandedet`
--
ALTER TABLE `llx_commandedet`
  ADD CONSTRAINT `fk_commandedet_fk_commande` FOREIGN KEY (`fk_commande`) REFERENCES `llx_commande` (`rowid`),
  ADD CONSTRAINT `fk_commandedet_fk_unit` FOREIGN KEY (`fk_unit`) REFERENCES `llx_c_units` (`rowid`);

--
-- Filtros para la tabla `llx_commande_fournisseur`
--
ALTER TABLE `llx_commande_fournisseur`
  ADD CONSTRAINT `fk_commande_fournisseur_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`);

--
-- Filtros para la tabla `llx_commande_fournisseurdet`
--
ALTER TABLE `llx_commande_fournisseurdet`
  ADD CONSTRAINT `fk_commande_fournisseurdet_fk_unit` FOREIGN KEY (`fk_unit`) REFERENCES `llx_c_units` (`rowid`);

--
-- Filtros para la tabla `llx_commande_fournisseur_dispatch`
--
ALTER TABLE `llx_commande_fournisseur_dispatch`
  ADD CONSTRAINT `fk_commande_fournisseur_dispatch_fk_reception` FOREIGN KEY (`fk_reception`) REFERENCES `llx_reception` (`rowid`);

--
-- Filtros para la tabla `llx_contrat`
--
ALTER TABLE `llx_contrat`
  ADD CONSTRAINT `fk_contrat_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`),
  ADD CONSTRAINT `fk_contrat_user_author` FOREIGN KEY (`fk_user_author`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_contratdet`
--
ALTER TABLE `llx_contratdet`
  ADD CONSTRAINT `fk_contratdet_fk_contrat` FOREIGN KEY (`fk_contrat`) REFERENCES `llx_contrat` (`rowid`),
  ADD CONSTRAINT `fk_contratdet_fk_product` FOREIGN KEY (`fk_product`) REFERENCES `llx_product` (`rowid`),
  ADD CONSTRAINT `fk_contratdet_fk_unit` FOREIGN KEY (`fk_unit`) REFERENCES `llx_c_units` (`rowid`);

--
-- Filtros para la tabla `llx_contratdet_log`
--
ALTER TABLE `llx_contratdet_log`
  ADD CONSTRAINT `fk_contratdet_log_fk_contratdet` FOREIGN KEY (`fk_contratdet`) REFERENCES `llx_contratdet` (`rowid`);

--
-- Filtros para la tabla `llx_c_departements`
--
ALTER TABLE `llx_c_departements`
  ADD CONSTRAINT `fk_departements_fk_region` FOREIGN KEY (`fk_region`) REFERENCES `llx_c_regions` (`code_region`);

--
-- Filtros para la tabla `llx_c_regions`
--
ALTER TABLE `llx_c_regions`
  ADD CONSTRAINT `fk_c_regions_fk_pays` FOREIGN KEY (`fk_pays`) REFERENCES `llx_c_country` (`rowid`);

--
-- Filtros para la tabla `llx_c_ziptown`
--
ALTER TABLE `llx_c_ziptown`
  ADD CONSTRAINT `fk_c_ziptown_fk_county` FOREIGN KEY (`fk_county`) REFERENCES `llx_c_departements` (`rowid`),
  ADD CONSTRAINT `fk_c_ziptown_fk_pays` FOREIGN KEY (`fk_pays`) REFERENCES `llx_c_country` (`rowid`);

--
-- Filtros para la tabla `llx_ecm_directories`
--
ALTER TABLE `llx_ecm_directories`
  ADD CONSTRAINT `fk_ecm_directories_fk_user_c` FOREIGN KEY (`fk_user_c`) REFERENCES `llx_user` (`rowid`),
  ADD CONSTRAINT `fk_ecm_directories_fk_user_m` FOREIGN KEY (`fk_user_m`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_element_contact`
--
ALTER TABLE `llx_element_contact`
  ADD CONSTRAINT `fk_element_contact_fk_c_type_contact` FOREIGN KEY (`fk_c_type_contact`) REFERENCES `llx_c_type_contact` (`rowid`);

--
-- Filtros para la tabla `llx_emailcollector_emailcollectoraction`
--
ALTER TABLE `llx_emailcollector_emailcollectoraction`
  ADD CONSTRAINT `fk_emailcollectoraction_fk_emailcollector` FOREIGN KEY (`fk_emailcollector`) REFERENCES `llx_emailcollector_emailcollector` (`rowid`);

--
-- Filtros para la tabla `llx_emailcollector_emailcollectorfilter`
--
ALTER TABLE `llx_emailcollector_emailcollectorfilter`
  ADD CONSTRAINT `fk_emailcollectorfilter_fk_emailcollector` FOREIGN KEY (`fk_emailcollector`) REFERENCES `llx_emailcollector_emailcollector` (`rowid`);

--
-- Filtros para la tabla `llx_expedition`
--
ALTER TABLE `llx_expedition`
  ADD CONSTRAINT `fk_expedition_fk_shipping_method` FOREIGN KEY (`fk_shipping_method`) REFERENCES `llx_c_shipment_mode` (`rowid`),
  ADD CONSTRAINT `fk_expedition_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`),
  ADD CONSTRAINT `fk_expedition_fk_user_author` FOREIGN KEY (`fk_user_author`) REFERENCES `llx_user` (`rowid`),
  ADD CONSTRAINT `fk_expedition_fk_user_valid` FOREIGN KEY (`fk_user_valid`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_expeditiondet`
--
ALTER TABLE `llx_expeditiondet`
  ADD CONSTRAINT `fk_expeditiondet_fk_expedition` FOREIGN KEY (`fk_expedition`) REFERENCES `llx_expedition` (`rowid`);

--
-- Filtros para la tabla `llx_expeditiondet_batch`
--
ALTER TABLE `llx_expeditiondet_batch`
  ADD CONSTRAINT `fk_expeditiondet_batch_fk_expeditiondet` FOREIGN KEY (`fk_expeditiondet`) REFERENCES `llx_expeditiondet` (`rowid`);

--
-- Filtros para la tabla `llx_facture`
--
ALTER TABLE `llx_facture`
  ADD CONSTRAINT `fk_facture_fk_facture_source` FOREIGN KEY (`fk_facture_source`) REFERENCES `llx_facture` (`rowid`),
  ADD CONSTRAINT `fk_facture_fk_projet` FOREIGN KEY (`fk_projet`) REFERENCES `llx_projet` (`rowid`),
  ADD CONSTRAINT `fk_facture_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`),
  ADD CONSTRAINT `fk_facture_fk_user_author` FOREIGN KEY (`fk_user_author`) REFERENCES `llx_user` (`rowid`),
  ADD CONSTRAINT `fk_facture_fk_user_valid` FOREIGN KEY (`fk_user_valid`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_facturedet`
--
ALTER TABLE `llx_facturedet`
  ADD CONSTRAINT `fk_facturedet_fk_facture` FOREIGN KEY (`fk_facture`) REFERENCES `llx_facture` (`rowid`),
  ADD CONSTRAINT `fk_facturedet_fk_unit` FOREIGN KEY (`fk_unit`) REFERENCES `llx_c_units` (`rowid`);

--
-- Filtros para la tabla `llx_facturedet_rec`
--
ALTER TABLE `llx_facturedet_rec`
  ADD CONSTRAINT `fk_facturedet_rec_fk_unit` FOREIGN KEY (`fk_unit`) REFERENCES `llx_c_units` (`rowid`);

--
-- Filtros para la tabla `llx_facture_fourn`
--
ALTER TABLE `llx_facture_fourn`
  ADD CONSTRAINT `fk_facture_fourn_fk_projet` FOREIGN KEY (`fk_projet`) REFERENCES `llx_projet` (`rowid`),
  ADD CONSTRAINT `fk_facture_fourn_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`),
  ADD CONSTRAINT `fk_facture_fourn_fk_user_author` FOREIGN KEY (`fk_user_author`) REFERENCES `llx_user` (`rowid`),
  ADD CONSTRAINT `fk_facture_fourn_fk_user_valid` FOREIGN KEY (`fk_user_valid`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_facture_fourn_det`
--
ALTER TABLE `llx_facture_fourn_det`
  ADD CONSTRAINT `fk_facture_fourn_det_fk_facture` FOREIGN KEY (`fk_facture_fourn`) REFERENCES `llx_facture_fourn` (`rowid`),
  ADD CONSTRAINT `fk_facture_fourn_det_fk_unit` FOREIGN KEY (`fk_unit`) REFERENCES `llx_c_units` (`rowid`);

--
-- Filtros para la tabla `llx_facture_rec`
--
ALTER TABLE `llx_facture_rec`
  ADD CONSTRAINT `fk_facture_rec_fk_projet` FOREIGN KEY (`fk_projet`) REFERENCES `llx_projet` (`rowid`),
  ADD CONSTRAINT `fk_facture_rec_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`),
  ADD CONSTRAINT `fk_facture_rec_fk_user_author` FOREIGN KEY (`fk_user_author`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_fichinter`
--
ALTER TABLE `llx_fichinter`
  ADD CONSTRAINT `fk_fichinter_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`);

--
-- Filtros para la tabla `llx_fichinterdet`
--
ALTER TABLE `llx_fichinterdet`
  ADD CONSTRAINT `fk_fichinterdet_fk_fichinter` FOREIGN KEY (`fk_fichinter`) REFERENCES `llx_fichinter` (`rowid`);

--
-- Filtros para la tabla `llx_fichinter_rec`
--
ALTER TABLE `llx_fichinter_rec`
  ADD CONSTRAINT `fk_fichinter_rec_fk_projet` FOREIGN KEY (`fk_projet`) REFERENCES `llx_projet` (`rowid`),
  ADD CONSTRAINT `fk_fichinter_rec_fk_user_author` FOREIGN KEY (`fk_user_author`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_livraison`
--
ALTER TABLE `llx_livraison`
  ADD CONSTRAINT `fk_livraison_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`),
  ADD CONSTRAINT `fk_livraison_fk_user_author` FOREIGN KEY (`fk_user_author`) REFERENCES `llx_user` (`rowid`),
  ADD CONSTRAINT `fk_livraison_fk_user_valid` FOREIGN KEY (`fk_user_valid`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_livraisondet`
--
ALTER TABLE `llx_livraisondet`
  ADD CONSTRAINT `fk_livraisondet_fk_livraison` FOREIGN KEY (`fk_livraison`) REFERENCES `llx_livraison` (`rowid`);

--
-- Filtros para la tabla `llx_paiement_facture`
--
ALTER TABLE `llx_paiement_facture`
  ADD CONSTRAINT `fk_paiement_facture_fk_facture` FOREIGN KEY (`fk_facture`) REFERENCES `llx_facture` (`rowid`),
  ADD CONSTRAINT `fk_paiement_facture_fk_paiement` FOREIGN KEY (`fk_paiement`) REFERENCES `llx_paiement` (`rowid`);

--
-- Filtros para la tabla `llx_payment_salary`
--
ALTER TABLE `llx_payment_salary`
  ADD CONSTRAINT `fk_payment_salary_user` FOREIGN KEY (`fk_user`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_prelevement_facture`
--
ALTER TABLE `llx_prelevement_facture`
  ADD CONSTRAINT `fk_prelevement_facture_fk_prelevement_lignes` FOREIGN KEY (`fk_prelevement_lignes`) REFERENCES `llx_prelevement_lignes` (`rowid`);

--
-- Filtros para la tabla `llx_prelevement_lignes`
--
ALTER TABLE `llx_prelevement_lignes`
  ADD CONSTRAINT `fk_prelevement_lignes_fk_prelevement_bons` FOREIGN KEY (`fk_prelevement_bons`) REFERENCES `llx_prelevement_bons` (`rowid`);

--
-- Filtros para la tabla `llx_product`
--
ALTER TABLE `llx_product`
  ADD CONSTRAINT `fk_product_barcode_type` FOREIGN KEY (`fk_barcode_type`) REFERENCES `llx_c_barcode_type` (`rowid`),
  ADD CONSTRAINT `fk_product_default_warehouse` FOREIGN KEY (`fk_default_warehouse`) REFERENCES `llx_entrepot` (`rowid`),
  ADD CONSTRAINT `fk_product_fk_country` FOREIGN KEY (`fk_country`) REFERENCES `llx_c_country` (`rowid`),
  ADD CONSTRAINT `fk_product_fk_unit` FOREIGN KEY (`fk_unit`) REFERENCES `llx_c_units` (`rowid`);

--
-- Filtros para la tabla `llx_product_batch`
--
ALTER TABLE `llx_product_batch`
  ADD CONSTRAINT `fk_product_batch_fk_product_stock` FOREIGN KEY (`fk_product_stock`) REFERENCES `llx_product_stock` (`rowid`);

--
-- Filtros para la tabla `llx_product_customer_price`
--
ALTER TABLE `llx_product_customer_price`
  ADD CONSTRAINT `fk_product_customer_price_fk_product` FOREIGN KEY (`fk_product`) REFERENCES `llx_product` (`rowid`),
  ADD CONSTRAINT `fk_product_customer_price_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`),
  ADD CONSTRAINT `fk_product_customer_price_fk_user` FOREIGN KEY (`fk_user`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_product_fournisseur_price`
--
ALTER TABLE `llx_product_fournisseur_price`
  ADD CONSTRAINT `fk_product_fournisseur_price_barcode_type` FOREIGN KEY (`fk_barcode_type`) REFERENCES `llx_c_barcode_type` (`rowid`),
  ADD CONSTRAINT `fk_product_fournisseur_price_fk_product` FOREIGN KEY (`fk_product`) REFERENCES `llx_product` (`rowid`),
  ADD CONSTRAINT `fk_product_fournisseur_price_fk_user` FOREIGN KEY (`fk_user`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_product_lang`
--
ALTER TABLE `llx_product_lang`
  ADD CONSTRAINT `fk_product_lang_fk_product` FOREIGN KEY (`fk_product`) REFERENCES `llx_product` (`rowid`);

--
-- Filtros para la tabla `llx_product_price`
--
ALTER TABLE `llx_product_price`
  ADD CONSTRAINT `fk_product_price_product` FOREIGN KEY (`fk_user_author`) REFERENCES `llx_user` (`rowid`),
  ADD CONSTRAINT `fk_product_price_user_author` FOREIGN KEY (`fk_product`) REFERENCES `llx_product` (`rowid`);

--
-- Filtros para la tabla `llx_product_price_by_qty`
--
ALTER TABLE `llx_product_price_by_qty`
  ADD CONSTRAINT `fk_product_price_by_qty_fk_product_price` FOREIGN KEY (`fk_product_price`) REFERENCES `llx_product_price` (`rowid`);

--
-- Filtros para la tabla `llx_projet`
--
ALTER TABLE `llx_projet`
  ADD CONSTRAINT `fk_projet_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`);

--
-- Filtros para la tabla `llx_projet_task`
--
ALTER TABLE `llx_projet_task`
  ADD CONSTRAINT `fk_projet_task_fk_projet` FOREIGN KEY (`fk_projet`) REFERENCES `llx_projet` (`rowid`),
  ADD CONSTRAINT `fk_projet_task_fk_user_creat` FOREIGN KEY (`fk_user_creat`) REFERENCES `llx_user` (`rowid`),
  ADD CONSTRAINT `fk_projet_task_fk_user_valid` FOREIGN KEY (`fk_user_valid`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_propal`
--
ALTER TABLE `llx_propal`
  ADD CONSTRAINT `fk_propal_fk_projet` FOREIGN KEY (`fk_projet`) REFERENCES `llx_projet` (`rowid`),
  ADD CONSTRAINT `fk_propal_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`),
  ADD CONSTRAINT `fk_propal_fk_user_author` FOREIGN KEY (`fk_user_author`) REFERENCES `llx_user` (`rowid`),
  ADD CONSTRAINT `fk_propal_fk_user_cloture` FOREIGN KEY (`fk_user_cloture`) REFERENCES `llx_user` (`rowid`),
  ADD CONSTRAINT `fk_propal_fk_user_valid` FOREIGN KEY (`fk_user_valid`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_propaldet`
--
ALTER TABLE `llx_propaldet`
  ADD CONSTRAINT `fk_propaldet_fk_propal` FOREIGN KEY (`fk_propal`) REFERENCES `llx_propal` (`rowid`),
  ADD CONSTRAINT `fk_propaldet_fk_unit` FOREIGN KEY (`fk_unit`) REFERENCES `llx_c_units` (`rowid`);

--
-- Filtros para la tabla `llx_reception`
--
ALTER TABLE `llx_reception`
  ADD CONSTRAINT `fk_reception_fk_shipping_method` FOREIGN KEY (`fk_shipping_method`) REFERENCES `llx_c_shipment_mode` (`rowid`),
  ADD CONSTRAINT `fk_reception_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`),
  ADD CONSTRAINT `fk_reception_fk_user_author` FOREIGN KEY (`fk_user_author`) REFERENCES `llx_user` (`rowid`),
  ADD CONSTRAINT `fk_reception_fk_user_valid` FOREIGN KEY (`fk_user_valid`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_resource`
--
ALTER TABLE `llx_resource`
  ADD CONSTRAINT `fk_resource_fk_country` FOREIGN KEY (`fk_country`) REFERENCES `llx_c_country` (`rowid`);

--
-- Filtros para la tabla `llx_societe_account`
--
ALTER TABLE `llx_societe_account`
  ADD CONSTRAINT `llx_societe_account_fk_societe` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`),
  ADD CONSTRAINT `llx_societe_account_fk_website` FOREIGN KEY (`fk_website`) REFERENCES `llx_website` (`rowid`);

--
-- Filtros para la tabla `llx_societe_remise_except`
--
ALTER TABLE `llx_societe_remise_except`
  ADD CONSTRAINT `fk_societe_remise_fk_facture` FOREIGN KEY (`fk_facture`) REFERENCES `llx_facture` (`rowid`),
  ADD CONSTRAINT `fk_societe_remise_fk_facture_source` FOREIGN KEY (`fk_facture_source`) REFERENCES `llx_facture` (`rowid`),
  ADD CONSTRAINT `fk_societe_remise_fk_invoice_supplier` FOREIGN KEY (`fk_invoice_supplier`) REFERENCES `llx_facture_fourn` (`rowid`),
  ADD CONSTRAINT `fk_societe_remise_fk_invoice_supplier_source` FOREIGN KEY (`fk_invoice_supplier`) REFERENCES `llx_facture_fourn` (`rowid`),
  ADD CONSTRAINT `fk_societe_remise_fk_user` FOREIGN KEY (`fk_user`) REFERENCES `llx_user` (`rowid`),
  ADD CONSTRAINT `fk_soc_remise_fk_facture_line` FOREIGN KEY (`fk_facture_line`) REFERENCES `llx_facturedet` (`rowid`),
  ADD CONSTRAINT `fk_soc_remise_fk_invoice_supplier_line` FOREIGN KEY (`fk_invoice_supplier_line`) REFERENCES `llx_facture_fourn_det` (`rowid`),
  ADD CONSTRAINT `fk_soc_remise_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`);

--
-- Filtros para la tabla `llx_socpeople`
--
ALTER TABLE `llx_socpeople`
  ADD CONSTRAINT `fk_socpeople_fk_soc` FOREIGN KEY (`fk_soc`) REFERENCES `llx_societe` (`rowid`),
  ADD CONSTRAINT `fk_socpeople_user_creat_user_rowid` FOREIGN KEY (`fk_user_creat`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_supplier_proposaldet`
--
ALTER TABLE `llx_supplier_proposaldet`
  ADD CONSTRAINT `fk_supplier_proposaldet_fk_supplier_proposal` FOREIGN KEY (`fk_supplier_proposal`) REFERENCES `llx_supplier_proposal` (`rowid`),
  ADD CONSTRAINT `fk_supplier_proposaldet_fk_unit` FOREIGN KEY (`fk_unit`) REFERENCES `llx_c_units` (`rowid`);

--
-- Filtros para la tabla `llx_usergroup_rights`
--
ALTER TABLE `llx_usergroup_rights`
  ADD CONSTRAINT `fk_usergroup_rights_fk_usergroup` FOREIGN KEY (`fk_usergroup`) REFERENCES `llx_usergroup` (`rowid`);

--
-- Filtros para la tabla `llx_usergroup_user`
--
ALTER TABLE `llx_usergroup_user`
  ADD CONSTRAINT `fk_usergroup_user_fk_user` FOREIGN KEY (`fk_user`) REFERENCES `llx_user` (`rowid`),
  ADD CONSTRAINT `fk_usergroup_user_fk_usergroup` FOREIGN KEY (`fk_usergroup`) REFERENCES `llx_usergroup` (`rowid`);

--
-- Filtros para la tabla `llx_user_employment`
--
ALTER TABLE `llx_user_employment`
  ADD CONSTRAINT `fk_user_employment_fk_user` FOREIGN KEY (`fk_user`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_user_rights`
--
ALTER TABLE `llx_user_rights`
  ADD CONSTRAINT `fk_user_rights_fk_user_user` FOREIGN KEY (`fk_user`) REFERENCES `llx_user` (`rowid`);

--
-- Filtros para la tabla `llx_website_page`
--
ALTER TABLE `llx_website_page`
  ADD CONSTRAINT `fk_website_page_website` FOREIGN KEY (`fk_website`) REFERENCES `llx_website` (`rowid`);
